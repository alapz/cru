library(here)
source(here("R","CRUmisc.R")); load(here("data","FakeData.rda"))
