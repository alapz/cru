## ----echo=FALSE---------------------------------------------------------------
library(CRUmisc)
#source("R:/CRU Epibiostat/projects/Nick/CRUmisc [svn]/CRUmisc/R/CRUmisc.R")

## ----message=FALSE,warning=FALSE----------------------------------------------
library(CRUmisc)
library(ggplot2)
library(dplyr)

## -----------------------------------------------------------------------------
u <- FakeData
u$Severity[c(1:2,8:9)] <- NA

## ----fig.width=7,fig.height=1.5-----------------------------------------------
plotpctbars(u,Severity,grouping=Category)
# Corresponding variable tree: vtree(u,"Category Severity")

## ----fig.width=7,fig.height=1.5-----------------------------------------------
plotpctbars(u,Severity,grouping=Category,drop=TRUE)
# Corresponding variable tree: vtree(u,"Category Severity")

## ----fig.width=7,fig.height=1.5-----------------------------------------------
plotpctbars(u,Severity,grouping=Category,vp=FALSE)

# Corresponding variable tree: vtree(u,"Category Severity",vp=FALSE)

## ----fig.width=7,fig.height=2-------------------------------------------------
plotpctbars(u,Sex,Severity)

## ----fig.width=7,fig.height=2-------------------------------------------------
plotpctbars(u,Sex,Severity,hide="M") + theme(legend.position="none")

## ----fig.width=7,fig.height=2-------------------------------------------------
plotpctbars(u,Sex,Severity,hide="M",sort="F") + theme(legend.position="none")

## ----fig.width=7,fig.height=1.5-----------------------------------------------
plotpctlikert(u,Severity,,below=c("Mild","Moderate"),grouping=Category)
# Corresponding variable tree: vtree(u,"Category Severity")

## ----fig.width=7,fig.height=1.1-----------------------------------------------
plotpctlikert(u,Severity,below=c("Mild","Moderate"),grouping=Category,drop=TRUE)
# Corresponding variable tree: vtree(u,"Category Severity")

## ----fig.width=7,fig.height=1.5-----------------------------------------------
plotpctlikert(u,Severity,below=c("Mild","Moderate"),grouping=Category,vp=FALSE)

# Corresponding variable tree: vtree(u,"Category Severity",vp=FALSE)

## ----fig.width=7,fig.height=1.5-----------------------------------------------
plotpctlikert(u,Severity,below="Mild",middle="Moderate",grouping=Category)
# Corresponding variable tree: vtree(u,"Category Severity")

## ----fig.width=7,fig.height=1.5-----------------------------------------------
plotpctlikert(u,Severity,below="Mild",middle="Moderate",grouping=Category,vp=FALSE)

# Corresponding variable tree: vtree(u,"Category Severity",vp=FALSE)

## ----fig.width=2.5,fig.height=4, echo=TRUE------------------------------------
par(las=1,mar=c(1,4,2,1))
boxbee(FakeData$Score)
title("Score")

## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------
par(las=1,mar=c(5,4,1,1))
drawprop(cbind(c(23,27-23),c(24,29-24),c(20,26-20),c(37,42-37)))

## -----------------------------------------------------------------------------

# legendabove(xpos, yrel = 0.1, xrel, log = "", ...)

## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------


## -----------------------------------------------------------------------------


## ----eval=FALSE---------------------------------------------------------------
#  grVizToPNG(example1)

## ----highlight=FALSE, eval=FALSE----------------------------------------------
#  ![](example1.png){ height=3in }

## ----highlight=FALSE, eval=FALSE----------------------------------------------
#  ![](MyFolder/example1.png){ height=3in }

## ----message=FALSE, warning=FALSE---------------------------------------------
#Flow-Chart

library(dplyr)

#Make up a simple exclusion/inclusion graph by first subsetting:

Keep.1 <-FakeData %>% filter(!is.na(Severity)) #remove subjects with missing data for Severity
exclude.1 <-FakeData %>% filter(is.na(Severity)) #how many were excluded for having missing Severity data
groupA <-Keep.1 %>% filter(Group=="A") #Split into a couple of 'intervention' groups
groupB <-Keep.1 %>% filter(Group=="B")

#Values for graph based upon subsets

sample.1 <-nrow(FakeData)
ex.1  <-nrow(exclude.1)
keep.1 <-nrow(Keep.1)
a.group <-nrow(groupA)
b.group <-nrow(groupB)

## ----echo=T-------------------------------------------------------------------
flowchart1 <- DiagrammeR::grViz("
digraph G {

  # a 'graph' statement

  graph [compound = true, nodesep = .5, ranksep = .25, fontsize = 12]

  # several 'node' statements

  node [fontname = Helvetica,
        fontcolor = black,
        shape = rectangle,
        color = black,
        width = 2,
        margin =  0.2
  ]

  Start[constraint=false,group=left];
  Complete[constraint=false,group=left];
  GA[group=left];
  GB[group=left];


  node [fontname = Helvetica,
        fontcolor = black,
        shape = rectangle,
        color = black,
        width = 2.5,
        margin =  0.2
  ]

 missing[group=right];


  Start -> Complete
  Start -> missing
  Complete -> GA
  Complete -> GB

  subgraph {
    rank = same;  Start;  missing;
  }

  Start[label = '@@1']
  missing[label = '@@2']
  Complete[label = '@@3']
  GA[label = '@@4']
  GB[label = '@@5']

}


[1]: paste0('All Records\\n',  'N=', sample.1)
[2]: paste0('Incomplete Records\\n', 'N=', ex.1)
[3]: paste0('Complete Records\\n', 'N=', keep.1)
[4]: paste0('Group A\\n', 'N=', a.group )
[5]: paste0('Group B\\n', 'N=', b.group )

")

grVizToPNG(flowchart1) #This is the function call

# Include the following code to insert your flow chart (outside of the code chunk)
#
# ![](flowchart1.png){height=3in}


