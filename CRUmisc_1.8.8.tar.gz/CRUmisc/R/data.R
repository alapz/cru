#' Fake Clinical Data.
#'
#' A dataset that contains some made-up data, including missing observations (i.e. NAs).
#'
#' @format A data frame with 46 rows and 6 variables:
#' \describe{
#'   \item{Group}{Treatment Group, A or B}
#'   \item{Severity}{Severity of condition, factor, Mild, Moderate, Severe}
#'   \item{Sex}{M or F}
#'   \item{Age}{Age, years, continous}
#'   \item{Male}{Sex coded as 1=M, 0=F}
#'   \item{Score}{continuous value}
#'   \item{Category}{single, double, or triple}
#'   \item{Pre}{initial measurement}
#'   \item{Post}{measurement taken after something happened}
#'   \item{Post2}{measurement taken at the very end}
#'   \item{Time}{time to event, or time of censoring}
#'   \item{Event}{Did the event occur? (1=yes, 0=no (i.e. censoring)}
#'   \item{Ind1}{An indicator variable for a certain characteristic, 1=present, 0=absent}
#'   \item{Ind2}{An indicator variable for a certain characteristic, 1=present, 0=absent}
#'   \item{Ind3}{An indicator variable for a certain characteristic, 1=present, 0=absent}
#'   \item{Ind4}{An indicator variable for a certain characteristic, 1=present, 0=absent}
#'
#' }
"FakeData"


#' Cloud
#'
#' A dataset that contains data on cloud seeding
#'
#' @format A data frame with 52 rows and 2 variables
#' describing a study in which 26 randomly selected clouds
#' were seeded with silver oxide. A control group of 26 clouds were not treated with silver
#' oxide.
#' \describe{
#'   \item{group}{seeded or notseeded}
#'   \item{volume}{rainfall in acre feet}
#' }
#' @details
#' Data set is given in:
#' Distribution-Free Confidence Intervals For Difference And Ratio Of Medians
#' Robert M. Price and Douglas G. Bonett
#' J. Statist. Comput. Simul., 2002, Vol. 72(2), pp. 119–124
#'
#' Source:
#' Simpson, J., Olsen, A. and Eden, J. C. (1975).
#' A Bayesian analysis of a multiplicative treatment effect in weather modification.
#' Techno., 17, 161–166.
#'
"cloud"
