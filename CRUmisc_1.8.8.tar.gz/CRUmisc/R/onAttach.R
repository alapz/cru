.onAttach <- function(...) {
  
  if (interactive()) {
    packageStartupMessage("CRUmisc version ",utils::packageVersion("CRUmisc")," -- For more information, type: vignette(\"CRUmisc\")")
  }
}
