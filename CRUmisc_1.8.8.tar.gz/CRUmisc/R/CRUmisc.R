#'
#' CRUmisc: Miscellaneous tools used and/or developed at the Clinical Research Unit.
#' @description
#' \code{CRUmisc} A package that provides tools developed
#' the CHEO Clinical Research Unit.
#'
#' @details
#' Miscellaneous tools used and/or developed at the Clinical Research Unit.
#' The package was developed by the Clinical Research Unit
#' at the Children's Hospital of Eastern Ontario (CHEO).
#'
#' @docType package
#' @name  CRUmisc
NULL


#' @title sp - Open browser page pointing to SharePoint project folder
#' @description Launch a browser on project-folder.html in the current directory
#'
#' @export
#'
sp <- function() {
  filename <- "project-folder.html"
  if (!file.exists(filename)) 
    stop("Cannot find file",filename)
      
  rstudioapi::viewer("project-folder.html")
}


#' @title wp 
#' @description Get the Windows path of the current folder
#'
#' @export
#'
wp <- function() {
  path <- getwd()
  p1 <- gsub("^/share","//rifilesrv1",path)
  
  # This is tricky
  # See: https://stackoverflow.com/a/41186646
  p2 <- gsub("/","\\",p1,fixed=TRUE)
  
  cat(p2)
}

 
#' @title FitFlextableToPage
#' @description Fit a flextable to a desired page width
#' @author Sarah https://stackoverflow.com/a/57193998
#' @param ft         flextable object
#' @param pgwidth    page width
#'
#' @export
#'
FitFlextableToPage <- function(ft, pgwidth = 6){

  ft_out <- ft %>% autofit()

  ft_out <- width(ft_out, 
    width = dim(ft_out)$widths*pgwidth /(flextable_dim(ft_out)$widths))
  return(ft_out)
}



#' @title urlpath
#' @description Find the URL path for a repo in the CRU's svn folder that matches the text provided
#' @author Nick Barrowman
#' @param text         text to search for in repo names. If not specified,
#'                     the URL paths for all repos will be listed.
#'
#' @export
#'
urlpath <- function(text) {
  if (missing(text)) {
    names <- suppressWarnings(system(
      paste0("cd /share/team/cru/svn ;", " ls"),intern=TRUE))     
  } else {
    names <- suppressWarnings(system(
      paste0("cd /share/team/cru/svn ;", " ls | grep -i ",text),
      intern=TRUE))
  }
  if (length(names)==0) stop("Nothing found.")
  for (name in names) {
    system(paste0("cd /share/team/cru/svn ;", " urlpath ","\"",name,"\""))
  }
  invisible()
}


#' @title Make a new SVN repository
#' @description Run the svnadmin create command and extract the path to the repo
#' @author Nick Barrowman
#'
#' @export
#'
makesvn <- function(reponame) {
  system(
    paste(
      "cd /share/team/cru/svn ;",
      "svnadmin create",reponame," ;",
      "chmod -R g+w",reponame," ;",
      "urlpath",reponame))
}

#' @title Make a new SVN repository on the v drive
#' @description Run the svnadmin create command and extract the path to the repo
#' @author Nick Barrowman
#'
#' @export
#'
makesvn_vdrive <- function(reponame) {
  system(
    paste(
      "cd ~/vdrive/CRU\\ Epibiostat/SVN ;",
      "svnadmin create",reponame," ;",
      "urlpath",reponame))
}


#' @title Set up a new project folder that is under SVN control
#' @description After creating a new project from a version control repository,
#'              set up a standard folder structure and .svnignore rules
#' @author Nick Barrowman
#'
#' @export
#'
setupdir <- function() {
  system("setupdir")
}


#' @title Show folder paths
#' @description Show folder path on Lambda server and on Windows
#' @author Nick Barrowman
#'
#' @export
#'
folder <- function() {
  wd <- getwd()
  wdwin <- gsub("\\/home\\/nbarrowman\\/vdrive\\/","V:/Research/CRU/",wd)
  wdwin2 <- gsub("\\/home\\/nbarrowman\\/jdrive\\/","J:/",wdwin)
  cat(wd,"\n")
  cat(wdwin2,"\n")
}


#' @title Remove labelled class
#' @description For each variable in the dataframe, remove labelled class
#' @author Nick Barrowman
#' @param data           Required: Data frame to use.
#' @param ignore         Names of any variables to ignore
#'                       Defaults to "a^" which will no match any string.
#' @param verbose        Report on ignored variables
#'
#' @export
#'
remove_class_labelled <- function(data,ignore="a^",verbose=FALSE) {
  data_names <- names(data)
  
  choose <- rep(TRUE,length(data_names))
  for (IGNORE in ignore) {
    choose <- choose & !grepl(IGNORE,data_names)
  }
  
  if (verbose) {
    names_ignored <- data_names[!choose]
    if (length(names_ignored)==0) {
      message("remove_class_labelled: not ignoring any variables.")
    } else {
      message("remove_class_labelled: Ignoring ",length(names_ignored)," variables.")
      message(paste(names_ignored,collapse=" "))
    }
  }
  
  for (i in (1:ncol(data))[choose]) {
    cl <- class(data[[i]])
    if ("labelled" %in% cl) class(data[[i]]) <- cl[cl!="labelled"]
  }  
  
  data
}

#' @title Remove redcapFactor class
#' @description For each variable in the dataframe, remove redcapFactor class
#' @author Nick Barrowman
#' @param data           Required: Data frame to use.
#' @param ignore         Names of any variables to ignore.
#'                       Defaults to "a^" which will no match any string.
#' @param verbose        Report on ignored variables
#'
#' @export
#'
remove_class_redcapFactor <- function(data,ignore="a^",verbose=FALSE) {
  data_names <- names(data)
  
  choose <- rep(TRUE,length(data_names))
  for (IGNORE in ignore) {
    choose <- choose & !grepl(IGNORE,data_names)
  }

  if (verbose) {
    names_ignored <- data_names[!choose]
    if (length(names_ignored)==0) {
      message("remove_class_redcapFactor: not ignoring any variables.")
    } else {
      message("remove_class_redcapFactor: Ignoring ",length(names_ignored)," variables.")
      message(paste(names_ignored,collapse=" "))
    }
  }
  
  for (i in (1:ncol(data))[choose]) {
    cl <- class(data[[i]])
    if ("redcapFactor" %in% cl) class(data[[i]]) <- cl[cl!="redcapFactor"]
  }  
  
  data
}


#' @title Unload other packages (using pkgload::unload)
#' @description Unload all packages except base packages and knitr, CRUmisc, and CRUmarkdown
#' @author Nick Barrowman
#'
#' @export
#'
unloadOtherPackages <- function() {
    loaded <- names(sessionInfo()$otherPkgs)
    loaded <- loaded[!(loaded %in% c("knitr", "CRUmisc", "CRUmarkdown"))]
    lapply(loaded, function(pkgs) pkgload::unload(pkgs))
}


#' @title Unload other packages
#' @description Unload all packages except base packages and knitr, CRUmisc, and CRUmarkdown
#' @author Nick Barrowman
#'
#' @export
#'
unload_other_packages <- function() {
  
  loaded <- names(sessionInfo()$otherPkgs)
  loaded <- loaded[!(loaded %in% c("knitr","CRUmisc","CRUmarkdown"))]
  
  lapply(loaded, function(pkgs)
    detach(
      paste0('package:', pkgs),
      character.only = T,
      unload = T,
      force = T
    ))
}


#' @title Obtain paths depending on the system
#' @description Obtain paths depending on the system
#' @author Nick Barrowman
#' @param rifilesrv1 Is the new RI file server being used?
#'
#' @export
#'
getpaths <- function (rifilesrv1 = FALSE)
{
  if (Sys.info()["sysname"] == "Linux") {
    if (rifilesrv1) {
      #USER <- Sys.getenv()["USER"]
      DBDATA <- paste0("~/personal/DBData/")
      RCDATA <- paste0("~/personal/RCData/")
      RCTOKENS <- paste0("~/personal/RCTokens/")
      CRUDATA <- paste0("/share/team/cru/CRU-Data/")
    }
    else {
      HOME <- Sys.getenv()["HOME"]
      DBDATA <- paste0(HOME, "/jdrive/DBData/")
      RCDATA <- paste0(HOME, "/jdrive/RCData/")
      RCTOKENS <- paste0(HOME, "/jdrive/RCTokens/")
      CRUDATA <- paste0(HOME, "/vdrive/CRU Data/")
    }
  }
  else {
    DBDATA <- "J:/DBData/"
    RCDATA <- "J:/RCData/"
    RCTOKENS <- "J:/RCTokens/"
    CRUDATA <- "R:/CRU Data/"
  }
  list(DBDATA = DBDATA, RCDATA = RCDATA, RCTOKENS = RCTOKENS,
       CRUDATA = CRUDATA)
}


#' @title Plot pairs with correlation coefficients too
#' @description Call `pairs` function (base R graphics), and
#'              show correlation coefficients too
#' @author Nick Barrowman
#' @param data           Required: Data frame to use.
#' @param method         "pearson" or "spearman"
#' @param labelx,labely  Coordinates of the correlation label
#' 
#' @details Displays the top right triangle of a scatterplot matrix
#' 
#' @examples
#'
#' library(dplyr)
#' FakeData %>% select(Pre,Post,Post2) %>% plotpairs(labelx=0.6,labely=0.1)
#'   
#' @export
#'
plotpairs <- function(data,method="pearson",labelx=0.1,labely=0.9,adj=0) {
  
  upper.panel<-function(x,y){
    points(x,y, pch=19)
    r <- round(cor.test(x, y,method=method)$estimate, digits=2)
    txt <- paste0("r = ", r)
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(0, 1, 0, 1))
    text(labelx,labely, txt,adj)
  }
  
  par(pty="s",las=1)
  pairs(as.matrix(data),
    lower.panel=NULL,upper.panel=upper.panel)  
}


IsDark <- function(color) {
  apply(grDevices::col2rgb(color) *c(299, 587,114)/1000,2,sum) < 186
}


getLabelColor <- function(colorsPerCat,var) {
  factor(
    ifelse(IsDark(colorsPerCat[as.character(var)]),'white','black'))
}


#' @title Plot stacked bars of percentages of Likert scale values by group
#' @description Fill colors corresponding to the values of the variable can be specified
#'              and the pieces of the stacked bars will be labeled to show
#'              frequency and percentage.
#'              For readability, the labels will be black of white according to
#'              the fill color.
#' @author Nick Barrowman
#' @param data         Required: Data frame to use.
#' @param item         Required: Likert factor variable in \code{data}.
#'                     Should be ordered from negative to positve.
#'                     Otherwise specify \code{pos=TRUE}.
#' @param below        Required: Values of \code{item} that are "below" the middle.
#' @param middle       Value of \code{item} (if any) that represents the middle of the scale.
#'                     (e.g. A scale like [Disagree, Agree] does not have a middle value,
#'                     whereas [Disagree, Neither, Agree] has a middle value, namely Neither.)
#' @param grouping     Grouping factor in \code{data}.
#' @param fillColor    a vector of colors, corresponding to the levels of \code{item}
#' @param pos          Is the Likert variable ordered from positive to negative?
#' @param keepEmpty    keep values that are in \code{fillColor} but don't appear in \code{item}
#' @param drop         Do not show unused levels in \code{grouping} variable?
#'                     (Default is FALSE, i.e. show unused levels.)
#' @param labelwrap    Number of characters before wrapping an axis label
#' @param labelsize    Size of font for labels (in pt)
#' @param textsize     Size of font for text in pt)
#' @param width        The width parameter in geom_bar
#' @param shown        Display sample size in each bar segment?
#' @param showtotals   Show totals on the left and right.
#' @param na.value     Color to use to show missing values
#' @param missingLabel Label to use for missing values
#' @param linecolor    Color of line to divide categories that are above and below
#' @param minpct       Minimum percentage to show a label
#' @param horiz        Should the plot be horizontal?
#' 
#' @return A ggplot object.
#' 
#' @examples
#'
#' # No grouping, no middle.
#' # Added borders around the colors in the legend.  
#' lev <- c("Very sad","A bit sad","A bit happy","Very happy")
#' d <- data.frame(mood=factor(lev[c(1,3,2,3,1,3,3,4,1,4,1,2,2)],levels=lev))
#' plotpctlikert(d,mood,below=c("Very sad","A bit sad")) + 
#'   guides(fill = guide_legend(override.aes = list(color = "black")))
#'
#' # Grouping, and a middle value
#' lev <- c("Very sad","A bit sad","Neither happy nor sad","A bit happy","Very happy")
#' d1to7 <- rev(weekdays(ISOdate(1, 1, 1:7)))
#' daysOfTheWeek <- factor(d1to7,levels=d1to7)
#' d <- data.frame(
#'   mood=factor(lev[c(1,1,4,2,3,2,3,1,4,3,3,4,1,4,1,2,2,5,5,5)],levels=lev),
#'   day=daysOfTheWeek[c(4,1,1,1,1,2,2,2,3,3,4,4,5,5,6,7,7,7,7,7)])
#' plotpctlikert(d,mood,below=c("Very sad","A bit sad"),
#'   middle="Neither happy nor sad",grouping=day) 
#'   
#' @export
#'
plotpctlikert <- function(data,item,below=NULL,middle=NULL,grouping,fillColor=NULL,pos=FALSE,vp=TRUE,keepEmpty=TRUE,drop=FALSE,labelwrap=20,
  labelsize=15,textsize=13,shown=FALSE,showtotals=FALSE,width=0.8,horiz=TRUE,
  na.value="grey50",missingLabel="Missing",linecolor="grey70",minpct=5) {
  
  require(dplyr)
  require(ggplot2)

  if (missing(item)) stop("Must specify item (a Likert-scale variable).")
  
  z <- data
  
  if (is.null(below)) stop("Must specify below (which items are below the middle).")
  
  if (missing(grouping)) {
    z$....GROUPING <- rep("",nrow(z))
  } else {
    z <- z %>% mutate(....GROUPING={{grouping}})
  }
  
  if (!is.factor(z$....GROUPING)) z$....GROUPING <- factor(z$....GROUPING)
  
  if (pos) { 
    z <- z %>% mutate(
      {{item}} := factor({{item}},levels=rev(levels({{item}}))))
  }
  
  u <- levels(z %>% pull({{item}}))
  
  if (!all(below %in% u)) stop("Some values in below are not levels of the item variable.")
  
  categoryNames <- u
  
  prespecifiedMiddle <- !is.null(middle)

  if (is.null(fillColor)) {
    fillColor <- hcl.colors(length(u),"Zissou 1")  # "Temps"
  }
  names(fillColor) <- u

  if (length(u) != length(fillColor)) 
    stop("length of fillColor parameter must equal number of levels of the item variable.")
  
  any_missing_item <- any(is.na(z %>% pull({{item}})))

  z <- z %>%
    group_by(....GROUPING,{{item}})
  
  if (vp) {
    if (any_missing_item) {
      num_missing <- sapply(
        split(z%>% pull({{item}}),z$....GROUPING),
        function(x) sum(is.na(x)))
      num_missing_message <- paste0(names(num_missing),":",num_missing,sep=" ")
      message("number of missing values by group: ",num_missing_message)
    }

    z <- z %>%
      dplyr::filter(!is.na({{item}}))
  }

  z <- z %>%
    group_by(....GROUPING,{{item}},.drop=FALSE) %>%
    dplyr::summarise(n=n(),.groups = "drop_last") %>%
    mutate(pct=100*n/sum(n))
  
  displaynpct <- function(pct,n,shown) {
    if (shown) {
      paste0(around_func(abs(pct), 0), "%", "\n(n=", n, ")")
    } else {
      paste0(around_func(abs(pct), 0), "%")
    }
  }

  #z <- z %>%
  #  mutate(....Category=factor({{item}},levels=names(fillColor)))
  
  z$....Category <- z %>% pull({{item}})

  if (is.null(middle)) {

    middle_lo <- NULL
    middle_hi <- NULL

    above <- u[!(u %in% below)]

    new_fillColor <- fillColor
    newlevels <- names(fillColor)

    if (any_missing_item & !vp) {
      CATEGORY <- as.character(z$....Category)
      CATEGORY[is.na(CATEGORY)] <- missingLabel
      z$....Category <- factor(CATEGORY,levels=c(below,missingLabel,above))
      categoryNames <- levels(z$....Category)
      middle <- missingLabel
      fillColor[missingLabel] <- na.value
    } else {
      z <- z %>%
        mutate(
          pct=if_else(....Category %in% below,-pct,pct))
    }

    z$newcat <- z$....Category
    z$CAT <- factor(z$newcat,levels=c(below,rev(above)))

    z$bigenough <- abs(z$pct) >= minpct
  }

  if (!is.null(middle)) {

    above <- u[!(u %in% below) & !(u %in% middle)]

    mid <- z %>% dplyr::filter(is.na(....Category) | ....Category==middle)

    d_below  <- z %>% dplyr::filter(....Category %in% below)
    d_middle <- z %>% dplyr::filter(is.na(....Category) | ....Category %in% middle)
    d_above  <- z %>% dplyr::filter(!(....Category %in% below) & !(is.na(....Category) | ....Category %in% middle))

    middle_lo <- middle
    middle_hi <- paste0(middle,"hi")

    newlevels <- c(below,middle_lo,middle_hi,above)

    z <- bind_rows(
      d_below  %>% mutate(pct=-pct,newcat=as.character(....Category)),
      d_middle %>% mutate(n=n/2,pct=-pct/2,newcat=middle_lo),
      d_middle %>% mutate(n=n/2,pct=pct/2,newcat=middle_hi),
      d_above  %>% mutate(newcat=as.character(....Category)))

    new_fillColor <- c(
      fillColor[below],fillColor[middle],fillColor[middle],fillColor[above])

    z$CAT <- factor(z$newcat,levels=c(below,middle_lo,rev(c(middle_hi,above))))

    z$bigenough <- abs(z$pct) >= minpct & !is.na(z$....Category) & z$....Category!=middle

  }

  VALUES <- new_fillColor
  names(VALUES) <- newlevels
  
  middleOrNA <- middle
  
  if (any_missing_item & !vp) {
    if (is.null(middle)) {
      VALUES <- c(VALUES,na.value)
      names(VALUES)[length(names(VALUES))] <- missingLabel
      if (is.null(middle)) {
        categoryNames <- c(below,missingLabel,above)
      } else{
        categoryNames <- c(below,middle,missingLabel,above)
      }
    } else {
      if (prespecifiedMiddle) {
        middleOrNA <- paste0(categoryNames[categoryNames==middle]," or missing")
        categoryNames[categoryNames==middle] <- middleOrNA
        levels(z$CAT)[levels(z$CAT)==middle] <- middleOrNA
        names(VALUES)[names(VALUES)==middle] <- middleOrNA
        middle_lo <- middleOrNA
      }
    }
  }
  
  z$LabelColor <- getLabelColor(VALUES,z$....Category)

  if (!keepEmpty) {
    fillColor <- fillColor[names(VALUES) %in% z$....Category]
  }

  RANGE <- z %>% group_by(....GROUPING) %>% dplyr::summarize(sumneg=sum(pct[pct<0],na.rm=TRUE),sumpos=sum(pct[pct>0],na.rm=TRUE))


  positive <- z %>% dplyr::filter(CAT %in% c(middle_hi,above))
  negative <- z %>% dplyr::filter(CAT %in% c(below,middle_lo))
  positive_or_NA <- z %>% dplyr::filter(is.na(CAT) | CAT %in% c(middle_hi,above))

  POS <- z %>% dplyr::filter(CAT %in% above)
  NEG <- z %>% dplyr::filter(CAT %in% below)

  right <- tapply(positive$pct,positive %>% pull(....GROUPING),sum)
  left  <- tapply(negative$pct,negative %>% pull(....GROUPING),sum)

  right_or_NA <- tapply(positive_or_NA$pct,positive_or_NA %>% pull(....GROUPING),sum)

  RIGHTpct <- tapply(POS$pct,POS %>% pull(....GROUPING),sum)
  LEFTpct  <- tapply(NEG$pct,NEG %>% pull(....GROUPING),sum)

  RIGHTn <- tapply(POS$n,POS %>% pull(....GROUPING),sum)
  LEFTn <- tapply(NEG$n,NEG %>% pull(....GROUPING),sum)

  TheEnds <- data.frame(names(left),left,LEFTpct,LEFTn,right,RIGHTpct,RIGHTn,right_or_NA)

  names(TheEnds)[1] <- as.character(ensym(grouping))

  mid <- z %>% dplyr::filter(CAT %in% c(middle_lo,middle_hi,middleOrNA)) %>% dplyr::summarize(n=sum(n),pct=sum(abs(pct)))

  mid$bigenough <- abs(mid$pct) >= minpct

ggplot(data=z,
    aes(
      y=pct,
      fill=CAT,
      label=if_else(bigenough,displaynpct(pct,n,shown=shown),""),
      color=LabelColor)) +
    geom_bar(aes(color=NULL,x=....GROUPING),stat="identity",position=position_stack(), width=width) +
    scale_fill_manual(values = VALUES,breaks=categoryNames,na.value = na.value) +
    scale_color_manual(values=levels(z$LabelColor)) +
    scale_x_discrete(expand=c(0,0),labels = function(x) stringr::str_wrap(x, width = labelwrap),drop=drop) +
   (if (showtotals) {
      scale_y_continuous(expand=c(0.1,0.1))
    } else {
      scale_y_continuous(expand=c(0,0))
    })+
    geom_text(
      aes(x=....GROUPING, y=pct),
      position = position_stack(vjust=.5), size=textsize/2.83465)+
    (if (showtotals) {
      geom_text(data=TheEnds,
        aes(
          y=left,x=....GROUPING,fill=NULL,color=NULL),
        hjust=1.2, size=textsize/2.83465,
        label=displaynpct(-LEFTpct,LEFTn,shown=shown))
    }) +
    (if (showtotals) {
      geom_text(data=TheEnds,
        aes(
          y=right_or_NA,x=....GROUPING,fill=NULL,color=NULL),
        hjust=-0.2, size=textsize/2.83465,
        label=displaynpct(RIGHTpct,RIGHTn,shown=shown))
    }) +
    ylab("")+
    xlab("")+
     guides(
      x="none",
      color="none") +
    theme(legend.position="bottom") +
    (if (horiz) {
      coord_flip()
    }) +
    geom_hline(yintercept=0,color=linecolor,linewidth=1.5) +
    (if (!is.null(middle)) {
      #browser()
      geom_label(
        aes(
          x=....GROUPING,y=0,fill=NULL,
      label=if_else(bigenough,displaynpct(pct,n,shown=shown),"")),
        data=mid,color=as.character(getLabelColor(VALUES,middle)),
        fill=if_else(mid$bigenough,VALUES[middleOrNA],NA_character_),label.size=NA,size=textsize/2.83465)
    }) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.background = element_blank(),
      axis.text.x=element_blank(),
      axis.line.y = element_blank(),
      axis.line.x = element_blank(),
      legend.title = element_blank(),
      axis.ticks.y=element_blank(),
      axis.title.y=element_blank(),
      axis.text=element_text(size=labelsize),
      legend.position="bottom",
      legend.text=element_text(size=labelsize),
      legend.margin=margin(0,0,0,0),
      legend.box.margin=margin(-10,0,0,0),
      plot.margin=unit(c(0,0,0,0),"cm"))  
  
  }



#' @title Plot stacked bars of percentages of values of a variable by group
#' @description Fill colors corresponding to the values of the variable can be specified
#'              and the pieces of the stacked bars will be labeled to show
#'              frequency and percentage.
#'              For readability, the labels will be black of white according to
#'              the fill color.
#' @author Nick Barrowman
#' @param data         Required: Data frame to use.
#' @param item         Required: Factor variable in \code{data}.
#' @param grouping     A grouping variable.
#' @param type         A variable specifying a higher-level grouping.
#' @param fillColor    a vector of colors, corresponding to the levels of \code{item}
#' @param vp           Use valid percentages?
#' @param keepEmpty    keep values that are in \code{fillColor} but don't appear in \code{item}
#' @param drop         Do not show unused levels in \code{grouping} variable?
#'                     (Default is FALSE, i.e. show unused levels.)
#' @param labelwrap    Number of characters before wrapping an axis label
#' @param labelsize    Size of font for labels (in pt)
#' @param textsize     Size of font for text (in pt)
#' @param shown        Show sample size (as well as percentage)
#' @param na.value     Colour to use to show missing values
#' @param missingLabel Label to use for missing values
#' @param minpct       Minimum percentage to show a label
#' @param hide         Don't show specified value. (For example with "Yes" and "No",
#'                     it may be desired to hide "No".)           
#' @param sort         A value of \code{item} to sort the grouping variable by.
#' @param width        The \code{width} setting in geom_bar
#' @param expand.x     How much to pad between data and edge of axis
#' @param expand.y     How much to pad between data and edge of axis
#' @param breaks       Specific levels to include in the legend.
#' @param horiz        Should the plot be horizontal?
#'
#' @return A ggplot object.
#' 
#' @examples
#'
#' # No grouping 
#' # Added borders around the colors in the legend.  
#' lev <- c("Very sad","A bit sad","A bit happy","Very happy")
#' d <- data.frame(mood=factor(lev[c(1,3,2,3,1,3,3,4,1,4,1,2,2)],levels=lev))
#' plotpctbars(d,mood) + 
#'   guides(fill = guide_legend(override.aes = list(color = "black")))
#'
#' # Grouping
#' lev <- c("Very sad","A bit sad","Neither happy nor sad","A bit happy","Very happy")
#' d1to7 <- rev(weekdays(ISOdate(1, 1, 1:7)))
#' daysOfTheWeek <- factor(d1to7,levels=d1to7)
#' d <- data.frame(
#'   mood=factor(lev[c(1,1,4,2,3,2,3,1,4,3,3,4,1,4,1,2,2,5,5,5)],levels=lev),
#'   day=daysOfTheWeek[c(4,1,1,1,1,2,2,2,3,3,4,4,5,5,6,7,7,7,7,7)])
#' plotpctbars(d,mood,grouping=day)
#'  
#' @export
#'
plotpctbars <- function(data,item,grouping=1,type,fillColor=NULL,vp=TRUE,
  keepEmpty=TRUE,drop=FALSE,labelwrap=20,breaks=NULL,horiz=TRUE,
  labelsize=15,textsize=13,shown=FALSE,na.value="grey50",missingLabel="Missing",minpct=5,
  hide=NULL,sort="",width=0.8,expand.x=c(0,0),expand.y=c(0.1,0.1)) {
  
  require(dplyr)
  require(ggplot2)

  data <- data %>% mutate(stuff1={{grouping}})
  
  z <- data
  
  z <- z %>% mutate(stuff2={{grouping}})

  if (missing(grouping)) {
    z$....GROUPING <- rep("",nrow(z))
  } else {
    z <- z %>% mutate(....GROUPING={{grouping}})
    
    if (any(is.na(z$....GROUPING))) {
      groupingLevels <- levels(z$....GROUPING)
      z <- z %>% mutate(
        ....GROUPING=as.character(....GROUPING),
        ....GROUPING=if_else(is.na(....GROUPING),missingLabel,....GROUPING),
        ....GROUPING=factor(....GROUPING,levels=c(groupingLevels,missingLabel)))
    }
  }

  if (!is.factor(z$....GROUPING)) z$....GROUPING <- factor(z$....GROUPING)

  u <- levels(z %>% pull({{item}}))
  
  if (is.null(breaks)) breaks <- u
  
  
  if (is.null(fillColor)) {
    fillColor <- hcl.colors(length(u),"Zissou 1",alpha=0.8)
    names(fillColor) <- u
  }

  names(fillColor) <- u
  
  any_missing_item <- any(is.na(z %>% pull({{item}})))
  
  if (missing(type)) {
    z <- z %>%
      group_by(....GROUPING,{{item}},.drop=FALSE)
  } else {
    z <- z %>%
      group_by({{type}},....GROUPING,{{item}},.drop=FALSE)
  }    

  if (vp) {
    if (any_missing_item) {
      num_missing <- sapply(
        split(z%>% pull({{item}}),z %>% pull(....GROUPING)),
        function(x) sum(is.na(x)))
      num_missing_message <- paste0(names(num_missing),":",num_missing,sep=" ")
      message("number of missing values by group: ",num_missing_message)
    }

    z <- z %>%
      dplyr::filter(!is.na({{item}}))
  }

  z <- z %>%
    dplyr::summarise(n=n(),.groups = "drop_last") %>%
    mutate(pct=case_when(
      sum(n)>0  ~ 100*n/sum(n),
      sum(n)==0 ~ 0))

  if (any_missing_item && !vp) {
    fillColor <- c(fillColor,na.value)
    names(fillColor)[length(names(fillColor))] <- missingLabel
  }
  
  z$....Category <- z %>% pull({{item}})

  z$LabelColor <- getLabelColor(fillColor,z$....Category)

  z$LabelColor[is.na(z$....Category)] <-
    rep(ifelse(IsDark(na.value),'white','black'),sum(is.na(z$....Category)))

  if (!keepEmpty) {
    fillColor <- fillColor[names(fillColor) %in% z$....Category]
  }

  displaynpct <- function(pct,n,shown) {
    if (shown) {
      paste0(around_func(abs(pct), 0), "%", "\n(n=", n, ")")
    } else {
      paste0(around_func(abs(pct), 0), "%")
    }
  }
  
  z <- z %>% dplyr::filter(!({{item}} %in% hide))
  
  z$LabelColor <- factor(z$LabelColor)
  
  if (sort!="") {
    zcat <- z %>%
      dplyr::filter(....Category==sort) %>%
      dplyr::group_by(....GROUPING) %>%
      dplyr::summarize(pct_cat=pct[1])
    z <- z %>%
      left_join(zcat,by="....GROUPING")
    z$....GROUPING <- reorder(z$....GROUPING,z$pct_cat)
  }
  
  ggplot(
    data=z,
    mapping=aes(
      x=....GROUPING, y=pct,
      label=if_else(abs(pct) >= minpct,displaynpct(pct,n,shown=shown), ""),
      fill=....Category, color=LabelColor, group=....GROUPING)) +
    geom_bar(
      aes(color=NULL), stat = "identity", width=width,
      position=position_stack(reverse=TRUE))+
    scale_fill_manual(values=fillColor,na.value=na.value,breaks=breaks)+
    scale_color_manual(values=levels(z$LabelColor))+ #levels(z$LabelColor))+  # values="white") +
    scale_y_continuous(expand = expand.x)+    
    scale_x_discrete(expand=expand.y,labels = function(x) stringr::str_wrap(x, width = labelwrap),drop=drop)+
    geom_text(
      aes(....GROUPING, pct),
      position = position_stack(vjust=.5), size=textsize/2.83465)+
    ylab("")+
    xlab("")+
    guides(
      (if (horiz) { x="none" } else { y="none" }),
      #x="none",
      color="none") + #,
    (if (horiz) {
      coord_flip()
    }) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.background = element_blank(),
      #if (horiz) { axis.text.y=element_blank() } else (axis.text.x=element_blank()),
      axis.line.y = element_blank(),
      axis.line.x = element_blank(),
      legend.title = element_blank(),
      axis.ticks.y=element_blank(),
      axis.title.y=element_blank(),
      axis.text=element_text(size=labelsize),
      legend.position="bottom",
      legend.text=element_text(size=labelsize),
      legend.margin=margin(0,0,0,0),
      legend.box.margin=margin(-10,0,0,0),
      #panel.border = element_rect(color = "red",fill = NA,size = 1),  # testing: box around graph
      #legend.background = element_rect(colour = "orange",size=1),     # testing: box around legend
      plot.margin=unit(c(0,0,0,0),"cm"))
}



#' @title DEPRECATED: Plot horizontal stacked bars of percentages of likert values of a variable by group
#' @description Fill colors corresponding to the values of the variable can be specified
#'              and the pieces of the horizontal stacked bars will be labeled to show
#'              frequency and percentage.
#'              For readability, the labels will be black of white according to
#'              the fill color.
#' @author Nick Barrowman
#' @param data         a data frame containing variables \code{group} and \code{pct}
#' @param varname      the name of a variable in the data frame.
#'                     Note that the variables \code{group} and \code{pct} must represent
#'                     the corresponding group values and percentages of this variable.
#' @param fillColor    a vector of colors, with names equal to the values of \code{var}
#' @param keepEmpty    keep values that are in \code{fillColor} but don't appear in \code{var}
#' @param labelwrap    Number of characters before wrapping an axis label
#' @param labelsize    Size of font for labels
#' @param textsize     Size of font for text
#' @param width        The width parameter in geom_bar
#' @param shown        Show sample size (as well as percentage)
#' @param below        Which values are "below" the line?
#' @param middle       Which value is in the middle of the line?
#' @param na.value     Colour to use to show missing values
#' @param missingLabel Label to use for missing values
#'
#' @export
#'
plotlikert <- function(data,varname,fillColor,keepEmpty=TRUE,labelwrap=20,width=NULL,
  labelsize=15,textsize=5,shown=TRUE,showtotals=FALSE,below=NULL,middle=NULL,
  na.value="grey50",missingLabel="Missing") {
  
  message("This function is deprecated. Use the plotpctlikert function instead.")

  textfunc <- function(pct,n,shown) {
    if (shown) {
      paste0(around_func(abs(pct), 0), "%", "\n (n=", n, ")")
    } else {
      paste0(around_func(abs(pct), 0), "%")
    }
  }

  categoryNames <- names(fillColor)

  data$Category   <- factor(data[[varname]],levels=categoryNames)


  if (is.null(middle)) {

    middle_lo <- NULL
    middle_hi <- NULL

    above <- categoryNames[!(categoryNames %in% below)]

    new_fillColor <- fillColor
    newlevels <- names(fillColor)

    data2 <- data %>%
      mutate(
        pct=if_else(Category %in% below,-pct,pct))

    data2$newcat <- data2$Category
    data2$CAT <- factor(data2$newcat,levels=c(below,rev(above)))

    data2$showpct <- abs(data2$pct) >= 5

  } else {

    above <- categoryNames[
      !(categoryNames %in% below) & !(categoryNames %in% middle)]

    mid <- data %>% dplyr::filter(Category==middle)

    d_below  <- data %>% dplyr::filter(Category %in% below)
    d_middle <- data %>% dplyr::filter(Category %in% middle)
    d_above  <- data %>% dplyr::filter(!(Category %in% below) & !(Category %in% middle))

    middle_lo <- middle
    middle_hi <- paste0(middle,"hi")

    newlevels <- c(below,middle_lo,middle_hi,above)

    data2 <- bind_rows(
      d_below  %>% dplyr::mutate(pct=-pct,newcat=as.character(Category)),
      d_middle %>% dplyr::mutate(pct=-pct/2,newcat=middle_lo),
      d_middle %>% dplyr::mutate(pct=pct/2,newcat=middle_hi),
      d_above  %>% dplyr::mutate(newcat=as.character(Category)))

    new_fillColor <- c(
      fillColor[below],fillColor[middle],fillColor[middle],fillColor[above])

    data2$CAT <- factor(data2$newcat,levels=c(below,middle_lo,rev(c(middle_hi,above))))

    data2$showpct <- abs(data2$pct) >= 5 & data2$Category!=middle

  }

  VALUES <- rev(new_fillColor)
  names(VALUES) <- newlevels

  if (any(is.na(data[[varname]]))) {
    VALUES <- c(VALUES,na.value)
    names(VALUES)[length(names(VALUES))] <- missingLabel
    #categoryNames <- c(categoryNames,missingLabel)
    if (is.null(middle)) {
      categoryNames <- c(below,missingLabel,above)
    } else{
      categoryNames <- c(below,middle,missingLabel,above)
    }
  }

  data2$LabelColor <- getLabelColor(VALUES,data2$Category)

  if (!keepEmpty) {
    fillColor <- fillColor[names(VALUES) %in% data$Category]
  }

  RANGE <- data2 %>% group_by(grouping) %>% dplyr::summarize(sumneg=sum(pct[pct<0],na.rm=TRUE),sumpos=sum(pct[pct>0],na.rm=TRUE))


  positive <- data2 %>% dplyr::filter(CAT %in% c(middle_hi,above))
  negative <- data2 %>% dplyr::filter(CAT %in% c(below,middle_lo))
  positive_or_NA <- data2 %>% dplyr::filter(is.na(CAT) | CAT %in% c(middle_hi,above))

  POS <- data2 %>% dplyr::filter(CAT %in% above)
  NEG <- data2 %>% dplyr::filter(CAT %in% below)

  right <- tapply(positive$pct,positive$grouping,sum)
  left  <- tapply(negative$pct,negative$grouping,sum)

  right_or_NA <- tapply(positive_or_NA$pct,positive_or_NA$grouping,sum)

  RIGHT <- tapply(POS$pct,POS$grouping,sum)
  LEFT  <- tapply(NEG$pct,NEG$grouping,sum)

  leftright <- data.frame(grouping=names(left),left,LEFT,right,RIGHT,right_or_NA)

  ggplot(data=data2,
    aes(
      y=pct,
      fill=CAT,
      label=if_else(showpct,textfunc(pct,n,shown=shown), ""),
      color=LabelColor)) +
    geom_bar(aes(color=NULL,x=grouping),stat="identity",position=position_stack(),width=width) +
    scale_fill_manual(values = VALUES,breaks=categoryNames,na.value = na.value) +
    scale_color_manual(values=levels(data2$LabelColor)) +
    scale_x_discrete(expand=c(0,0),labels = function(x) stringr::str_wrap(x, width = labelwrap))+
    scale_y_continuous(expand=c(0.1,0.1))+
    geom_text(
      aes(x=grouping, y=pct),
      position = position_stack(vjust=.5), size=textsize)+
    (if (showtotals) {
      geom_text(data=leftright,
        aes(y=left,x=grouping,label=textfunc(-LEFT,n,shown=shown),fill=NULL,color=NULL),hjust=1.2, size=textsize)
    }) +
    (if (showtotals) {
      geom_text(data=leftright,
        aes(y=right_or_NA,x=grouping,label=textfunc(RIGHT,n,shown=shown),fill=NULL,color=NULL),hjust=-0.2, size=textsize)
    }) +
    ylab("")+
    xlab("")+
    guides(
      x="none",
      color="none") +
    theme(legend.position="bottom") +
    coord_flip() +
    geom_hline(yintercept=0,color="grey50",linewidth=1) +
    (if (!is.null(middle)) {
      geom_label(
        aes(x=grouping,y=0,fill=NULL,label=textfunc(pct,n,shown=shown)),data=mid,color="black",
       fill=VALUES[middle],label.size=NA,size=textsize)
    }) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.background = element_blank(),
      axis.text.x=element_blank(),
      axis.line.y = element_blank(),
      axis.line.x = element_blank(),
      legend.title = element_blank(),
      axis.ticks.y=element_blank(),
      axis.title=element_text(size=labelsize),
      axis.text=element_text(size=labelsize),
      legend.position="bottom",
      legend.text=element_text(size=labelsize),
      legend.margin=margin(0,0,0,0),
      legend.box.margin=margin(-10,0,0,0),
      #panel.border = element_rect(color = "red",fill = NA,size = 1),  # testing: box around graph
      #legend.background = element_rect(colour = "orange",size=1),     # testing: box around legend
      plot.margin=unit(c(0,0,0,0),"cm"))
}


#' @title DEPRECATED: Plot horizontal stacked bars of percentages of values of a variable by group
#' @description Fill colors corresponding to the values of the variable can be specified
#'              and the pieces of the horizontal stacked bars will be labeled to show
#'              frequency and percentage.
#'              For readability, the labels will be black of white according to
#'              the fill color.
#' @author Nick Barrowman
#' @param data         a data frame containing variables \code{grouping} and \code{pct}
#' @param varname      the name of a variable in the data frame.
#'                     Note that the variables \code{grouping} and \code{pct} must represent
#'                     the corresponding group values and percentages of this variable.
#' @param fillColor    a vector of colors, with names equal to the values of \code{var}
#' @param keepEmpty    keep values that are in \code{fillColor} but don't appear in \code{var}
#' @param labelwrap    Number of characters before wrapping an axis label
#' @param labelsize    Size of font for labels
#' @param textsize     Size of font for text
#' @param width        The width parameter in geom_bar
#' @param shown        Show sample size (as well as percentage)
#' @param na.value     Colour to use to show missing values
#' @param missingLabel Label to use for missing values
#'
#' @export
#'
plotbars <- function(data,varname,fillColor,keepEmpty=TRUE,labelwrap=20,width=0.8,
  labelsize=15,textsize=5,shown=TRUE,na.value="grey50",missingLabel="Missing") {
  
  message("This function is deprecated. Use the plotpctbars function instead.")
  

  if (any(is.na(data[[varname]]))) {
    fillColor <- c(fillColor,na.value)
    names(fillColor)[length(names(fillColor))] <- missingLabel
  }

  data$Category   <- factor(data[[varname]],levels=names(colorsPerCat))

  data$LabelColor <- getLabelColor(fillColor,data$Category)

  data$LabelColor[is.na(data$Category)] <-
    rep(ifelse(IsDark(na.value),'white','black'),sum(is.na(data$Category)))

  if (!keepEmpty) {
    fillColor <- fillColor[names(fillColor) %in% data$Category]
  }

  textfunc <- function(pct,n,shown) {
    if (shown) {
      paste0(around_func(pct, 0), "%", "\n (n=", n, ")")
    } else {
      paste0(around_func(pct, 0), "%")
    }
  }

  ggplot(
    data=data,
    mapping=aes(
      x=grouping, y=pct,
      label=if_else(abs(pct) >= 5,textfunc(pct,n,shown=shown), ""),
      fill=Category, color=LabelColor, group=grouping)) +
  geom_bar(
    aes(color=NULL), stat = "identity", width=width,
    position=position_stack(reverse=TRUE))+
  scale_fill_manual(values=fillColor,na.value=na.value)+
  scale_color_manual(values=levels(data$LabelColor))+
  scale_y_continuous(
    breaks=seq(0, 100, by=50), limits = c(0,100), expand = c(0,0))+
  scale_x_discrete(expand=c(0,0),labels = function(x) stringr::str_wrap(x, width = labelwrap))+
  geom_text(
    aes(grouping, pct),
            position = position_stack(vjust=.5), size=textsize)+
  ylab("")+
  xlab("")+
  guides(
    x="none",
    color="none") + #,
    #fill = guide_legend(reverse=T)) +
  coord_flip() +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.text.x=element_blank(),
    axis.line.y = element_blank(),
    axis.line.x = element_blank(),
    legend.title = element_blank(),
    axis.ticks.y=element_blank(),
    axis.title=element_text(size=labelsize),
    axis.text=element_text(size=labelsize),
    legend.position="bottom",
    legend.text=element_text(size=labelsize),
    legend.margin=margin(0,0,0,0),
    legend.box.margin=margin(-10,0,0,0),
    #panel.border = element_rect(color = "red",fill = NA,size = 1),  # testing: box around graph
    #legend.background = element_rect(colour = "orange",size=1),     # testing: box around legend
    plot.margin=unit(c(0,0,0,0),"cm"))
}






#' @title Convert a Windows path to a path on our Linux server, if necessary
#' @description If this function is executed on the Linux server,
#'              the path will be converted to the appropriate Linux server path.
#' @author Nick Barrowman
#' @param path  A windows path.
#'
#' @export
#'
LinuxWindowsPath <- function(path) {
  OS <- .Platform$OS.type
  if (OS=="unix") {
    path <- gsub("^J:/",path.expand("~/Jdrive/"),path)
    path <- gsub("^R:/",path.expand("~/Rdrive/"),path)
  }
  path
}


#' @title Render an Rmarkdown document
#' @author Nick Barrowman
#' @description Call \code{rmarkdown::render} with the option
#'              \code{knitr.in.progress} set to TRUE.
#'              This solves a problem that can occur when
#'              running (rather than knitting) the main R Markdown file.
#'              The problem occurs if the child R Markdown file calls
#'              a function that relies on knowing when knitting is taking place.
#'              (This has happened with \code{vtree} but it could
#'              happen in other situations.)
#' @param file  The path to the child R Markdown file.
#'
#' @export
#'
Render <- function(file,...) {
  output <- tryCatch(
    {
      kip <- options()$knitr.in.progress
      options(knitr.in.progress=TRUE)
      rmarkdown::render(file,...)
    },
    finally={
      options(knitr.in.progress=kip)
    }
  )
  output
}


#' @title Knit a child document
#' @author Nick Barrowman
#' @description Call \code{knitr::knit_child} with the option
#'              \code{knitr.in.progress} set to TRUE.
#'              This solves a problem that can occur when
#'              running (rather than knitting) the main R Markdown file.
#'              The problem occurs if the child R Markdown file calls
#'              a function that relies on knowing when knitting is taking place.
#'              (This has happened with \code{vtree} but it could
#'              happen in other situations.)
#' @param file  The path to the child R Markdown file.
#'
#' @export
#'
knitchild <- function(file) {
  output <- tryCatch(
    {
      kip <- options()$knitr.in.progress
      options(knitr.in.progress=TRUE)
      knitr::knit_child(file)
    },
    finally={
      options(knitr.in.progress=kip)
    }
  )
  output
}



svnStatus <- 
function (path = ".", show = TRUE, clip = 80) 
{
    wd <- getwd()
    setwd(path)
    out <- system(paste0("svn status"), intern = TRUE)
    setwd(wd)
    out <- substr(out, 1, clip)
    if (show) {
        cat(paste(out, collapse = "\n"))
    }
    invisible(out)
}
 

check_svn_modifications <- function(path=".") {
  status <- svnStatus(path,show=FALSE)
  out <- status
  out <- out[grep("^M",out)]
  out <- gsub("^M +()","\\1",out)
  out <- gsub("\\\\","/",out)

  modifications <- length(out)>0

  if (modifications) {

    mod <- file.info(paste0(path,"/",out))$mtime
    
    modified <- strftime(
      strptime(mod,format="%Y-%m-%d %H:%M:%S"),
      format="%d-%b-%Y %H:%M")
    
    list(
      modifications=modifications,
      data=data.frame(file=out,modified=modified))
  } else {
    list(
      modifications=modifications,
      data=NULL)
  }
}
 

#' @title Check other SVN working copies for modifications, etc.
#' @author Nick Barrowman
#' @description Check other SVN working copies for modifications, etc.
#' @details A file `other_wc.txt` lists paths to other SVN working copies.
#'          The file should be in the root folder for a project
#'
#' @export
#'
checkother <- function() {
  outRepo <-  system("svn info . -r HEAD",intern=TRUE)
  outRepo <- outRepo[grep("^Last Changed Rev: ",outRepo)]
  outRepo <- gsub("^Last Changed Rev: ","",outRepo)
  Reporev <- as.numeric(outRepo)
  
  cat("Repsitory revision:",Reporev,"\n")
  
  cat("\n")
  
  stat <- system("svn status -u -v",intern=TRUE)

  asterisk <- stat[grep("\\*",stat)]
  outdated <- length(asterisk)>0  

  if (outdated) {
    cat("SVN update needed.\n") 
  } else {
    cat("SVN Working copy is up to date.\n")
  }
  cat("\n")
    
  info <- system("svn info .",intern=TRUE)
  
  info <- info[
    grep("^(Working Copy Root Path|URL|Revision|Last Changed)",info)]
  
  cat(paste(info,collapse="\n"),"\n")
  
  cat("\n")
  paths <- read.delim("other_wc.txt",header=FALSE)[1,]
  for (path in paths) {
    cat(path,"\n")
    out <- check_svn_modifications(path)
    if (out$modification) {
      print(out$data)
    } else {
      cat("No modifications.\n")
    }
    cat("\n")
  }
}


#' @title SVN status
#' @author Nick Barrowman
#' @description Get status of an SVN working copy
#' @param path  The path to the working copy
#' @param show  Display the output?
#' @param clip  Number of columns at which to clip the output
#'
#' @export
#'
svnstatus <- function(path=".",show=TRUE,clip=80) {

  wd <- getwd()
  setwd(path)
  out <- system(paste0("svn status -u -v"),intern=TRUE)
  setwd(wd)

  out <- substr(out,1,clip)

  if (show) {
    cat(paste(out,collapse="\n"))
  }

  invisible(out)
}



#' @title Get SVN data
#' @author Nick Barrowman
#' @description Call SVN commands to obtain key information about the
#'              working copy and the repository.
#'
#' @export
#'
getSVNdata <- function() {
  #---------------------------------------------------------------------------

  outWC <- system("svn info ..",intern=TRUE)
  outWC <- outWC[grep("^Last Changed Rev: ",outWC)]
  outWC <- gsub("^Last Changed Rev: ","",outWC)
  WCrev <- as.numeric(outWC)

  outRepo <-  system("svn info .. -r HEAD",intern=TRUE)
  outRepo <- outRepo[grep("^Last Changed Rev: ",outRepo)]
  outRepo <- gsub("^Last Changed Rev: ","",outRepo)
  Reporev <- as.numeric(outRepo)

  # updateNeeded <- WCrev != Reporev

  #---------------------------------------------------------------------------

  out <- system("svn status -u -v",intern=TRUE)

  asterisk <- out[grep("\\*",out)]
  outdated <- length(asterisk)>0
  asterisk <- gsub("^ +","",asterisk)
  asterisk <- gsub("^M +","",asterisk)
  asterisk <- gsub("^\\* +","",asterisk)
  asterisk <- gsub(" ","&nbsp;",asterisk)

  out <- out[grep("^M",out)]
  out <- gsub("^ +","",out)
  out <- gsub("^M +","",out)
  out <- gsub("^\\* +","",out)
  modified <- length(out)>0

  modifiedFiles <- gsub(" ","&nbsp;",out)

  #---------------------------------------------------------------------------

  # log <- system("svn log .. -v -r HEAD:1 --limit 4",intern=TRUE)

  logHEAD <- system("svn log .. -v -r HEAD",intern=TRUE)

  #---------------------------------------------------------------------------

  dir <- ".."
  tree <- shell(paste("tree",dir,"/f /a"),intern=TRUE)
  tree <- tree[-(1:2)]
  tree <- gsub(" ","&nbsp;",tree)
  tree <- gsub("^\\\\","| SPECIALCODEHERE \\\n+",tree)
  tree <- gsub("\\\\","/",tree)
  tree <- gsub("SPECIALCODEHERE","\\",tree)

  #---------------------------------------------------------------------------

  # list <- system("svn list .. --recursive --verbose",intern=TRUE)
  list <- system("svn list -r HEAD -R -v ..",intern=TRUE)

  list <- gsub(" ","&nbsp;",list)

  #---------------------------------------------------------------------------

  list(
    outdated=outdated,
    asterisk=asterisk,
    WCrev=WCrev,
    Reporev=Reporev,
    #updateNeeded=updateNeeded,
    modified=modified,
    modifiedFiles=modifiedFiles,
    logHEAD=logHEAD,
    list=list,
    tree=tree)
}


#' @title Show SVN status
#' @author Nick Barrowman
#' @description Using data from \code{getSVNdata},
#'              show SVN status.
#' @param data      Data from \code{getSVNdata}.
#'
#' @export
#'
showSVNstatus <- function(data) {
  cat("\n")
  cat("## SVN status\n\n")
  cat("* Repository revision",data$Reporev,"\n\n")

#  if (data$updateNeeded) {
#    cat("* **SVN update needed.** ([see details below](#SVNrevisions))\n\n")
#  } else {
#    cat("* SVN working copy is up to date\n\n")
#  }

  if (data$outdated) {
    cat("* **SVN update needed.** ([see details below](#SVNrevisions))\n\n")
  } else {
    cat("* SVN working copy is up to date\n\n")
  }

  if (data$modified) {
    cat("* **Some files under SVN control have been modified.** ([see details below](#SVNmods))\n\n")
  } else {
    cat("* No files under SVN control have been modified\n\n")
  }
}


#' @title Show SVN details
#' @author Nick Barrowman
#' @description Using data from \code{getSVNdata},
#'              show SVN details.
#' @param data      Data from \code{getSVNdata}.
#'
#' @export
#'
showSVNdetails <- function(data) {


#  if (data$WCrev==data$Reporev) {
#    cat("Both working copy and repository are at revision ",data$Reporev,".\\\n",sep="")
#  } else {
#    cat(paste0(
#      "Working copy is at revision ",data$WCrev,". ",
#      "Repository is at revision ",data$Reporev,
#      "\\\n"))
#    cat("\nMost recent commit to repository:\n\n")
#    cat(paste(data$logHEAD,"\\\n"))
#  }

  if (data$outdated) {
    cat("\n")
    cat("## Files with a newer version in the repository\n\n")
    cat("working revision \\#, last committed revision \\#, last committed author, filename\n\n")

    cat(paste("> ",data$asterisk,"\\\n"),"\n\n")
  }


   cat("\n## Most recent commit to SVN repository\n\n")
   cat(paste("> ",data$logHEAD,"\\\n"))


  if (data$modified) {
    cat("\n")
    cat("## Files under SVN control that have been modified {#SVNmods}\n\n")
    cat("working revision \\#, last committed revision \\#, last committed author, filename\n\n")

    cat(paste("> ",data$modifiedFiles,"\\\n"),"\n\n")
  }

  cat("\n## List of files in the SVN repository\n\n")

  cat(paste("> ",data$list,"\\\n"),"\n\n")


  cat("## Directory tree\n\n")

  cat("Note that not all files may be under SVN control.\n\n")
  cat(paste("> ",data$tree,"\\\n"))
}

#' @title Show directory tree
#' @author Nick Barrowman
#' @description Show the output of the Microsoft Windows tree command.
#'              The output is in Markdown format and should be included as-is.
#'
#' @export
#'
showDirTree <- function(dir) {
  thing <- shell(paste("tree",dir,"/f /a"),intern=TRUE)
  thing <- thing[-(1:2)]
  thing <- gsub(" ","&nbsp;",thing)
  thing <- gsub("^\\\\","| SPECIALCODEHERE \\\n+",thing)
  thing <- gsub("\\\\","/",thing)
  thing <- gsub("SPECIALCODEHERE","\\",thing)
  cat(paste("> ",thing,"\\\n"),"\\\n")
}

#' @title Show SVN log
#' @author Nick Barrowman
#' @description Show the SVN log information
#'
#' @export
#'
showSVNlog <- function(style="SmallFixedFont") {
  options(warn = -1)
  log <- system("svn log .. -v -r HEAD:1 --limit 4",intern=TRUE)
  cat(paste(log,"\\\n"),"\n")
}

#' @title Show SVN list
#' @author Nick Barrowman
#' @description Show the SVN list information
#'
#' @export
#'
showSVNlist<- function() {
  options(warn = -1)
  log <- system("svn list .. --recursive --verbose",intern=TRUE)
  log <- gsub(" ","&nbsp;",log)
  cat(paste("> ",log,"\\\n"),"\\\n")
}


#' @title Show SVN files that have been modified
#' @author Nick Barrowman
#' @description Show SVN files that have been modified
#'
#' @export
#'
showSVNmodified <- function() {
  out <- system("svn status -u -v",intern=TRUE)
  out <- out[grep("^M",out)]
  out <- gsub(" ","&nbsp;",out)
  out <- gsub("^M +","",out)
  cat(paste("> ",out,"\\\n"),"\\\n")
}


#' @title Check if an SVN update is needed
#' @author Nick Barrowman
#' @description Check whether SVN repo revision equals working copy revision
#'
#' @export
#'
checkSVNupdateNeeded <- function() {
  outWC <- system("svn info ..",intern=TRUE)
  outWC <- outWC[grep("^Last Changed Rev: ",outWC)]
  outWC <- gsub("^Last Changed Rev: ","",outWC)
  WCrev <- as.numeric(outWC)

  outRepo <-  system("svn info .. -r HEAD",intern=TRUE)
  outRepo <- outRepo[grep("^Last Changed Rev: ",outRepo)]
  outRepo <- gsub("^Last Changed Rev: ","",outRepo)
  Reporev <- as.numeric(outRepo)

  if (WCrev==Reporev) {
    cat("Both working copy and repository are at revision",Reporev,"\\\n")
  } else {
    cat(paste0(
      "**Working copy needs to be updated.**\\\n",
      "(Working copy is at revision ",WCrev,". ",
      "Repository is at revision ",Reporev,")",
      "\\\n"))
  }
}


#' @title Output css for automated README file generator
#' @author Nick Barrowman
#' @description Write CSS
#'
#' @export
#'
cssREADME <- function() {
  cssString <- "
  <style type='text/css'>
    h1.title{ font-size: 14pt; font-weight:bold; margin-bottom: 0px; color: #002db3;}
    h2{ font-size: 12pt; font-weight:bold; color: #0033cc;}
    h3.subtitle{ font-size: 10pt; font-family: consolas; margin-top: 10px;}
    h4.date{ font-size: 9pt; font-style:italic; }
    blockquote { font-size: 8pt; font-family: consolas; }
    body{ font-size: 10pt; }
    pre, code {
      font-family: consolas;
     #font-weight: bold;
      font-size: 9pt;
      background-color: #DDDDDD;
      border-radius: 3px;
      color: #333;
      white-space: pre-wrap;    /* Wrap long lines */
    }

  table {
      margin-left: auto;
      margin-right: auto;
      margin-bottom: 24px;
      border-spacing: 0;
      border-bottom: 2px solid #BBBBBB;
      border-top: 2px solid #BBBBBB;
  }
  table th {
      padding: 3px 10px;
      background-color: #E6ECFF;
      border-top: none;
      border-left: none;
      border-right: none;
      border-bottom: 2px solid #BBBBBB;
  }
  table td {
      padding: 3px 10px;
      border-top: none;
      border-left: none;
      border-bottom: none;
      border-right: none;
  }
  </style>
  "
  cat(cssString)
}


#' @title Configuration query
#' @author Nick Barrowman
#' @description Save configuration details to a file
#'
#' @export
#'
config <- function() {
  # vdf <- data.frame(Name=names(version),Version=as.character(version))
  vdf <- data.frame(Name="R.version.string",Version=R.version.string)
  vdf <- rbind(vdf,Name="RStudio",Version=rtstudioapi::versionInfo())
  p   <- installed.packages()
  pdf <- data.frame(Name=x[,"Package"],Version=x[,"Version"])
  x <- rbind(vdf,pdf)
  write.csv(x,"InstalledPackages.csv",row.names=FALSE)
}



#' @title File Explorer (Windows)
#' @author Nick Barrowman
#' @description Open Windows file explorer in current working directory
#'
#' @export
#'
fe <- function() {
  #
  # Open Windows file explorer in current working directory
  #
  wd <- getwd()
  wd <- gsub('"', "", gsub("/", "\\\\", wd))
  withQuotes <- paste0('"',wd,'"')

  shell.exec(withQuotes)
}



#' @title reproduciblity
#' @author Nick Barrowman
#' @description Show markdown information for reproducibility
#'
#' @export
#'
reproducibility <- function(style="SmallFixedFont",columns=1) {
  if (isTRUE(getOption("knitr.in.progress"))) {
    stylecode <- paste0("{custom-style=\"",style,"\"}")

    cat("#########\n\n")

    cat("#### Information included for reproducibility purposes\n\n")

    cat("[",strftime(Sys.time(),format="%d-%b-%Y at %H:%M"),"]",
      stylecode,"\\\n",sep="")

    currentDir <- getwd()
    currentDir <- gsub("\\[","&#91;",currentDir)
    currentDir <- gsub("\\]","&#93;",currentDir)
    
    cat("[",currentDir,"/",knitr::current_input(dir = FALSE),"]",stylecode,sep="")

    cat("\n\n")

    cat("##### SVN\n\n")

    showSVNinfo(style)
    cat("\n\n")

    cat("##### platform from devtools::session_info()\n\n")

    cat("[")
    cat(paste(fixtxt(capture.output(devtools::session_info()$platform)),collapse="\\\n"),sep="")
    cat("]",stylecode,sep="")

    cat("\n\n")
    cat("##### packages from devtools::session_info()\n\n")

    thang <- capture.output(devtools::session_info()$package)
    cat("[")
    cat(fixtxt(paste0(
      apply(makeColumns(padSpaces(thang),columns),1,
        function(x) paste(x,collapse="&nbsp;&nbsp;&nbsp;")),
      "\n")),sep="")
    cat("]",stylecode,"\n",sep="")
  }
}


#' @title Show SVN info
#' @author Nick Barrowman
#' @description Show the SVN info
#'
#' @export
#'
showSVNinfo <- function(style="SmallFixedFont") {
  stylecode <- paste0("{custom-style=\"",style,"\"}")

  svninfo <- system("svn info",intern=TRUE)
  
  if (is.null(svninfo)) {
    cat("[command svn info not available.]",stylecode,sep="")
    return(NULL)
  }

  options(warn = -1)
  RepoPath <- system("svn info --show-item repos-root-url",inter=TRUE)
  if (length(RepoPath) == 0) {
    cat("[Not under SVN version control.]",stylecode,sep="")
    Revision <- ""
  }
  else {
    RepoPath <- gsub("\\[","&#91;",RepoPath)
    RepoPath <- gsub("\\]","&#93;",RepoPath)
    RepoPath <- gsub(":","&#58;",RepoPath)
    cat("[**SVN version control information**]",stylecode,"\\\n",sep="")

    cat("[**Repository URL**: ",
      RepoPath, "]",stylecode,"\\\n",sep="")
    WCroot <- system("svn info --show-item wc-root",inter = TRUE)
    displayWCroot <- gsub("\\[","&#91;",WCroot)
    displayWCroot <- gsub("\\]","&#93;",displayWCroot)
    cat("[**Working copy root**: ",displayWCroot, "]",stylecode,"\\\n",sep="")
    Revision <- system(paste0("svn info --show-item=revision ", "\"",
      WCroot, "\""), inter = TRUE)
    cat(paste0("[",
      paste("Revision:",Revision,collapse="\\\n")),"]",stylecode,sep="")    
  }
  options(warn = 0)
}


#' @title Show SVN version
#' @author Nick Barrowman
#' @description Show the version (and note any changes) of SVN
#'
#' @export
#'
showSVNversion <- function() {

  svninfo <- system("svn info",intern=TRUE)
  
  if (is.null(svninfo)) {
    cat("[command svn info not available.]",stylecode,sep="")
    return(NULL)
  }

  options(warn = -1)
  RepoPath <- system("svn info --show-item repos-root-url",inter=TRUE)
  if (length(RepoPath) == 0) {
    cat("[Not under SVN version control.]",stylecode,sep="")
    Revision <- ""
  }
  else {
    changes <- ifelse(length(grep("^[AMCDG]",system("svn status",intern=TRUE)))>0,
      " with changes","")
    WCroot <- system("svn info --show-item wc-root",inter = TRUE)
    Revision <- system(paste0("svn info --show-item=revision ", "\"",
      WCroot, "\""), inter = TRUE)
    LCDate <- system(paste0("svn info -r HEAD --show-item=last-changed-date ", "\"",
      WCroot, "\""), inter = TRUE)
    LCDate <- strftime(
      as.POSIXct(strptime(LCDate,format="%Y-%m-%dT%H:%M:%S"),tz="UTC"),
      format="[last commit %d-%b-%Y at %H:%M]")
    Revision <- paste("rev",paste0(Revision,changes),LCDate,collapse="\\\n")    
  }
  options(warn = 0)
  Revision
}


padSpaces <- function(x) {
  nc <- nchar(x)
  maxnc <- max(nc)
  for (i in 1:length(x)) {
    x[i] <- paste0(x[i],paste(rep(" ",maxnc-nc[i]),collapse=""))
  }
  x
}

makeColumns <- function(x,cols) {
  n <- length(x)
  rows <- ceiling(length(x)/cols)
  result <- matrix("",nrow=rows,ncol=cols)
  for (i in 1:cols) {
    indices <- 1:rows+(i-1)*rows
    fill <- c(x[indices[indices<=n]],rep("",sum(indices>n)))
    result[,i] <- fill
  }
  result
}


fixtxt <- function(x) {
  x0 <- gsub("^ (.*)","\\1",x)
  x1 <- gsub(" ","&nbsp;",x0)
  x2 <- gsub("\\n","\\\\\\\n",x1)
  x3 <- gsub("\\*","&ast;",x2)
  x4 <- gsub("@","&commat;",x3)
  x5 <- gsub("%","&dollar;",x4)
  x5
}







VV <- function (x,quiet = TRUE, linebreak = "LINEBREAKCODE") {
    pastedText <- x
    pt <- paste(pastedText, collapse = linebreak)
    out <- ""
    w <- pt
    done <- FALSE
    while (!done) {
        pos <- regexpr("`r [^`]+`", w)
        if (pos == -1) {
            out <- paste(out, w)
            done <- TRUE
        }
        else {
            left <- substr(w, 1, pos - 1)
            out <- paste0(out, left)
            n <- attr(pos, "match.length")
            x <- substr(w, pos, pos + n - 1)
            r <- gsub("`r ([^`]+)`", "\\1", x)
            r <- gsub(linebreak, "", r)
            rOut <- eval(parse(text = r), envir = parent.frame(n = 2))
            out <- paste0(out, rOut)
            if ((pos + n) == length(w)) {
                done <- TRUE
            }
            else {
                right <- substr(w, pos + n, nchar(w))
                w <- right
            }
        }
    }
    result <- gsub(linebreak, "\n", out)
    # cat(result)
    result <- paste0("---\npagetitle: markdown rendered by CRUmarkdown::vv\n---\n\n",
        result)
    dir <- tempfile()
    dir.create(dir)
    mdFile <- file.path(dir, "source.md")
    cat(result, file = mdFile)
    rmarkdown::render(mdFile, "html_document", output_file = "index.html",
        output_dir = dir, quiet = quiet)
    htmlFile <- file.path(dir, "index.html")
    rstudioapi::viewer(htmlFile)
    invisible(NULL)
}


#' @title kc
#' @author Nick Barrowman
#' @description Knit clipboard
#' @param verbose   Show extra information?
#' @param show      Show the text?
#' @param source    Source in the text as R code?
#' @param copy      Copy the text to the Clipboard? (Default=\code{TRUE})
#' @param knit      Knit the text as R Markdown
#'
#' @export

kc <- function(show=FALSE,knit=TRUE,quiet=FALSE) {
  if (!is.null(options()$vtree_folder)) {
    options(vtree_folder=NULL)
    message("Reset vtree_folder.")
  }
  if (!is.null(options()$vtree_count)) {
    options(vtree_count=NULL)
    message("Reset vtree_count.")
  }  
  
  savedOptions <- options()
  
  stuff <- rstudioapi::getSourceEditorContext()$selection[[1]]$text
  if (stuff=="") stop("Please select code to knit")
  
  message("--->",stuff,"<---","\n")
  stuff <- utf8::as_utf8(stuff)

  #
  # Now perform output
  #
  if (show) {
    cat(stuff,sep="\n")
  }
  if (knit) {
    newstuff <- paste0(
      "---\npagetitle: markdown rendered by kc function\n---\n\n",
      paste(stuff,collapse="\n"))
    dir <- tempfile()
    dir.create(dir)
    RmdFile <- file.path(dir, "source.Rmd")
    cat(newstuff,sep="\n",file = RmdFile)
    cat(newstuff,sep="\n")
    rmarkdown::render(RmdFile, "html_document", output_file = "index.html",
        output_dir = dir, knit_root_dir = getwd(), quiet = quiet, envir=parent.frame(2))
    htmlFile <- file.path(dir, "index.html")
    rstudioapi::viewer(htmlFile)
    invisible(NULL)
  }
  
  # Reset options to how they were before this function was called.
  # This is a bit tricky because new options can't be easily removed.
  # Instead, it is necessary to find new options, and then
  # on exit, reset options and then remove the new ones one by one.
  
  currentOptions <- options()
  addedOptionNames <- names(currentOptions)[!(names(currentOptions) %in% names(savedOptions))]
  
  on.exit(
    {
      options(savedOptions)
      if (length(addedOptionNames)>0) {
        for (op in addedOptionNames) { 
          li <- list(NULL)
          names(li) <- op
          options(li)
        }
      }
    }
  )
}


#' @title gd
#' @author Nick Barrowman
#' @description Read in text from Google Drive
#' @param filename  URL for a Google Doc
#'                  (can also be specified using
#'                  \code{options(gd.filename="MyURL")}
#' @param verbose   Show extra information?
#' @param show      Show the text?
#' @param source    Source in the text as R code?
#' @param copy      Copy the text to the Clipboard? (Default=\code{TRUE})
#' @param knit      Knit the text as R Markdown
#' @details
#' When you first use \code{gd}, your browser will be directed to
#' a web page to authorize the googledrive package to access the file in question.
#' Later, you may be asked again:
#' "The googledrive package is requesting access to your Google account.
#' Select a pre-authorised account or enter '0' to obtain a new token."
#'
#'
#' @export

gd <- function(filename,verbose=FALSE,show=FALSE,source=FALSE,copy=TRUE,knit=FALSE) {
  if (missing(filename)) filename <- options()$gd.filename

  if (is.null(filename)) stop('File not specified. Use: options(gd.filename="URL-from-Google-Drive")')

  temp <- tempfile()
  googledrive::drive_download(filename,type="text",path=temp,overwrite=TRUE,verbose=verbose)
  filename <- paste0(temp,".txt")
  con <- file(filename,"r",method="default",encoding="UTF-8-BOM")
  if (verbose) {
    stuff <- readLines(con)
  } else {
    stuff <- suppressWarnings(readLines(con))
  }
  close(con)
  #
  # Now fix problem with repeat blank lines
  #
  newstuff <- c()
  lastblank <- FALSE
  for (i in 1:length(stuff)) {
    if (lastblank) {
      if (stuff[i]!="") newstuff <- c(newstuff,stuff[i])
      lastblank <- FALSE
    } else {
      if (stuff[i]=="") lastblank <- TRUE
      newstuff <- c(newstuff,stuff[i])
    }
  }
  #
  # Now perform output
  #
  if (copy) {
    writeClipboard(newstuff)
    cat("Copied",length(newstuff),"lines to clipboard.\n")
  }
  if (show) {
    cat(newstuff,sep="\n")
  }
  if (source) {
    source(exprs=parse(text=newstuff),print.eval=TRUE) #,echo=TRUE)
  }
  if (knit) {
    VV(newstuff)
  }
}


#' @title bb
#' @author Nick Barrowman
#' @description Make a boxbee within an R Markdown document.
#' @param varname Name of variable
#' @param data Data frame
#'
#' @export

bb <- function(varname,data) {
  if (mode(data[[varname]])=="numeric") {
    value <- data[[varname]]
    codes <- NULL
  } else {
    wsave <- options()$warn
    options(warn=-1)
    value <- as.numeric(data[[varname]])
    options(warn=wsave)
    nonnumeric <- data[[varname]][is.na(value)]
    codes <- paste(nonnumeric,collapse=", ")
  }
  par(las=1,mar=c(1,5,1,1))
  boxbee(value)
  #if (length(vlab)==0) vlab <- paste0(varname," [no label available]")
  #title(vlab)
  nmiss <- sum(is.na(value))
  if (nmiss>0) {
    missval <- paste0(nmiss," missing values")
  } else {
    missval <- ""
  }
  if (!is.null(codes)) {
    cat("  \n  \n**Non-numeric codes**: ")
    cat(codes,"\n")
  }
  numValues <- length(value)
  numMissing <- sum(is.na(value))
  numZero <- sum(value==0,na.rm=TRUE)
  if (numMissing==numValues) {
    cat(paste0("\n\nAll ",numValues," values are missing.\n"))
  } else {
    cat(paste0("\n\nN=",length(value)," "))
    if (numZero==0) {
      if (numMissing==0) {
        cat("(no missing, no zeros)")
      } else {
        cat(paste0(
          "(",sum(is.na(value))," missing, no zeros)"))
      }
    } else {
      if (numMissing==0) {
        cat("(no missing, ",numZero," zeros)")
      } else {
        cat(paste0(
          "(",sum(is.na(value))," missing, ",numZero," zeros)"))
      }
    }
    cat(paste0(" ---",
      "    Mean (SD): ",meanSD(value),
      ",   Median (IQR): ",medianIQR(value),
      ",   range: ",
        around(min(value,na.rm=TRUE),digits=1)," - ",
        around(max(value,na.rm=TRUE),digits=1)),
      "\n")
  }
}



#' @title col
#' @author Nick Barrowman
#' @description show frequencies and percentages (listed in a column)
#' @param x    variable name
#' @param vlab variable label
#' @param data data frame
#'
#' @export

coltab <- function(x,vlab="",data) {
  vlab <- gsub("\\_","\\\\_",vlab)
  pipetablecol(data[[x]],rowvarname=vlab,showmisscol=FALSE,showNcol=FALSE)
}



#' @title summarizeREDCap
#' @author Nick Barrowman
#' @description Automatically summarize a REDCap database in an R Markdown document.
#' @param data            Data frame
#' @param numbering       Try to count variables to correspond with the numbering in the codebook
#' @param desc            Vector that identifies descriptive fields based on field number in the codebook
#' @param notInCodebook   Vector that identifies files that will not appear in the codebook
#' @param maxFactorLevels Maximum number of levels of a factor to show
#' @param verbose         Give message listing each variable in turn
#' @details Should be called inline
#'          or in a code chunk using chunk option \code{result="asis"}
#'
#' @export

summarizeREDCap <- function(data,vars,numbering=FALSE,desc=NULL,
  notInCodebook=c("redcap_data_access_group","redcap_event_name",
    "redcap_repeat_instrument","redcap_repeat_instance"),
  maxFactorLevels=15,
  verbose=TRUE) {

  if (missing(vars)) vars <- names(data)

  j <- 0 # count of variable number (attempt to line up with codebook)
  insideChecklist <- FALSE
  for (i in 1:ncol(data)) {
    x <- names(data)[i]

    if (x %in% vars) {

      while ((j+1) %in% desc) {
        j <- j+1

        if (numbering) {
          cat("\n##",j," --- Descriptive field ---\n")
          if (verbose) message(paste(j," --- Descriptive field ---","column",i))
        }
      }

      if (length(grep("\\.factor",x))==0) {
        lab <- label(data[[x]])
        j <- j+1

        if (numbering) {
          if (verbose) message(paste(j,x,"- column",i))
        } else {
          if (verbose) message(paste(x,"- column",i))
        }

        #
        # Handle numbering of checklist items
        #
        if (length(grep("\\.factor",x))==0) {
          if (length(grep("___[0-9l]+$",x))==1) {
            numberStr <- gsub("(.+___)([0-9l]+)$","\\2",x)
            if (!(numberStr %in% c("1","l"))) {
              if (insideChecklist) {
                j <- j-1
              }
            }
            insideChecklist <- TRUE
          } else {
            insideChecklist <- FALSE
          }
        }

        if (x %in% notInCodebook) {
          j <- j-1
          cat("\n##",lab,"--",x,"\n\n")
        } else {
          if (numbering) {
            cat("\n##",j,lab,"--",x,"\n\n")
          } else {
            cat("\n##",lab,"--",x,"\n\n")
          }
        }
        # Check if it's a time
        t <- strptime(data[[x]],format="%H:%M")
        # Check if it's an ISO date
        d <- strptime(data[[x]],format="%Y-%m-%d")
        if (any(!is.na(t))) {
          hours <- as.numeric(strftime(t,"%H"))+as.numeric(strftime(t,"%M"))/60
          minutes <- hours*60
          cat(paste0("Range (hours) =",
            round(min(hours,na.rm=TRUE),1)," to ",
            round(max(hours,na.rm=TRUE),1),".  "))
          cat(paste0("Range (minutes) =",
            min(minutes,na.rm=TRUE)," to ",
            max(minutes,na.rm=TRUE),".\n"))
        } else
        if (any(!is.na(d))) {
          cat("Range =",
            strftime(min(d,na.rm=TRUE),"%Y-%m-%d")," to ",
            strftime(max(d,na.rm=TRUE),"%Y-%m-%d"),"\n")
        } else
        if (is.factor(data[[x]]) && length(levels(data[[x]]))>maxFactorLevels) {
          cat("Number of levels =",length(levels(data[[x]])),"\n")
          next
        } else {
          factorVersion <- paste0(x,".factor")
          if (any(names(data)==factorVersion)) {
            x <- factorVersion
          }
          val <- data[[x]]
          if (is.numeric(val) & length(unique(val))>maxFactorLevels) {
            bb(x,data=data)
          } else {
            if (length(unique(val))<=maxFactorLevels) {
              cat(coltab(escapeSymbols(x),vlab=x,data=data))
            } else {
              cat("Number of discrete values =",length(unique(val)),"\n")
            }
          }
          cat("\n")
        }
      } # end if (length(grep("\\.factor",x))==0)
    } # end  if (x %in% vars)
  } # end for (i in 1:ncol(data))
}


#' @title showcol
#' @author Nick Barrowman
#' @description Show colors.
#' @param col       Part of a color name.
#'
#' @export

showcol <- function(col) {
  co <- colors()[grep(col,colors())]
  thickness <- floor(400/length(co))
  par(mar=c(1,8,1,1))
  par(las=1)
  plot(0,0,type="n",xlim=c(0,1),ylim=c(1,length(co)),axes=FALSE,xlab="",ylab="")
  mtext(co,line=0,side=2,at=1:length(co),cex=0.7)
  for (i in 1:length(co)) { segments(0,i,1,i,col=co[i],lwd=thickness) }
}



#' @title readREDCap
#' @author Vid Bijelic
#' @description Use the redcapAPI package to download a REDCap database with factors and numeric values.
#' @details
#' The function makes two calls to the redcapAPI::exportRecords function:
#' (1) a call with \code{factors=FALSE} which represents factors using numeric codes, and
#' (2) a call with \code{factors=TRUE} which uses factors.
#' These are renamed with the suffix \code{.factor} to be consistent with the
#' R databases downloaded manually from REDCap.
#' @section Accessing the REDCap API for a project:
#' First, the REDCap administrator has to enable the API for a specific project.
#' Once this is done, go into the project and click API in the sidebar.
#' Then click the button to request a new token.
#' The REDCap administrator will need to approve this request.
#' The token is like a password and must be kept securely in a folder nobody else can normally access
#' (your J drive is ideal).
#' @section REDCap API Documentation:
#' For more information on the REDCap API, see \url{https://redcap.cheori.org/api/help/}
#' @param api_token       (Required) API token provided by REDCap administrator.
#' @param api_url         URL to the REDCap API server.
#' @param checkboxLabels  Should checkbox variables have labels based on their contents
#'                        (instead of "CHECKED" and "UNCHECKED")?
#' @param omit            Vector of variable names that should be omitted.
#'
#' @examples
#' # First read the token from a CSV file in secure personal folder
#' # In this example the CSV file contains several tokens,
#' # each one associated with a database pid (REDCap project id).
#' # In particular it has columns called \code{pid} and \code{token}.
#' tokensDF <- read.csv("J:/tokens/tokens.csv",as.is=TRUE)
#
#' # Let's get data from the project with pid 5555
#' z <- readREDCap(tokensDF$token[tokensDF$pid=="5555"])
#' dim(z)
#'
#' @export

readREDCap <- function(api_token, api_url = "https://redcap.cheori.org/api/",
  checkboxLabels = FALSE, omit=NULL, config=httr::config(), ...) {

  rcon <- redcapAPI::redcapConnection(url = api_url, token = api_token, config = config)

  rdat.i <- redcapAPI::exportRecords(rcon, factors = FALSE, ...)
  rdat.i <- suppressWarnings(dplyr::select(rdat.i,-one_of(omit)))

  rdat.f <- redcapAPI::exportRecords(rcon, factors = TRUE, checkboxLabels = checkboxLabels, ...)
  rdat.f <- suppressWarnings(dplyr::select(rdat.f,-one_of(omit)))

  add.dot.factor <- function(x) { paste0(x,".factor") }

  cbind(rdat.i,dplyr::rename_all(rdat.f,function(x) paste0(x,".factor")))
}


#' @title readREDCapNew
#' @author Vid Bijelic, Nick Barrowman
#' @description Use the redcapAPI package to download a REDCap database with factors and numeric values.
#' @details
#' The function makes two calls to the redcapAPI::exportRecords function:
#' (1) a call with \code{factors=FALSE} which represents factors using numeric codes, and
#' (2) a call with \code{factors=TRUE} which uses factors.
#' These are renamed with the suffix \code{.factor} to be consistent with the
#' R databases downloaded manually from REDCap.
#' @section Accessing the REDCap API for a project:
#' First, the REDCap administrator has to enable the API for a specific project.
#' Once this is done, go into the project and click API in the sidebar.
#' Then click the button to request a new token.
#' The REDCap administrator will need to approve this request.
#' The token is like a password and must be kept securely in a folder nobody else can normally access
#' (your J drive is ideal).
#' @section REDCap API Documentation:
#' For more information on the REDCap API, see \url{https://redcap.cheori.org/api/help/}
#' @param api_token       (Required) API token provided by REDCap administrator.
#' @param api_url         URL to the REDCap API server.
#' @param checkboxLabels  Should checkbox variables have labels based on their contents
#'                        (instead of "CHECKED" and "UNCHECKED")?
#' @param omit            Vector of variable names that should be omitted.
#'
#' @examples
#' # First read the token from a CSV file in secure personal folder
#' # In this example the CSV file contains several tokens,
#' # each one associated with a database pid (REDCap project id).
#' # In particular it has columns called \code{pid} and \code{token}.
#' tokensDF <- read.csv("J:/tokens/tokens.csv",as.is=TRUE)
#
#' # Let's get data from the project with pid 5555
#' z <- readREDCap(tokensDF$token[tokensDF$pid=="5555"])
#' dim(z)
#'
#' @export

readREDCapNew <- function (api_token, api_url = "https://redcap.cheori.org/api/",
  checkboxLabels = FALSE, omit=NULL, config=httr::config(), ...) {

  rcon <- redcapAPI::redcapConnection(url = api_url, token = api_token, config = config)

  rdat.i <- redcapAPI::exportRecordsTyped(rcon, ...)
  rdat.i <- suppressWarnings(dplyr::select(rdat.i,-one_of(omit)))

  rdat.i
}



#' @title readPeriodicREDCap
#' @author Vid Bijelic, Nick Barrowman
#' @description Use the \code{readREDCap} function to download a REDCap database only if specified time (in hours) has passed.
#' @details
#' Whenever this function imports data from REDCap it caches it to a local RDS file.
#' The next time the function is run, it checks the cached copy to determine
#' whether sufficient time has elapsed to re-import from REDCap;
#' otherwise it uses the cached version.
#'
#' @section REDCap API Documentation:
#' For more information on the REDCap API, see \url{https://redcap.cheori.org/api/help/}
#' @param api_token    (Required) API token provided by REDCap administrator.
#' @param REDCapPid    REDCap project ID
#' @param updateHours  Number of hours before REDCap database should be imported again.
#' @param printHours   Show number of hours since database was imported.
#' @param rdsLoc       Path to the RDS file
#' @param omit         Vector of variable names that should be omitted.
#' @param recent       1=most recent RDS file, 2=2nd most recent, etc.
#'                     If recent>1 the the REDCap database will not be imported again.
#' @param remove_class_labelled Run remove_class_labelled?
#' @param remove_class_redcapFactor Run remove_class_redcapFactor?
#' @param new          Call readREDCapNew instead of readREDCap?
#' @param ...          Additional parameters passed to \code{readREDCap}
#'
#' @return
#' List with the following components
#' \item{data}{The data frame}
#' \item{source}{\code{"REDCap"} if the data was newly imported from REDCap;
#'       \code{"Cached"} if the data was imported from a cached local file.}
#' \item{when}{an object of class \code{"POSIXct"}: When was the data originally imported from REDCap?}
#'
#' @seealso \code{readREDCap}
#'
#' @examples
#' # First read the token from a CSV file in secure personal folder
#' # In this example the CSV file contains several tokens,
#' # each one associated with a database pid (REDCap project id).
#' # In particular it has columns called \code{pid} and \code{token}.
#' tokensDF <- read.csv("J:/tokens/tokens.csv",as.is=TRUE)
#'
#' original <- readPeriodicREDCap(api_token=tokensDF$token[tokensDF$pid=="3057"],
#'              REDCapPid="3057", rdsLoc ="J:/RCData/3057",updateHours=24)
#' @export

readPeriodicREDCap <- function (api_token, REDCapPid, updateHours = 24,
  printHours = FALSE, rdsLoc = ".", omit=NULL, recent=1, 
  remove_class_labelled=FALSE, remove_class_redcapFactor=FALSE, new=FALSE, config=httr::config(), ...) {

  allfiles <- list.files(rdsLoc,full.names=TRUE)
  if (length(allfiles)>0) {
    info <- file.info(allfiles)
    o <- rev(order(info$mtime))
    # Sort from most recent to least recent
    info <- info[o,]

    mostRecent <- rownames(info)[recent]

    rdsTime <- info[recent,"mtime"]
    
    sinceTime <- as.numeric(difftime(Sys.time(), rdsTime, units = "hours"))
  } else {
    sinceTime <- Inf
  }

  if ((recent==1) & (sinceTime >= updateHours)) {
    Now <- Sys.time()
    if (new) {
      data <- readREDCapNew(api_token = api_token,omit=omit, config=config, ...)
    } else {
      data <- readREDCap(api_token = api_token,omit=omit, config=config, ...)
    }
    if (remove_class_labelled) {
      data <- CRUmisc::remove_class_labelled(data)
    } 
    if (remove_class_redcapFactor) {
      data <- CRUmisc::remove_class_redcapFactor(data)
    }
    source <- paste0("REDCap"," (project ",REDCapPid,")")
    rdsName <- paste0("REDCap",REDCapPid,"_",strftime(Now,format="%d_%b_%Y"))
    if (!file.exists(rdsLoc)) {
      stop("Cannot find folder ",rdsLoc)
    }
    rdsFullPath <- paste0(rdsLoc,"/",rdsName, ".rds")
    saveRDS(data, file = paste0(rdsFullPath))
    when <- Now
  } else {
    if (!file.exists(mostRecent)) {
      stop("Cannot find file " ,mostRecent)
    }
    data <- readRDS(file = paste0(mostRecent))
    if (recent>1) {
      source <- paste0("Cached: recent=",recent)
    } else {
      source <- "Cached"
    }
    when <- rdsTime
    rdsFullPath <- mostRecent
  }

  labels <- sapply(data,
    function(x) {
      at <- attributes(x)$label
      ifelse(is.null(at),"",at) })
  

  if (printHours) message("The printHours parameter is now deprecated.")

  list(data=data,field.labels=labels,source=source,when=when,path=rdsFullPath)
}



#' @title [Install and] load packages.
#' @author Steven Worthington
#' @description Load packages. Install them first if necessary.
#' @param pkg      vector of package names
#'
#' @examples
#' ipak(c("ggplot2","dplyr"))
#'
#' @export

# Install missing packages
# from: https://gist.github.com/stevenworthington/3178163
ipak <- function(pkg){
  
  stop("ipak function has been disabled.")
  
  new.pkg <- pkg[!(pkg %in% installed.packages()[, "Package"])]
  if (length(new.pkg))
      install.packages(new.pkg, dependencies = TRUE, repos = "http://cran.us.r-project.org")
  invisible(sapply(pkg, require, character.only = TRUE, quietly = TRUE))
}

#' @title Plot a change graph.
#' @author Nick J. Barrowman
#' @description Draw lines from values on the left (pre) to values on the right (post).
#' @param y1       often the pre-score
#' @param y2       often the post-score
#' @param name1    name of the pre-score
#' @param name2    name of the post-score
#' @param labels   labels for each of the data points
#' @param col      colours
#' @param cex.text text size for the labels
#'
#' @examples
#' # Not a great example, but it's better than nothing
#' plotchange(FakeData$Age,FakeData$Score)
#'
#' @export

plotchange <- function(y1,y2,
  name1=sapply(as.list(substitute({y1})[-1]), deparse),
  name2=sapply(as.list(substitute({y2})[-1]), deparse),
  xpos1=1,
  xpos2=2,
  labels=rep("",length(y1)),
  col=rep(1,length(y1)),
  cex.text=1,...) {

  # These next two lines seem ridiculous, but they apparently
  # force R to evaluate name1 and name2, so that they get
  # passed properly to mtext later on.
  name1 <- name1
  name2 <- name2

  y1 <- signif(y1,4); y2 <- signif(y2,4)

  if (length(y1)!=length(y2))
    stop("y1 and y2 are paired, so they should be the same length")

  x1 <- rep(xpos1,length(y1))
  x2 <- rep(xpos2,length(y2))

  x <- c(x1,x2)

  y <- c(y1,y2)

  plot(x,y,axes=FALSE,xlab="",ylab="",...,xlim=c(0.75,2.25),pch=19)
  axis(side=2)
  box()

  if (any(labels!="")) {
    sp1 <- split(labels,y1)
    for (i in 1:length(sp1)) {
      text(xpos1-0.03,as.numeric(names(sp1[i])),paste(sp1[[i]],collapse=","),adj=1,cex=cex.text)
    }

    sp2 <- split(labels,y2)
    for (i in 1:length(sp2)) {
      text(xpos2+0.03,as.numeric(names(sp2[i])),paste(sp2[[i]],collapse=","),adj=0,cex=cex.text)
    }
  }

  segments(x1,y1,x2,y2,col=col)

  mtext(name1,side=1,at=xpos1,line=1)
  mtext(name2,side=1,at=xpos2,line=1)

}


#' @title around_func
#' @author Nick J. Barrowman
#' @description Helper function for flowcharts
#'
#' @export

around_func <- function (x, digits = 2, tooLong = 10) {
    if (is.data.frame(x)) {
        for (i in 1:ncol(x)) {
            x[[i]] <- around(x[[i]], digits = digits)
        }
        x
    }
    else if (!is.numeric(x)) {
        x
    }
    else {
        if (digits == 0) {
            result <- formatC(x, digits = digits, drop0trailing = TRUE,
                format = "f", flag = "#")
            result[nchar(result) > tooLong] <- formatC(x[nchar(result) >
                tooLong], digits = digits, drop0trailing = TRUE,
                format = "g", flag = "#")
        }
        else {
            result <- formatC(x, digits = digits, drop0trailing = FALSE,
                format = "f", flag = "#")
            result[nchar(result) > tooLong] <- formatC(x[nchar(result) >
                tooLong], digits = digits, drop0trailing = FALSE,
                format = "g", flag = "#")
        }
        result[result == "-0"] <- "0"
        result[result == "-0.0"] <- "0.0"
        result[result == "-0.00"] <- "0.00"
        result[result == "-0.000"] <- "0.000"
        result
    }
}


#' @title Wilson score confidence interval for a proportion
#' @author Nick J. Barrowman
#' @description
#'  \code{wilsonscore} Generate a Wilson score confidence interval for a proportion
#'
#' @param r          numerator
#' @param n          denominator
#' @param alpha      alpha level (default 0.05)
#'
#' @return a list with elements \code{L} (lower end of confidence interval), \code{p} (estimated proportion), and \code{U}(upper end of confidence interval)
#' @examples
#' wilsonscore(33,2322)
#' @export

wilsonscore <- function(r,n,alpha=0.05) {
z <- qnorm(1-alpha/2)
p <- r/n
q <- 1-p
L <- (2*n*p+z^2-z*sqrt(z^2+4*n*p*q))/(2*(n+z^2))
U <- (2*n*p+z^2+z*sqrt(z^2+4*n*p*q))/(2*(n+z^2))
list(L=L,p=p,U=U)
}


#' @title Wilson score confidence interval for the difference of two proportions
#' @author Nick J. Barrowman
#' @description
#' Generate a Wilson score confidence interval for the difference of two proportions
#'
#' @param a          numerator 1
#' @param m          denominator 1
#' @param b          numerator 2
#' @param n          denominator 2
#' @param alpha      alpha level (default 0.05)
#'
#' @return a list with elements \code{lower} (lower end of confidence interval),
#'   \code{thetahat} (estimated difference in proportions), and \code{U}(upper end of confidence interval)
#' @examples
#' wilson2prop(33,2322,18,250)
#' @export

wilson2prop <- function(a,m,b,n) {
# Wilson score method for confidence interval
# for the difference between independent proportions
# ----------------------------------------------------------------
# See method #10 on p.876 of
# Newcombe RG. Interval estimation for the difference
# between independent proportions: comparison of eleven
# methods. Stat Med 1998; 17(8):873-890.
#

thetahat <- a/m - b/n

seq01 <- seq(0,1,length=200)
func <- function(pi1,num,denom) { abs(pi1-num/denom)-1.96*sqrt(pi1*(1-pi1)/denom) }

i <- 1
if (a==0) {
l1 <- 0
} else {
while(sign(func(seq01[i],num=a,denom=m))==sign(func(seq01[i+1],num=a,denom=m))) {
i <- i+1
}
lower <- seq01[i]; upper <- seq01[i+1]
l1 <- uniroot(func,lower=lower,upper=upper,num=a,denom=m)$root
}
if (a==m) {
u1 <- 1
} else {
i <- i+1
while(sign(func(seq01[i],num=a,denom=m))==sign(func(seq01[i+1],num=a,denom=m))) {
i <- i+1
}
lower <- seq01[i]; upper <- seq01[i+1]
u1 <- uniroot(func,lower=lower,upper=upper,num=a,denom=m)$root
}

i <- 1
if (b==0) {
l2 <- 0
} else {
while(sign(func(seq01[i],num=b,denom=n))==sign(func(seq01[i+1],num=b,denom=n))) {
i <- i+1
}
lower <- seq01[i]; upper <- seq01[i+1]
l2 <- uniroot(func,lower=lower,upper=upper,num=b,denom=n)$root
}
if (b==n) {
u2 <- 1
} else {
i <- i+1
while(sign(func(seq01[i],num=b,denom=n))==sign(func(seq01[i+1],num=b,denom=n))) {
i <- i+1
}
lower <- seq01[i]; upper <- seq01[i+1]
u2 <- uniroot(func,lower=lower,upper=upper,num=b,denom=n)$root
}

delta <- 1.96*sqrt(l1*(1-l1)/m + u2*(1-u2)/n)
epsilon <- 1.96*sqrt(u1*(1-u1)/m + l2*(1-l2)/n)

lower <- thetahat-delta
upper <- thetahat+epsilon

c(lower,thetahat,upper)
}




#' @title Multiple plot function
#' @author http://www.cookbook-r.com/Graphs/Multiple_graphs_on_one_page_(ggplot2)/
#' @description
#'   \code{multiplot} Generate multiple graphs on one page (ggplot2)
#' @import ggplot2
#' @import grid
#' @param ...          ggplot objects
#' @param plotlist     a list of ggplot objects
#' @param cols         Number of columns in layout
#' @param layout       A matrix specifying the layout. If present, \code{cols} is ignored.
#'
#' @export

multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)


  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)

  numPlots = length(plots)

  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                    ncol = cols, nrow = ceiling(numPlots/cols))
  }

 if (numPlots==1) {
    print(plots[[1]])

  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))

    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))

      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}


#' @title Boxbee graph (using base graphics)
#' @author Nick Barrowman
#' @description
#'  \code{boxbee} Displays a boxbee graph, i.e. the 25th, median, and 75th percentile like a boxplot, with a superimposed "beeswarm" of points.
#' @import beeswarm
#' @param z            numeric vector or list of numeric vectors
#' @param log          should the axis use a log scale?
#' @param type         if equal to \code{"n"} then don't plot anything, just set up the graph
#' @param verbose      show summaries for each group in \code{x}
#' @param show90       show summaries for each group in \code{x} including the 90th percentile
#' @param spacing      beewarm spacing
#' @param type         if equal to \code{"n"} then don't plot anything, just set up the graph
#' @param yat          position of y-axis labels
#' @param ylabels      y-axis labels
#' @param pch          plotting character
#' @param cex.axis     axis character size
#' @param ygrid        Show a y-axis grid.
#' @param at           where to put the boxbees
#' @param horizontal   Display the boxbee horizontally?
#' @param horiz        Draw a horizontal line at the specified y-value.
#' @param horizcol     colour of the horizontal line
#' @param horizlwd     width of the horizontal line
#' @param refline      Draw a reference line at the specified value.
#' @param refcol       colour of the reference line
#' @param reflwd       width of the reference line
#' @param xlim         x-limits for the graph (or y-limits if horizontal=TRUE)
#' @param ylim         y-limits for the graph (or x-limits if horizontal=TRUE)
#' @param pwpch        pointwise plotting character for the beeswarms
#' @param pwcol        pointwise plotting colors
#' @param showmean     Show where the mean is (using a horizontal line)?
#' @param showmeancol  colour of the mean line
#' @param showmeanwidth width of the mean line
#' @param showmeanlwd  thickness of the mean line#' @examples
#' boxbee(FakeData$Score)
#' @export

boxbee <- function(
  z,log=FALSE,col="lightsteelblue1",boxcol="lightsteelblue3",medcol="lightsteelblue4",
  boxwex=0.7,cex=1,varwidth=TRUE,verbose=FALSE,show90 = FALSE,spacing=1,type="",yat,ylabels,pch=1,
  cex.axis=1,ygrid=FALSE,at,horiz,horizline,horizcol="grey80",horizlwd=1,xlim,ylim,pwpch=NULL,pwcol=NULL,
  showmean=FALSE,showmeancol="red",showmeanwidth=0.32,showmeanlwd=3,horizontal=FALSE,refline,refcol,reflwd,...) {
  
  if (!missing(horiz)) refline <- horiz
  if (!missing(horizcol)) refcol <- horizcol
  if (!missing(horizlwd)) reflwd <- horizlwd

  # You need the suggested package for this function
  my_fun <- function(a, b) {
    if (!requireNamespace("beeswarm", quietly = TRUE)) {
      stop("beeswarm package needed for this function to work. Please install it.",
        call. = FALSE)
    }
  }

  if (missing(at)) {
    if (is.list(z)) {
      at <- 1:length(z)
    } else {
      at <- 1
    }
  }

  # Note from bxp help page:
  # "When add = FALSE, xlim now defaults to xlim = range(at, *) + c(-0.5, 0.5)."
  if (missing(xlim)) xlim <- c(min(at)-0.5,max(at)+0.5)

  if (log) {
    for (i in 1:length(z)) {
      if (any(z[[i]][!is.na(z[[i]])]<=0)) {
        cat("Zeros or negatives can't be log transformed.\n")
        # Remove missing values, zeros, negatives
        z[[i]] <- z[[i]][!is.na(z[[i]]) & z[[i]]>0]
      }
    }
    if (type=="n") {
      if (missing(ylim)) ylim <- range(sapply(z,function(w) range(log(w),na.rm=TRUE)))
      if (horizontal) {
        plot(NA,NA,type="n",xlab="",ylab="",axes=FALSE,
          xlim=ylim,ylim=xlim,log="x")
      } else {
        plot(NA,NA,type="n",xlab="",ylab="",axes=FALSE,
          xlim=xlim,ylim=ylim,log="y")
      }
      return(NULL)
    }
    if (missing(yat)) {
      if (missing(ylim)) ylim <- range(z,na.rm=TRUE)
      if (horizontal) {
        plot(NA,NA,type="n",xlab="",ylab="",axes=FALSE,xlim=ylim,ylim=xlim,log="x")
      } else {
        plot(NA,NA,type="n",xlab="",ylab="",axes=FALSE,xlim=xlim,ylim=ylim,log="y")
      }      
      if (horizontal) {
        boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,medcol=medcol,
          whisklty="blank",staplelty="blank",outpch=NA,log="x",
          varwidth=varwidth,cex.axis=cex.axis,at=at,
          add=TRUE,horizontal=TRUE,...)
      } else {
        boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,medcol=medcol,
          whisklty="blank",staplelty="blank",outpch=NA,log="y",
          varwidth=varwidth,cex.axis=cex.axis,at=at,add=TRUE,...)
      }
      if (ygrid) abline(h=axTicks(2),col="grey80")
      if (horizontal) {
        boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,medcol=medcol,
          whisklty="blank",staplelty="blank",outpch=NA,log="x",
          varwidth=varwidth,cex.axis=cex.axis,at=at,
          horizontal=TRUE,add=TRUE,...)
      } else {
        boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,medcol=medcol,
          whisklty="blank",staplelty="blank",outpch=NA,log="y",
          varwidth=varwidth,cex.axis=cex.axis,at=at,add=TRUE,...)
      }
    } else {
      if (horizontal) {
        boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,medcol=medcol,
          whisklty="blank",staplelty="blank",outpch=NA,log="x",
          varwidth=varwidth,axes=FALSE,at=at,ylim=xlim,horizontal=TRUE,...)
      } else {
        boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,medcol=medcol,
          whisklty="blank",staplelty="blank",outpch=NA,log="y",
          varwidth=varwidth,axes=FALSE,at=at,xlim=xlim,...)
      }
      if (is.list(z)) {
        if (horizontal) {
          axis(2,at=at,labels=names(z),cex.axis=cex.axis)
        } else {
          axis(1,at=at,labels=names(z),cex.axis=cex.axis)
        }
      } else {
        axis(1,at=1,labels=names(z),cex.axis=cex.axis)
      }
      if (missing(ylabels)) {
        ylabels <- yat
      }
      if (horizontal) {
        axis(1,at=yat,labels=ylabels,cex.axis=cex.axis)
      } else {
        axis(2,at=yat,labels=ylabels,cex.axis=cex.axis)
      }
      box()
    }
    if (horizontal) {
      beeswarm::beeswarm(z,add=TRUE,method="center",
        log=TRUE,cex=cex,spacing=spacing,pch=pch,at=at,
        pwpch=pwpch,pwcol=pwcol,horizontal=TRUE)
    } else {
      beeswarm::beeswarm(z,add=TRUE,method="center",
        log=TRUE,cex=cex,spacing=spacing,pch=pch,at=at,
        pwpch=pwpch,pwcol=pwcol)
    }
  } else { ### log=FALSE ########################
    if (type=="n") {
      if (missing(ylim)) ylim <- range(sapply(z,function(w) range(w,na.rm=TRUE)))
      if (horizontal) {
        plot(NA,NA,type="n",xlab="",ylab="",axes=FALSE,
          xlim=ylim,ylim=xlim)
      } else {
        plot(NA,NA,type="n",xlab="",ylab="",axes=FALSE,
          xlim=xlim,ylim=ylim)
      }
      if (horizontal) {
        bxp <- boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,
          medcol=medcol,whisklty="blank",staplelty="blank",
          outpch=NA,varwidth=varwidth,at=at,xlim=ylim,
          plot=FALSE,horizontal=TRUE,...)
      } else {
        bxp <- boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,
          medcol=medcol,whisklty="blank",staplelty="blank",
          outpch=NA,varwidth=varwidth,at=at,xlim=xlim,
          plot=FALSE,...)
      }
      return(invisible(bxp))
    }
    if (missing(ylim)) ylim <- range(z,na.rm=TRUE)
    if (horizontal) {
      plot(NA,NA,type="n",xlab="",ylab="",axes=FALSE,xlim=ylim,ylim=xlim)
    } else {
      plot(NA,NA,type="n",xlab="",ylab="",axes=FALSE,xlim=xlim,ylim=ylim)
    }
    if (ygrid) abline(h=axTicks(2),col="grey80")
    if (horizontal) {
      if (!missing(refline) | !missing(horizline)) abline(v=refline,col=refcol,lwd=reflwd)
    } else {
      if (!missing(refline) | !missing(horizline)) abline(h=refline,col=refcol,lwd=reflwd)
    }
    if (horizontal) {
      bxp <- boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,medcol=medcol,
        whisklty="blank",staplelty="blank",outpch=NA,varwidth=varwidth,
        at=at,xlim=ylim,add=TRUE,horizontal=TRUE,...)
    } else {
      bxp <- boxplot(z,col=col,boxwex=boxwex,boxcol=boxcol,medcol=medcol,
        whisklty="blank",staplelty="blank",outpch=NA,varwidth=varwidth,
        at=at,xlim=xlim,add=TRUE,...)
    }
    if (horizontal) {
      beeswarm::beeswarm(z,boxwex=wexBox,add=TRUE,method="center",
        cex=cex,spacing=spacing,pch=pch,at=at,pwpch=pwpch,pwcol=pwcol,
        horizontal=TRUE)
    } else {
      beeswarm::beeswarm(z,boxwex=wexBox,add=TRUE,method="center",
        cex=cex,spacing=spacing,pch=pch,at=at,pwpch=pwpch,pwcol=pwcol)
    }
    if (showmean) {
      if (is.list(z)) {
        xlen <- sapply(z,length)
        smwidth <- (par()$usr[2]-par()$usr[1])*showmeanwidth/length(z)
        if (varwidth) smwidth <- smwidth/(max(sqrt(xlen))/sqrt(xlen))
        smm <- sapply(z,function(q) mean(q,na.rm=TRUE))
      } else {
        smwidth <- (par()$usr[2]-par()$usr[1])*showmeanwidth
        smm <- mean(z,na.rm=TRUE)
      }
      segments(at-smwidth,smm,at+smwidth,smm,col=showmeancol,lwd=showmeanlwd)
    }
  }
  if (!show90 & verbose) {
      if (!is.list(z))
          z <- list(z)
      for (i in 1:length(z)) {
          Z <- z[[i]]
          cat(names(z)[i], " (n=", length(Z), ")\n", sep = "")
          print(summary(Z))
      }
  }
  if (show90) {
      if (!is.list(z))
          z <- list(z)
      for (i in 1:length(z)) {
          Z <- z[[i]]
          cat(names(z)[i], " (n=", length(Z), ")\n", sep = "")
          smry <- summary(Z)
          pos <- (1:length(smry))[names(smry) == "Max."] -
              1
          descriptive <- c(smry[1:pos], quantile(Z, 0.9, na.rm = TRUE),
              smry[((pos) + 1):length(smry)])
          print(round(descriptive, 4))
      }
  }
}

#' @title Draw confidence intervals (base graphics)
#' @author Nick Barrowman
#' @description
#'  \code{drawintervals} Draw confidence intervals with more automatic features than drawci()
#' @param lo         vector of low end of intervals
#' @param est        vector of estimates
#' @param hi         vector of high end of intervals
#' @param vertical   vertical error bars?
#' @param pos        vector of positions (vertical or horizontal) of each interval.
#' @param dotColour  vector of colour of each dot
#' @param barColour  vector of colour of each bar
#' @param cex        vector of character expansion size
#' @param lwd        vector of line width
#' @param tickscale  vector of confidence interval tick scalings
#' @param xlim       x limits of the plot
#' @param ylim       y limits of the plot
#' @param xlab       label for x-axis
#' @param ylab       label for y-axis
#' @param names      a vector of K character strings.
#' @param font       vector of font number for each name
#' @param fill       Fill the plot region using gradientfill().
#' @param shadow     Put a shadow under each dot?
#' @param plot       Show the graph actually be plotted?
#' @param add        Add to an existing graph?
#' @param log        when \code{log}=\code{x} (or \code{y}) use log scaling on the x-axis (or y-axis)
#' @param extend     how much to extend the plot vertically (if \code{vertical}=\code{FALSE}) or horizontally (if \code{vertical}=\code{TRUE})
#' @param numberaxis Number the quantitative axis?
#'
#' @examples
#' drawintervals(lo=c(1,3,8),est=c(2,4,10),hi=c(5,7,15),pch=c(19,18,19),
#'   fill=FALSE,barColour=c("black","green","blue"),
#'   dotColour="orange",names=c("cat","fish","dog"))
#'
#' @return \code{invisible(list(xlim=xlim,ylim=ylim,pos=pos))}
#'
#' @export

drawintervals <- function(lo,est,hi,vertical=FALSE,pos=-(1:length(est)),
  pch=rep(19,length(est)),dotColour=rep("red",length(est)),barColour=rep("grey40",length(est)),
  cex=rep(1,length(est)),lwd=rep(1,length(est)),tickscale=rep(0.05,length(est)),
  xlim,ylim,xlab="",ylab="",names, font=rep(1,length(est)),
  fill=FALSE,shadow=FALSE,plot=TRUE,add=FALSE,log="",extend=0.1,
  showbox=TRUE,
  numberaxis=TRUE,estimatesRHS=FALSE) {

  around <- function(x,digits=2) {

    if (is.data.frame(x)) {
      # Handle data frames
      for (i in 1:ncol(x)) {
        x[[i]] <- around(x[[i]],digits=digits)
      }
      x
    } else
      if (!is.numeric(x)) {
        # Ignore variables that are not numeric
        x
      } else {
        if (digits==0) {
          result <- formatC(x,digits=digits,drop0trailing=TRUE,format="f",flag="#")
        } else {
          result <- formatC(x,digits=digits,drop0trailing=FALSE,format="f",flag="#")
        }
        result[result=="-0"] <- "0"
        result[result=="-0.0"] <- "0.0"
        result[result=="-0.00"] <- "0.00"
        result[result=="-0.000"] <- "0.000"
        result
      }
  }

  K <- length(est)

  if (length(pch)==1) pch <- rep(pch,K)
  if (length(dotColour)==1) dotColour <- rep(dotColour,K)
  if (length(barColour)==1) barColour <- rep(barColour,K)
  if (length(cex)==1) cex <- rep(cex,K)
  if (length(lwd)==1) lwd <- rep(lwd,K)
  if (length(tickscale)==1) tickscale <- rep(tickscale,K)

  minpos <- min(pos)
  maxpos <- max(pos)

  # {r}ange of {pos}itions
  rpos <- maxpos-minpos

  limpos <- c(minpos-rpos*extend,maxpos+rpos*extend)

  if (vertical) {
    if (missing(ylim)) ylim <- range(lo[!is.na(lo) & !is.na(hi) & lo!=Inf & hi!=Inf],hi[!is.na(lo) & !is.na(hi) & lo!=Inf & hi!=Inf])
    if (missing(xlim)) xlim <- limpos
  } else {
    if (missing(xlim)) xlim <- range(lo[!is.na(lo) & !is.na(hi) & lo!=Inf & hi!=Inf],hi[!is.na(lo) & !is.na(hi) & lo!=Inf & hi!=Inf])
    if (missing(ylim)) ylim <- limpos
  }

  if (plot) {
    if (!add) {
      par(las=1)
      plot(NA,NA,type="n",xlab="",ylab="",
        xlim=xlim,ylim=ylim,axes=FALSE,log=log)
    }
    if (fill) gradientfill()
    if (showbox) box()
    if (vertical) {
      if (numberaxis) axis(2)
      if (missing(ylab)) ylab <- ""
      if (!missing(names)) {
        for (i in 1:length(pos)) {
          axis(1,at=pos[i],labels=names[i],tick=FALSE,font=font[i])
        }
      }
    } else {
      if (numberaxis) axis(1)
      if (missing(xlab)) xlab <- ""
      if (!missing(names)) {
       for (i in 1:length(pos)) {
          axis(2,at=pos[i],labels=names[i],tick=FALSE,font=font[i])
       }
      }
    }
    title(xlab=xlab,ylab=ylab)
    for (i in 1:length(pos)) {
      if (vertical) {
        drawci(lo[i],est[i],hi[i],x=pos[i],
          barColour=barColour[i],dotColour=dotColour[i],
          pch=pch[i],cex=cex[i],lwd=lwd[i],tickscale=tickscale[i],shadow=shadow)
      } else {
        drawci(lo[i],est[i],hi[i],y=pos[i],
          barColour=barColour[i],dotColour=dotColour[i],
          pch=pch[i],cex=cex[i],lwd=lwd[i],tickscale=tickscale[i],shadow=shadow)
      }
    }
  }

  if (estimatesRHS) {
    estlohi <- paste0(around(est,2)," (",around(lo,2),", ",around(hi,2),")")
    estlohi[is.na(est)] <- ""
    estlohi[estlohi=="1.00 (1.00, 1.00)"] <- 1
    mtext(estlohi,side=4,line=1,at=pos,las=1,cex=0.8)
  }

  invisible(list(xlim=xlim,ylim=ylim,pos=pos))
}


#' @title Draw confidence intervals (base graphics)
#' @author Nick Barrowman
#' @description
#'   \code{drawci} Draw confidence intervals at specified locations, with various bells and whistles.
#' @param lo   the low end of the interval
#' @param est  the point estimate
#' @param hi   the high end of the interval
#' @param x,y  the x (or y) position of a vertical (or horizontal) bar
#'
#' @export

drawci <- function(lo,est,hi,x,y,
  leftarrows=rep(FALSE,length(est)),rightarrows=rep(FALSE,length(est)),arrowlength=0.1,
  lwd=2.2,pch=19,cex=1.5,dotColour="red",shadowColour="grey20",barColour="grey40",
  plotit=TRUE,tickscale=0.05,shadow=FALSE,showLower=TRUE,showUpper=TRUE,add=TRUE,type="p",ylim,...) {

  G <- length(est)

  if (length(pch)==1) pch <- rep(pch,G)

  positionsSupplied <- TRUE
  if (missing(x) && missing(y)) {
    positionsSupplied <- FALSE
    y <- 1:length(est)
  }

  if (!add) {
    if (!missing(x)) {
      xlim <- range(x,na.rm=TRUE)
      if (!positionsSupplied) xlim <- rev(xlim)
      plot(NA,NA,xlim=xlim,ylim=range(lo,hi,na.rm=TRUE),type="n",xlab="",ylab="",...)
    } else
    if (!missing(y)) {
      if (missing(ylim)) {
        ylim <- range(y,na.rm=TRUE)
        if (!positionsSupplied) ylim <- rev(ylim)
      }
      plot(NA,NA,ylim=ylim,xlim=range(lo,hi,na.rm=TRUE),type="n",xlab="",ylab="",...)
    }
  }

  # -----------------------------------------------------------------
  # Get the overall dimensions of the plot
  usr <- par()$usr; xlo<-usr[1]; xhi<-usr[2]; ylo<-usr[3]; yhi<-usr[4]
  xr <- xhi-xlo; yr <- yhi-ylo; xmid=(xlo+xhi)/2; ymid=(ylo+yhi)/2
  # -----------------------------------------------------------------
  # Get the dimensions of the plot in inches
  pin <- par()$pin; widthInches <- pin[1]; heightInches <- pin[2]
  xUnitsPerInch <- xr/widthInches; yUnitsPerInch <- yr/heightInches
  # -----------------------------------------------------------------

  # Slight displacement to create a shadow under the dot for the point estimate
  xb <- xr*0.002; yb <- yr*0.002

  if (plotit) {
    if (!missing(x)) {
      if (type=="l") {
        lines(x-xb,est-yb,col=shadowColour)   # shouldn't this be points not lines??
      }
      foothalfwidth <- tickscale*xUnitsPerInch  # number of x units corresponding to 0.05 inches
      for (i in 1:G) {
        if (showLower & showUpper)
          segments(x[i],lo[i],x[i],hi[i],lwd=lwd,col=barColour)
        if (showLower & !showUpper)
          segments(x[i],lo[i],x[i],est[i],lwd=lwd,col=barColour)
        if (!showLower & showUpper)
          segments(x[i],est[i],x[i],hi[i],lwd=lwd,col=barColour)
        if (showLower)
          segments(x[i]-foothalfwidth,lo[i],x[i]+foothalfwidth,lo[i],lwd=lwd,col=barColour) # tick at low end
        if (showUpper)
          segments(x[i]-foothalfwidth,hi[i],x[i]+foothalfwidth,hi[i],lwd=lwd,col=barColour) # tick at high end
        if (shadow)
          points(x[i]-xb,est[i]-yb,pch=pch,col=shadowColour,cex=cex) # shadow
        points(x[i],est[i],pch=pch,col=dotColour,cex=cex)
      }
    }
  }

  if (plotit) {
    if (!missing(y)) {
      foothalfwidth <- tickscale*yUnitsPerInch  # number of y units corresponding to 0.05 inches
      for (i in 1:length(lo)) {
        if (!leftarrows[i] & !rightarrows[i]) {
          segments(lo[i],y[i],hi[i],y[i],lwd=lwd,col=barColour)
          segments(lo[i],y[i]-foothalfwidth,lo[i],y[i]+foothalfwidth,lwd=lwd,col=barColour) # tick at low end
          segments(hi[i],y[i]-foothalfwidth,hi[i],y[i]+foothalfwidth,lwd=lwd,col=barColour) # tick at high end
        } else
        if (leftarrows[i] & !rightarrows[i]) {
          arrows(lo[i],y[i],hi[i],y[i],lwd=lwd,col=barColour,code=1,length=arrowlength)
          segments(hi[i],y[i]-foothalfwidth,hi[i],y[i]+foothalfwidth,lwd=lwd,col=barColour) # tick at high end
        } else
        if (!leftarrows[i] & rightarrows[i]) {
          arrows(lo[i],y[i],hi[i],y[i],lwd=lwd,col=barColour,code=2,length=arrowlength)
          segments(lo[i],y[i]-foothalfwidth,lo[i],y[i]+foothalfwidth,lwd=lwd,col=barColour) # tick at low end
        } else
        if (leftarrows[i] & rightarrows[i]) {
          arrows(lo[i],y[i],hi[i],y[i],lwd=lwd,col=barColour,code=3,length=arrowlength)
        }
      }
      if (shadow)
        points(est-xb,y-yb,pch=pch,col=shadowColour,cex=cex,type=type) # shadow
      if (type=="l") {
        lines(est-xb,y-yb,col=shadowColour)
      }
      points(est,y,pch=pch,col=dotColour,cex=cex)
    }
  }

}



#' @title  [show] [Context] of an R Markdown project
#'
#' @author Nick Barrowman
#'
#' @description
#'  \code{showContext} Displays information about the working directory and version control
#'
#' @examples
#'
#' # The R Markdown code below uses showContext() and then calls devtools:::session_info()
#' # The isTRUE(getOption("knitr.in.progress")) makes sure this is only done when knitting.
#'
#' #########
#' # Context information (For reproducibility purposes only)
#'
#' ```{r, echo=FALSE,results="asis"}
#' if (isTRUE(getOption("knitr.in.progress"))) {
#'   showContext()
#' }
#' ```
#'
#' ```{r}
#' if (isTRUE(getOption("knitr.in.progress"))) {
#'   devtools::session_info()
#' }
#' ```
#'
#' @export
#'

showContext <- function() {
  wd <- getwd()
  cat("**Working directory**:",wd,"\n\n")
  options(warn=-1)
  cat("**SVN version control information**\n\n")
  RepoPath <- system("svn info --show-item repos-root-url",inter=TRUE)
  if (length(RepoPath)==0) {
    cat("&nbsp;&nbsp;&nbsp;&nbsp;Not under SVN version control.\n")
    Revision <- ""
  } else {
    cat("&nbsp;&nbsp;&nbsp;&nbsp;*Repository URL*: ",RepoPath,"\n\n")
    WCroot <- system("svn info --show-item wc-root",inter=TRUE)
    cat("&nbsp;&nbsp;&nbsp;&nbsp;*Working copy root*: ",WCroot,"\n\n")
    WCroot2 <- gsub("/","\\\\",WCroot)
    Revision <- system(paste0("subwcrev ",'"',WCroot2,'"'),inter=TRUE)
    Revision <- gsub("\\\\","/",Revision)
    Revision <- cat(paste0("&nbsp;&nbsp;&nbsp;&nbsp;",Revision[-1]),sep="\\\n")
  }
  options(warn=0)
}


#' @title  Confidence interval for difference of medians
#'
#' @author Nick Barrowman
#'
#' @description
#'  \code{medCI} Confidence interval for difference of medians
#'
#' @param x,y   two numeric vectors
#' @param alpha two-sided alpha for confidence interval
#'
#' @return
#' A list with elements
#' \describe{
#'   \item{estimate}{difference of sample medians}
#'   \item{lo}{lower end of confidence interval}
#'   \item{hi}{upper end of confidence interval}
#' }
#'
#' @details
#' The formula is from page 120 of:
#' Distribution-Free Confidence Intervals For Difference And Ratio Of Medians
#' Robert M. Price and Douglas G. Bonett
#' J. Statist. Comput. Simul., 2002, 72(2), 119–124.
#'
#' In that paper,
#' there is an error in the exponent in the expression for p_j (bottom p.120).
#' The exponent should be n-1 but it is written n-i.
#'
#' Note that in another paper the correct expression is given for p_j
#' (but it's called alpha* ). It's on p. 298 (just after equation 8) of:
#' Estimating the variance of the sample median
#' Robert M. Price and Douglas G. Bonett
#' J. Statist. Comput. Simul., 2001, 68(3), 295-305.
#'
#' @examples
#' medCI(cloud$volume[cloud$group=="seeded"],cloud$volume[cloud$group=="unseeded"])
#'
#' @export
#'

medCI <- function(x,y,alpha=0.05) {

  x <- sort(x)
  y <- sort(y)
  medx <- median(x)
  medy <- median(y)
  nx <- length(x)
  ny <- length(y)
  cx <- round((nx+1)/2 - sqrt(nx))
  if (cx==0) cx <- 1
  cy <- round((ny+1)/2 - sqrt(ny))
  if (cy==0) cy <- 1

  # cat("cx=",cx,"  cy=",cy,"\n")

  px <- 0
  for (i in 0:(cx-1)) {
    px <- px+choose(nx,i)*0.5^(nx-1)
  }

  py <- 0
  for (i in 0:(cy-1)) {
    py <- py+choose(ny,i)*0.5^(ny-1)
  }

  # cat("px=",px,"  py=",py,"\n")

  zx <- qnorm(1-px/2)
  zy <- qnorm(1-py/2)

  # cat("zx=",zx,"  zy=",zy,"\n")

  vx <- ((x[nx-cx+1] - x[cx])/(2*zx))^2
  vy <- ((y[ny-cy+1] - y[cy])/(2*zy))^2

  # cat("vx=",vx,"  vy=",vy,"\n")

  s <- sqrt(vx+vy)

  est <- medx-medy

  list(estimate=est,lo=est - qnorm(1-alpha/2)*s, hi = est + qnorm(1-alpha/2)*s)
}



#' @title Confidence interval for ratio of medians
#'
#' @author Nick Barrowman, Amisha Agarwal
#'
#' @description
#'  \code{medCIratio} Confidence interval for ratio of medians
#'
#' @param x,y   two numeric vectors
#' @param alpha two-sided alpha for confidence interval
#'
#' @return
#' A list with elements
#' \describe{
#'   \item{estimate}{ratio of sample medians}
#'   \item{lo}{lower end of confidence interval}
#'   \item{hi}{upper end of confidence interval}
#' }
#'
#' @details
#' The formula is from page 120 of:
#' Distribution-Free Confidence Intervals For Difference And Ratio Of Medians
#' Robert M. Price and Douglas G. Bonett
#' J. Statist. Comput. Simul., 2002, 72(2), 119–124.
#'
#' @examples
#' medCIratio(cloud$volume[cloud$group=="seeded"],cloud$volume[cloud$group=="unseeded"])
#'
#' @export
#'

medCIratio <- function (x, y, alpha = 0.05)
{
    medx <- median(x)
    medy <- median(y)
    est <- medx/medy
    x <- log(x)
    y <- log(y)
    x <- sort(x)
    y <- sort(y)
    nx <- length(x)
    ny <- length(y)
    cx <- round((nx + 1)/2 - sqrt(nx))
    if (cx == 0)
        cx <- 1
    cy <- round((ny + 1)/2 - sqrt(ny))
    if (cy == 0)
        cy <- 1
    px <- 0
    for (i in 0:(cx - 1)) {
        px <- px + choose(nx, i) * 0.5^(nx - 1)
    }
    py <- 0
    for (i in 0:(cy - 1)) {
        py <- py + choose(ny, i) * 0.5^(ny - 1)
    }
    zx <- qnorm(1 - px/2)
    zy <- qnorm(1 - py/2)
    vx <- ((x[nx - cx + 1] - x[cx])/(2 * zx))^2
    vy <- ((y[ny - cy + 1] - y[cy])/(2 * zy))^2
    s <- sqrt(vx + vy)
    list(estimate = est, lo = est * (exp(-1 * (qnorm(1 - alpha/2) * s))), hi = est * (exp(qnorm(1 - alpha/2) * s)))
}





#' @title  pairwise Fisher's exact test
#' @author Nick Barrowman
#'
#' @description
#'  \code{pairwiseFisher} Given a 2 x K matrix, perform pairwise Fisher's exact tests.
#'
#' @param x           a matrix with 2 rows and K columns.
#'                    First row is numerator.
#'                    First row + second row is denominator.
#' @param cols        Is it actually a column matrix, not a row matrix?
#' @param switch      Are the first and second rows switched?
#' @param denomrow    Is the second row actually the denominator?
#' @param firstRowNum Is the first row the numerator?
#'
#' @export
#'

pairwiseFisher <- function(x,cols=FALSE,switch=FALSE,denomrow=FALSE,names,firstRowNum=TRUE,
  showaxis=TRUE) {

  if (cols) x <- t(x)

  if (switch) x <- rbind(x[2,],x[1,])

  if (denomrow) x[2,] <- x[2,] - x[1,]

  if (!firstRowNum) {
    uu <- x
    x[1,] <- uu[2,]
    x[2,] <- uu[1,]
  }

  K <- ncol(x)

  if (missing(names)) names <- colnames(x)

  w <- wilsonscore(x[1,],x[1,]+x[2,])

  pairnames <- c()
  pvalues <- c()
  for (i in 1:(K-1)) {
    for (j in (i+1):K) {
      pairnames <- c(pairnames,paste0(names[i],":",names[j]))
      ft <- fisher.test(x[,c(i,j)])
      pvalues <- c(pvalues,ft$p.value)
    }
  }
  names(pvalues) <- pairnames
  return(pvalues)
}


#' @title  Draw [prop]ortions
#' @author Nick Barrowman
#'
#' @description
#'  \code{drawprop} Draws proportions with confidence intervals.
#'
#' @param x          a matrix with 2 rows and K columns.
#'                   First row is numerator.
#'                   First row + second row is denominator.
#' @param cols       Is it actually a column matrix, not a row matrix?
#' @param switch     Are the first and second rows switched?
#' @param denomrow   Is the second row actually the denominator?
#' @param firstRowNum Is the first row the numerator?
#' @param vertical   vertical error bars? (by default horizontal error bars are used)
#' @param horizontal horizontal error bars? (this can be specified instead of \code{vertical})
#' @param xlim       x limits of the plot
#' @param ylim       y limits of the plot
#' @param xlab       label for x-axis
#' @param ylab       label for y-axis
#' @param names      a vector of K character strings.
#' @param fill       Fill the plot region using gradientfill().
#' @param tickscale  Confidence interval tick scale.
#'
#' @examples
#' drawprop(cbind(c(23,27-23),c(24,29-24),c(20,26-20),c(37,42-37)))
#'
#' @export
#'

drawprop <- function(x,cols=FALSE,switch=FALSE,denomrow=FALSE,vertical,horizontal,xlim,ylim,xlab="",ylab="",names,
  shownames=TRUE,
  fill=FALSE,barColour="black",shadow=FALSE,cex=1,dotColour="red",lwd=1,
  firstRowNum=TRUE,connect=FALSE,connectColour="cornflowerblue",tickscale=0.05,
  showaxis=TRUE) {

  if (cols) x <- t(x)

  if (switch) x <- rbind(x[2,],x[1,])

  if (denomrow) x[2,] <- x[2,] - x[1,]

  if (missing(vertical) & missing(horizontal)) {
    vertical <- FALSE
  } else
  if (missing(vertical)) {
    vertical <- !horizontal
  }

  if (!firstRowNum) {
    uu <- x
    x[1,] <- uu[2,]
    x[2,] <- uu[1,]
  }

  K <- ncol(x)

  if (missing(names)) names <- colnames(x)

  w <- wilsonscore(x[1,],x[1,]+x[2,])
  lo <- 100*min(w$L,na.rm=TRUE)
  hi <- 100*max(w$U,na.rm=TRUE)

  if (vertical) {
    if (missing(ylim)) ylim <- c(lo,hi)
    if (missing(xlim)) xlim <- c(0.5,K+0.5)
  } else {
    if (missing(xlim)) xlim <- c(lo,hi)
    if (missing(ylim)) ylim <- c(0.5,K+0.5)
  }

  par(las=1)
  plot(0,0,type="n",xlab="",ylab="",
    xlim=xlim,ylim=ylim,axes=FALSE)
  if (fill) gradientfill()
  if (showaxis) { box() }
  if (vertical) {
    if (showaxis) {
      axis(2)
      if (missing(ylab)) ylab <- "Percent"
      if (shownames) axis(1,at=1:K,labels=names)
    }
  } else {
    if (showaxis) {
      axis(1)
      if (missing(xlab)) xlab <- "Percent"
      if (shownames) axis(2,at=1:K,labels=names)
    }
  }

  title(xlab=xlab,ylab=ylab)
  for (i in 1:K) {
    if (vertical) {
      drawci(100*w$L[i],100*w$p[i],100*w$U[i],x=i,barColour=barColour,dotColour=dotColour,shadow=shadow,cex=cex,lwd=lwd,tickscale=tickscale)
    } else {
      drawci(100*w$L[i],100*w$p[i],100*w$U[i],y=i,barColour=barColour,dotColour=dotColour,shadow=shadow,cex=cex,lwd=lwd,tickscale=tickscale)
    }
  }
  if (connect) {
    if (vertical) { lines(1:K,100*w$p,col=connectColour) } else { lines(100*w$p,1:K,col=connectColour) }
  }
}



#' @title Gradientfill (base graphics)
#'
#' @author Nick Barrowman
#'
#' @description
#'  \code{gradientfill} Performs a gradient fill in the plotting region.
#' @examples
#'
#' par(las=1,mar=c(1,4,1,1))
#' plot(0,0,type="n",xlab="",ylab="")
#' gradientfill()
#'
#' @export
#'

gradientfill <- function(gradient=c("blue","black"),G=200) {

  # -----------------------------------------------------------------
  # Get the overall dimensions of the plot
  usr <- par()$usr; xlo<-usr[1]; xhi<-usr[2]; ylo<-usr[3]; yhi<-usr[4]
  xr <- xhi-xlo; yr <- yhi-ylo; xmid=(xlo+xhi)/2; ymid=(ylo+yhi)/2
  # -----------------------------------------------------------------
  # Get the dimensions of the plot in inches
  pin <- par()$pin; widthInches <- pin[1]; heightInches <- pin[2]
  xUnitsPerInch <- xr/widthInches; yUnitsPerInch <- yr/heightInches
  # -----------------------------------------------------------------

  colour <- colorRamp(gradient)(seq(0,1,length=G))

  h <- yr/G
  for (i in 1:G) {
    polygon(c(xlo,xlo,xhi,xhi),c(ylo+h*(i-1),ylo+h*i,ylo+h*i,ylo+h*(i-1)),
      col=rgb(colour[i,1]/255,colour[i,2]/255,colour[i,3]/255),
      border=FALSE)
  }
}



#' @title ShadePointwise (base graphics)
#'
#' @author Nick Barrowman
#'
#' @description
#'  \code{ShadePointwise} Draw a shaded confidence band.
#'
#' @export
#'

ShadePointwise <- function(x,ylo,yhi,col="lightblue",alpha=0.3,newplot=TRUE,border=FALSE,baseline=0,...) {
  RGB <- col2rgb(col)
  r <- RGB[1,]/255; g <- RGB[2,]/255; b <- RGB[3,]/255
  COL <- rgb(r,g,b,alpha=alpha)

  if (newplot) {
    plot(c(x,x),c(ylo,yhi),type="n",...)
  }

  if (length(x)<2) return(NULL)

  START <- NA
  STOP <- NA
  for (i in 1:length(x)) {
    if (!is.na(START) & ((i==length(x)) | (is.na(ylo[i]) | is.na(yhi[i])))) {
      STOP <- i-1
      if (STOP>START) {
        #cat("----------shading from START=",START,"to  STOP=",STOP,"\n")
        polygon(c(x[START:STOP],rev(x[START:STOP])),
          c(ylo[START:STOP],rev(yhi[START:STOP])),col=COL,border=border)
        START <- STOP <- NA
      }
    }
    if (is.na(START) & !is.na(ylo[i]) & !is.na(yhi[i])) {
      START <- i
    }
    #cat("i=",i,"  START=",START,"  STOP=",STOP,"\n")
  }

  #polygon(c(x,rev(x)),c(ylo,rev(yhi)),col=COL,border=border)
}


#' @title ShadeUnderCurve (base graphics)
#'
#' @author Nick Barrowman
#'
#' @description
#'  \code{ShadeUnderCurve} Shade under a curve.
#'
#' @export
#'

ShadeUnderCurve <- function(x,y,col="lightblue",alpha=0.3,newplot=TRUE,border=FALSE,baseline=0,...) {
  RGB <- col2rgb(col)
  r <- RGB[1,]/255; g <- RGB[2,]/255; b <- RGB[3,]/255
  COL <- rgb(r,g,b,alpha=alpha)

  if (newplot) {
    plot(x,y,type="n",...)
  }
  polygon(c(x,rev(x)),c(y,rep(baseline,length(y))),col=COL,border=border)
  #lines(x,y)
}


#' @title grVizToPNG
#'
#' @author Nick Barrowman
#'
#' @description
#'  \code{grVizToPNG} Export a grViz object into a PNG file.
#'
#' @param g      an object produced by the grViz function from the DiagrammmeR package
#' @param width  the pixel width of the bitmap
#' @param folder path to folder where the PNG file should stored
#'
#' @details
#'   First the grViz object is exported to an SVG file (using \code{DiagrammeRsvg::export_svg}).
#'   Then the SVG file is converted to a bitmap (using \code{rsvg::rsvg}).
#'   Then the bitmap is exported as a PNG file (using \code{png::writePNG}).
#'   Note that the SVG file and the PNG file will be named using the name of the \code{g} parameter
#'
#' @note
#'   In addition to the DiagrammmeR package, the following packages are needed: DiagrammeRsvg, rsvg, png
#'
#' @export
#'


grVizToPNG <- function (g, width = 3000, folder = ".") {
    argname <- sapply(as.list(substitute({g})[-1]), deparse)
    message <- capture.output(svg <- DiagrammeRsvg::export_svg(g))
    rsvg::rsvg_png(charToRaw(svg),paste0(folder,"/",argname, ".png"), width = width)
}


#' @title Parallel version of the any function
#'
#' @author Nick Barrowman
#'
#' @description
#'   Perform an element-wise any of a group of logical vectors.
#'
#' @param ...   a group of logical vectors
#' @param na.rm Remove missing values first?
#'
#' @seealso See the \code{any} function in base R.
#' See also \code{pmax}.
#'
#' @export
#'
pany <- function(...,na.rm=FALSE) {
  mat <- cbind(...)
  apply(mat,1,any,na.rm=na.rm)
}

#' @title Parallel version of the all function
#'
#' @author Nick Barrowman
#'
#' @description
#'   Perform an element-wise any of a group of logical vectors.
#'
#' @param ...   a group of logical vectors
#' @param na.rm Remove missing values first?
#'
#' @seealso See the \code{all} function in base R.
#' See also \code{pmax}.
#'
#' @export
#'
pall <- function(...,na.rm=FALSE) {
  mat <- cbind(...)
  apply(mat,1,all,na.rm=na.rm)
}


#' @title [sum] a group of vectors, e[x]cluding [NA]s.
#'
#' @author Nick Barrowman
#'
#' @description
#'   Perform an element-wise sum of a group of vectors, excluding missing values.
#'   In other words treat NA's as zeros, except when the
#'   corresponding elements of all of the vectors are NAs,
#'   in which the result for that element is NA.
#'
#' @param ... a group of vectors
#'
#' @export
#'

sumxNA <- function(...) {
  #
  # {sum} a group of vectors, e{x}cluding {NA}s.
  # In other words treat NA's as zeros, except when the
  # corresponding elements of all of the vectors are NAs,
  # in which the result for that element is NA.
  #

  argname <- sapply(as.list(substitute({...})[-1]), deparse)

  LIST <- list(...)

  for (i in 1:length(LIST)) {
    vec <- LIST[[i]]
    if (is.null(vec)) stop(paste(argname[i],"is NULL.\n"))
  }

  z <- cbind(...)
  q <- z
  q[is.na(z)] <- 0
  result <- apply(q,1,sum)
  allna <- apply(z,1,function(x) all(is.na(x)))
  if (any(allna))
    result[allna] <- NA
  result
}



#' @title Hijack a function
#'
#' @author Tyler Rinker  \url{https://www.r-bloggers.com/hijacking-r-functions-changing-default-arguments/} or the original post at \url{https://trinkerrstuff.wordpress.com/2014/08/19/hijacking-r-functions-changing-default-arguments-3/}
#'
#' @description
#'   \code{hijack} Hijack the template of a function
#'
#' @param FUN the original function
#' @param ... default arguments
#'
#' @examples
#' npct <- hijack(npct, showN = TRUE,
#'   shown = TRUE, showp = TRUE, nmiss = TRUE, nmiss0 = FALSE)
#'
#' medianIQR <- hijack(medianIQR, nmiss0 = TRUE)
#'
#' @export
#'

hijack <- function (FUN, ...) {
    .FUN <- FUN
    args <- list(...)
    invisible(lapply(seq_along(args), function(i) {
        formals(.FUN)[[names(args)[i]]] <<- args[[i]]
    }))
    .FUN
}


#' @title Put a legend above a graph (base graphics)
#'
#' @author Nick Barrowman
#'
#' @description
#'   \code{legendabove} Put a legend above a graph (base graphics).
#'
#' @param xpos the x position of the left side of the legend box
#' @param yrel the relative y position of the bottom of the legend box
#' @param xrel the relative x position of the left side of the legend box
#' @param log  character string: which axes are using log scales?
#' @param ...  arguments to pass the the legend function
#'
#' @export
#'
legendabove <- function(xpos,yrel=0.1,xrel,log="",...) {
# -----------------------------------------------------------------
# Get the overall dimensions of the plot
usr <- par()$usr; xlo<-usr[1]; xhi<-usr[2]; ylo<-usr[3]; yhi<-usr[4]
xr <- xhi-xlo; yr <- yhi-ylo; xmid=(xlo+xhi)/2; ymid=(ylo+yhi)/2
# -----------------------------------------------------------------
# Get the dimensions of the plot in inches
pin <- par()$pin; widthInches <- pin[1]; heightInches <- pin[2]
xUnitsPerInch <- xr/widthInches; yUnitsPerInch <- yr/heightInches
# -----------------------------------------------------------------

  if (!missing(xrel)) {
    xpos <- xlo+xr*xrel
  } else
  if (missing(xpos)) xpos <- xlo

  ypos <- yhi+yr*yrel

  if (log=="xy") { xpos <- 10^xpos; ypos <- 10^ypos }
  if (log=="x")  { xpos <- 10^xpos }
  if (log=="y")  { ypos <- 10^ypos }

  par(xpd=TRUE)
  legend(xpos,ypos,...)
  par(xpd=FALSE)
}


#' @title Update the CRUmisc package
#' @author Nick Barrowman
#' @description
#' Install the latest version of CRUmisc from the source tarball in R:/CRU Epibiostat/CRUpackages
#' @details
#' Assuming that a version of CRUmisc has been previously installed, it can be updated to the latest version by typing: \code{CRUmisc::up()}
#'
#' @export
#'

up <- function() {
  cat("Current version:",paste(packageVersion("CRUmisc")),"\n")
  out <- tryCatch(
    {
      detach("package:CRUmisc",unload=TRUE)
    },
    error=function(cond) {
      message(cond,"\n")
    }
  )
  install.packages(
    list.files(
      path="R:/CRU Epibiostat/CRUpackages",
      pattern="CRUmisc.*.tar.gz",full.names=TRUE),
    repos=NULL,type="source")

  cat("Updated version:",paste(packageVersion("CRUmisc")),"\n")
}


#' @title PRISMA Flowchart
#' @author Vid Bijelic
#'
#' @description
#'  \code{prismaFlow} Create a PRISMA (Preferred Reporting Items for Systematic Reviews and Meta-Analyses) flowchart.
#' @import diagram
#' @param ndb	 number of records identified through database searching
#' @param noth	 number of records identified through other sources
#' @param ndup	 number of duplicate records removed
#' @param nrecex number of excluded records in the first screening
#' @param nfulex number of full-text articles excluded
#' @param nmet   number of studies included in meta-analysis
#'
#'
#' @export
#'
#'
prismaFlow <- function(ndb,noth,ndup,nrecex,nfulex,nmet,
  radxl=.11,radyl=.05,shadowl=.0,cexl=0.75){

  if (!requireNamespace("diagram", quietly = TRUE)) {
    stop("Package \"diagramg\" needed for this function to work. Please install it.",
      call. = FALSE)
  }


  openplotmat(main = "");
  pos <- coordinates(c(2,1,2,2,1,1))
  pos[c(4,6),1] <- .50

  textroundl <- hijack(textround, lab = "", radx=0.09, rady=0.015,
    angle = 90, cex = .65, box.col = "lightblue",shadow.size = 0)
  textroundl(c(.1,sum(pos[3:4, 2])/1.5))
   text(0.1,sum(pos[3:4, 2])/1.5, "Identification", srt=90, cex = .85)
  textroundl(c(.1,sum(pos[3:4, 2])/2))
   text(0.1,sum(pos[3:4, 2])/2, "Screening", srt=90, cex = .85)
  textroundl(c(.1,sum(pos[c(4,6,8), 2])/3))
   text(0.1,sum(pos[c(4,6,8), 2])/3, "Eligibility", srt=90, cex = .85)
  textroundl(c(.1,sum(pos[c(8,9), 2])/2))
   text(0.1,sum(pos[c(8,9), 2])/2, "Included", srt=90, cex = .85)

  lab0 <- c(
    paste0("Records identified through \ndatabase searching \n(n=",ndb,")"),
    paste0("Additional records identified \nthrough other sources \n(n=",noth,")"),
    paste0("Duplicates records removed \n(n=",ndup,")"),
    paste0("Records screened \n(n=",(ndb<-ndb+noth-ndup),")"),
    paste0("Records excluded \n(n=",nrecex,")"),
    paste0("Full-text articles assessed \nfor eligibility \n(n=",(ndb<-ndb-nrecex),")"),
    paste0("Full-text articles excluded \n(n=",nfulex,")"),
    paste0("Studies included in \nqualitative analysis \n(n=",(ndb<-ndb-nfulex),")"),
    paste0("Studies included in \nquantitative synthesis \n(n=",nmet,")")
    )

  bentarrow(from=pos[1,],to=pos[3,]-c(.05,0),path = "H",lcol="black",
    arr.length = 0.2, arr.width= .2,arr.type = "triangle")
  bentarrow(from=pos[2,],to=pos[3,]+c(.05,0),path = "H",lcol="black",
    arr.length = 0.2, arr.width= .2,arr.type = "triangle")
  straightarrow(from=pos[3,],to=pos[4,],arr.length=.2,arr.width=.2,arr.type="triangle")
  straightarrow(from=pos[4,],to=pos[5,],arr.length=.2,arr.width=.2,arr.type="triangle")
  straightarrow(from=pos[4,],to=pos[6,],arr.length=.2,arr.width=.2,arr.type="triangle")
  straightarrow(from=pos[6,],to=pos[7,],arr.length=.2,arr.width=.2,arr.type="triangle")
  straightarrow(from=pos[6,],to=pos[8,],arr.length=.2,arr.width=.2,arr.type="triangle")
  straightarrow(from=pos[8,],to=pos[9,],arr.length=.2,arr.width=.2,arr.type="triangle")

  for(i in 1:nrow(pos)) textrect(pos[i, ], lab = lab0[i],
            radx=radxl, rady=radyl, cex = cexl, shadow.size=shadowl)
}


#' @title Exclusion Flowchart
#' @author Vid Bijelic
#'
#' @description
#'  \code{excludeFlow} Create a flowchart of excluded records.
#' @import diagram
#' @param la		list of nodes' content to plot (list of vectors of strings to be shown one per line)
#' @param ttl		flowchart title
#' @param lgnd		flowchart legend
#' @param radxl		node width parameter
#' @param radyl		node height parameter
#' @param lcoll		node colour parameter
#' @param cexl		node text size parameter
#' @param shadowl	node shadow parameter
#'
#'
#' @export
#'
#'
excludeFlow <- function(la,ttl="",lgnd=NULL,radxl=.11,radyl=.09,lcoll=1,shadowl=.0,cexl=1){

  if (!requireNamespace("diagram", quietly = TRUE)) {
    stop("Package \"diagramg\" needed for this function to work. Please install it.",
      call. = FALSE)
  }

  openplotmat(main = ttl)
  if(!is.null(lgnd))
    legend("topleft", legend=c(lgnd,date()),cex = cexl)

  pos <- coordinates(rep(1,length(la)))
  pos[seq(2,nrow(pos),2),1] <- .75

  for(i in 1:(nrow(pos)-1)){
      if(i %in% (1:nrow(pos))[1:nrow(pos) %% 2 == 0]){
        bentarrow(from=pos[i,],to=pos[i+1,],path = "H",lcol="black")
      } else {
        bentarrow(from=pos[i,],to=pos[i+1,],path = "V",lcol="black")
      }
  }

  for(i in 1:nrow(pos)){
      textrect(pos[i, ], lab = la[[i]],
          radx=radxl, rady=radyl, cex = cexl)
  }
}


#' @title Source the CRUmisc code for testing purposes
#' @author Nick Barrowman
#'
#' @description
#'  
#' @param path Path to the CRUmisc source
#'
#' @export
#'
sourceCRUmisc <- function(path="./") {
  source(paste0(path,"R/CRUmisc.R")); load(paste0(path,"data/FakeData.rda"))
}

