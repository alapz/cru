source("/home/nbarrowman/vdrive/CRU Epibiostat/projects/Nick/0/CRUmarkdown/R/CRUmarkdown.R"); load("/home/nbarrowman/vdrive/CRU Epibiostat/projects/Nick/0/CRUmarkdown/data/FakeData.rda")
