#' @name CRUmarkdown
#' @title
#' CRUmarkdown: Tools developed at the Clinical Research Unit for flexibly generating pandoc Markdown syntax.
#' @description
#' Tools developed at the CHEO Clinical Research Unit
#' for flexibly generating pandoc Markdown syntax.
#' @details
#' The CRUmarkdown package provides tools for flexibly generating pandoc Markdown syntax.
#' in R Markdown.
#' The package was developed by the Clinical Research Unit
#' at the Children's Hospital of Eastern Ontario Research Institute (CHEORI).
#' The FakeData object contains made-up data for use in examples.
#'
#' @docType package
NULL

# Folding tables
fold <- function(w,rows,cnames,sep="") {

  x <- matrix(as.character(as.matrix(w)),nrow=nrow(w),ncol=ncol(w))

  colnames(x) <- colnames(w)

  if (nrow(x)<=rows) return(x)

  while (nrow(x) %% rows != 0) {
    x <- rbind(x,rep(sep,ncol(x)))
  }

  ROWS <- nrow(x)

  result <- x[1:rows,,drop=FALSE]
  if (!missing(cnames)) resultnames <- cnames

  for (i in 2:(ROWS/rows)) {
    cn <- colnames(result)
    result <- cbind(result,sep,x[(1+(i-1)*rows):(i*rows),,drop=FALSE])
    if (!is.null(colnames(x))) {
      colnames(result) <- c(cn,sep,colnames(x[(1+(i-1)*rows):(i*rows),,drop=FALSE]))
    }
    if (!missing(cnames)) resultnames <- c(resultnames,sep,cnames)
  }

  if (is.null(colnames(x))) {
    colnames(result) <- rep(sep,ncol(result))
  }

  rownames(result) <- NULL

  if (!missing(cnames)) attributes(result)$cnames <- resultnames
  result
}



# function to calculate OR and confidence interval
orciordinal <- function(z) {
# [o]dds [r]atios and [c]onfidence [i]ntervals from an ordinal fitted model object

  if (class(z)=="polr") {
    x <- data.frame(z$coefficients)
    or <- exp(x[,"z.coefficients"])
    ci<-exp(confint.default(z, level=0.95))
    cilo <- ci[,"2.5 %"]
    cihi <- ci[,"97.5 %"]

}
  cbind(cilo,or,cihi)
}

# function to apply to orciordinal above to put the or and CI together
orcordinal<- function(orciordinal, rowname) {
  #
  # Format estimate and confidence interval
  #
  paste(
               around(orciordinal[rowname,"or"]),
               " (",
               around(orciordinal[rowname,"cilo"]),
               "-",
               around(orciordinal[rowname,"cihi"]),
               ")",
                 sep=""
  )
}


# function to get the p value from the model immediately. (package MASS doesn’t give p values, so will be helpful), package (ordinal) gives p values but this will be simpler to apply
p_ordinal<- function(z){
  x<-coef(summary(z))
p <- around(pnorm(abs(x[, "t value"]), lower.tail = FALSE) * 2 ,2)

}



#' @title Split character strings with newline characters
#' @author Nick Barrowman
#' @description
#' Split character strings at specified characters (space, hyphen, etc.) with newline characters
#'
#' @param x      a vector of character strings
#' @param width  minimum number of characters before a newline is inserted
#' @param sp     newline character to insert
#' @param at     vector of characters to split at
#' @param same   Same number of splits in each element?
#'
#' @export
splitlines <- function (x, width = 10, sp = "\n", at = c(" ", "/", "-", "+"), same = FALSE) {

  n <- nchar(x)
  nsp <- nchar(sp)
  result <- rep("", length(x))
  splits <- rep(0, length(x))
  if (is.null(x) || (length(x)==0)) return(NULL)
  for (i in 1:length(x)) {
      count <- 0
      start <- 1
        for (j in 1:(n[i])) {
          count <- count + 1
          char <- substring(x[i], j, j)
          if (char %in% at) {
              if (count > width) {
                if (char == " ") {
                  end <- j - 1
                }
                else {
                  end <- j
                }
                result[i] <- paste0(result[i], substring(x[i],
                  start, end), sp)
                start <- j + 1
                count <- 0
                splits[i] <- splits[i] + 1
              }
          }
      }
      if (start <= n[i])
          result[i] <- paste0(result[i], substring(x[i], start,
              n[i]))
  }
  if (same) {
      maxsplits <- max(splits)
      for (i in 1:length(x)) {
          while (splits[i] < maxsplits) {
              result[i] <- paste0(result[i], sp)
              splits[i] <- splits[i] + 1
          }
      }
  }
  result
}


#' @title Show boilerplate text.
#' @author Nick Barrowman
#' @description
#' Show boilerplate text.
#'
#' @export
boilerplate <- function( ) {
  paste0(
  "#########
# About this report

This report,
dynamically generated using R Markdown,
contains results as of ",
strftime(Sys.time(),format="%B %d, %Y at %I:%M%P"),".
To ensure that results in your manuscript or presentation are consistent,
up-to-date, and reproducible,
all of the figures, tables, and values
should be copied from the most recent report.
If you spot any inconsistencies, or have any questions, please let us know.

## Common abbreviations
|
---------------|------------------------------------------------------------------------------------------------------------------------
mv             | missing value
CI             | confidence interval (commonly the 95% confidence interval)
SD             | standard deviation
IQR            | interquartile range, i.e. 25th and 75th percentiles, representing the middle 50% of the data

## Extracting figures from this report

It is possible to copy figures directly from this report.
However figures copied from Microsoft Word into another program often suffer degraded resolution.
The following steps will allow you to extract all figures from the report as separate files without loss of resolution.

* Select **File** &rarr; **Save As**
* Near the bottom of the dialog box, in **Save as type**, specify **Web Page (&#42;.htm;&#42;.html)**;
* Click the **Save** button.

An HTML file will be created together with a folder (whose name ends with `_files`) containing the figures. *Caution*: The folder will contain low and high resolution versions of the figures. *Note*: If the resolution/DPI is insufficient, let us know and we will generate high resolution figures.

## A note on authorship

Authorship should be granted for CRU participation in research provided the [criteria for authorship](http://www.icmje.org/recommendations/browse/roles-and-responsibilities/defining-the-role-of-authors-and-contributors.html#two) of the International Committee of Medical Journal Editors (ICMJE) are met.

## The Clinical Research Institute (CRU)

The CRU is supported by the Children's Hospital Academic Medical Organization (CHAMO) and the CHEO Research Institute.
Follow this link for more information about the [CRU](http://www.cheori.org/en/clinicalresearchunit).
Also, check out our [How To guides](http://www.cheori.org/en/cruhowto).")
}


#' @title Display an alert message if a specified condition is met.
#' @author Nick Barrowman
#' @description
#' Display an alert message using Pandoc Markdown's block quote syntax.
#'
#' @param message    a character string giving the message to display
#' @param condition  Display the message?
#' @param separated  Generate a blank line after the message?
#'
#' @export
Alert <- function(message,condition=TRUE,separated=FALSE) {
#
# NJB 21-Jul-2017
#
  if (condition & message!="") {
    markdown <- paste(">",message)
    if (separated) markdown <- paste0(markdown,"\n\n\\ \n\n")
    markdown
  }
}

#' @title [categ]orical function
#' @author Nick Barrowman
#' @description
#' Generate one or more table rows to summarize a categorical variable
#'
#' @param w          a categorical variable
#' @param heading    a descriptive label for the variable
#' @param indent     number of spaces to indent each level of the variable (Default 5)
#'
#' @return a labelled series of rows for each level of a categorical variable
#' that also returns the value(s) for a user specified executed function
#' (i.e. npct, meanSD, etc.)
#'
#'
#' @export

categ <- function(w,heading,indent=5) {

  # If heading is not specified, use the actual name of the w argument.
  if (missing(heading)) heading <- sapply(as.list(substitute({w})[-1]), deparse)

  if (length(w)==0) stop("w has length zero.")
  spaces <- paste(rep("&nbsp;",indent),collapse="")
  values <- sort(unique(w))
  n <- length(values)
  if (n==1) {
    groupOfRows <- ""
  } else {
    groupOfRows <- paste(tablerow(heading,"","","",""),"\n")
  }
  i <- 0
  for (value in values) {
    i <- i+1
    if (n==1) {
      col1 <- heading
    } else {
      col1 <- paste(spaces,value,sep="")
    }

    row <- tablerow(            # These lines specify what goes in each
      col1,                     # column (except for header rows).
      npct(w)[[paste(value)]],  #
      "other stuff1",           #
      "other stuff2"            #
    )

    groupOfRows <- paste(groupOfRows,row,sep="")
    if (i<n)
      groupOfRows <- paste(groupOfRows,"\n",sep="")
  }

  groupOfRows
}


#' @title [categ]orical function version 2
#' @author Nick Barrowman
#' @description
#' Generate one or more table rows to summarize a categorical variable
#'
#' @param w          a categorical variable
#' @param heading    a descriptive label for the variable
#' @param indent     number of spaces to indent each level of the variable (Default 5)
#' @param nmiss      to be passed to npct
#' @param missingrow show a row for missing values?
#'
#' @return a labelled series of rows for each level of a categorical variable
#' that also returns the value(s) for a user specified executed function
#' (i.e. npct, meanSD, etc.)
#'
#'
#' @export

categ2 <- function (w, heading, indent = 5, nmiss=FALSE, missingrow=TRUE) {
    if (missing(heading))
        heading <- sapply(as.list(substitute({
            w
        })[-1]), deparse)
    if (length(w) == 0)
        stop("w has length zero.")
    spaces <- paste(rep("&nbsp;", indent), collapse = "")
    values <- sort(unique(w))
    n <- length(values)
    if (n == 1) {
        groupOfRows <- ""
    }
    else {
        groupOfRows <- paste(tablerow(heading, "", "", "", ""),
            "\n")
    }
    i <- 0
    for (value in values) {
        i <- i + 1
        if (n == 1) {
            col1 <- heading
        }
        else {
            col1 <- paste(spaces, value, sep = "")
        }
        row <- tablerow(col1, npct(w,nmiss=nmiss)[[paste(value)]], "other stuff1",
            "other stuff2")
        groupOfRows <- paste(groupOfRows, row, sep = "")
        if (i < n)
            groupOfRows <- paste(groupOfRows, "\n", sep = "")
    }
    if (missingrow & any(is.na(w))) {
      col1 <- paste(spaces, "Missing", sep = "")
      row <- tablerow(col1, sum(is.na(w)),"other stuff1",
            "other stuff2")
      if (length(values)>0) {
        groupOfRows <- paste(groupOfRows, "\n",row, sep = "")
      } else {
        groupOfRows <- paste(groupOfRows, row, sep = "")
      }
    }
    groupOfRows
}


#' @title [multi]ple [categ]orical table function
#' @author Nick Barrowman
#' @description
#' Generate one or more pipetable rows to summarize a categorical variable
#'
#' @param heading     a descriptive label for the variable
#' @param ...         vectors corresponding to the columns of the table
#' @param vars        alternatively, a list of named vectors corresponding to the columns of the table
#' @param pcs         to be passed to the npct function (percentage symbol)
#' @param indent0     number of spaces to indent heading
#' @param indent1     number of spaces to indent row below heading
#' @param header      generate a table header (i.e. a complete pipetable)?
#' @param headercount if header=TRUE, should N= be show in each column?
#' @param vp          use valid percentages? (i.e. omit missing values from denominator)
#' @param show0missing show Missing row even if there are no missing values
#'
#' @return a character string of markdown pipe-table rows
#'
#' @details
#' If there are no missing values, a Missing row will not be shown.
#'
#' @examples
#'
#' pet <- c("dog","cat","fish","lizard",NA)
#'
#' # R Markdown example: Single variable, automatic header
#'
#' `r multicateg("**Pet**",
#'   rep(pet,rmultinom(1,10,prob=rep(1,length(pet)))[,1]),
#'   header=TRUE)`
#'
#' # R Markdown example: Multiple variables, automatic header
#'
#' `r pet <- c("dog","cat","fish","lizard",NA)
#'    multicateg("**Pet**",
#'      vars=list(
#'        one=rep(pet,rmultinom(1,10,prob=rep(1,length(pet)))[,1]),
#'        two=rep(pet,rmultinom(1,1000,prob=rep(1,length(pet)))[,1]),
#'        three=rep(pet,rmultinom(1,3,prob=rep(1,length(pet)))[,1]),
#'        four=rep(pet,rmultinom(1,50,prob=rep(1,length(pet)))[,1]),
#'        five=rep(pet,rmultinom(1,1000,prob=rep(1,length(pet)))[,1]),
#'        six=rep(pet,rmultinom(1,50,prob=rep(1,length(pet)))[,1])),
#'      pcs="%",header=TRUE)`
#'
#' # R Markdown example: One column showing two variables, manual header
#'
#' `r pet <- c("dog","cat","fish","lizard",NA)`
#' `r icecream <- c("vanilla","chocolate","strawberry")`
#' | Variable | Value        |
#' |:---------|:-------------|
#' `r multicateg("**Pet**",
#'      rep(pet,rmultinom(1,10,prob=rep(1,length(pet)))[,1]))`
#' `r multicateg("**Favorite ice cream**",
#'      rep(icecream,rmultinom(1,1000,prob=rep(1,length(icecream)))[,1]))`
#'
#' # Single column, self-contained table, show percent sign
#'
#' multicateg("**Pet**",
#'   rep(pet,rmultinom(1,10,prob=rep(1,length(pet)))[,1]),
#'   pcs="%",header=TRUE)
#'
#' # Multiple columns, self-contained table, show percent sign
#'
#' multicateg("**Pet**",
#'  vars=list(
#'    one=rep(pet,rmultinom(1,10,prob=rep(1,length(pet)))[,1]),
#'    two=rep(pet,rmultinom(1,1000,prob=rep(1,length(pet)))[,1]),
#'    three=rep(pet,rmultinom(1,3,prob=rep(1,length(pet)))[,1]),
#'    four=rep(pet,rmultinom(1,50,prob=rep(1,length(pet)))[,1]),
#'    five=rep(pet,rmultinom(1,1000,prob=rep(1,length(pet)))[,1]),
#'    six=rep(pet,rmultinom(1,50,prob=rep(1,length(pet)))[,1])),
#'  pcs="%",header=TRUE)
#'
#' @export

multicateg <- function(heading,...,vars=NULL,pcs="",indent0=0,indent1=4,
  header=FALSE,headercount=TRUE,vp=TRUE,show0missing=FALSE) {

  varsProvided <- !is.null(vars)

  if (varsProvided) {
    varnames <- names(vars)
    arguments <- vars
    colnames <- varnames
  } else {
    arguments <- list(...)
    colnames <- rep("&nbsp;",length(arguments)) # sapply(as.list(substitute({...})[-1]), deparse)
  }

  allLogical <- TRUE
  for (i in 1:length(arguments)) {
    allLogical <- allLogical & is.logical(arguments[[i]])
  }

  if (allLogical) samelevels <- TRUE

  sampleSizes <- sapply(arguments,length)

  u <- NULL

  if (allLogical) {
    levels <- c(TRUE,FALSE)
  } else {
    prevlevels <- levels(arguments[[1]])
    if (is.null(prevlevels)) {
      prevlevels <- unique(arguments[[1]])
      prevlevels <- prevlevels[!is.na(prevlevels)]
    }

    samelevels <- TRUE
    if (length(arguments)==1) {
      if (is.factor(arguments[[1]])) {
        levels <- levels(arguments[[1]])
        samelevels <- TRUE
      } else {
        samelevels <- FALSE
      }
    } else {
      for (arg in arguments[-1]) {
        if (is.null(levels(arg))) {
          arglevels <- unique(arg)
        } else {
          arglevels <- levels(arg)
        }
        if (!setequal(arglevels,prevlevels)) samelevels <- FALSE
      }
      if (samelevels) levels <- prevlevels
    }
  }

  anyMissing <- FALSE
  for (arg in arguments) {
    un <- unique(as.character(arg))
    u <- c(un[!is.na(un)],u)
    anyMissing <- anyMissing | any(is.na(un))
  }
  if (!samelevels) levels <- sort(unique(u))

  if (anyMissing|show0missing) {
    augmented_levels <- c(levels,"Missing")
  } else {
    augmented_levels <- levels
  }

  if (allLogical) {
    tab1 <- c()
    for (arg in arguments) {
      tab1 <- cbind(tab1,
        npct(factor(arg,levels=levels),nmiss=FALSE,pcs=pcs,vp=vp)["TRUE"])
    }
    left <- paste0(paste(rep("&nbsp;",indent0),collapse=""),heading,", n(%)")
    if (anyMissing|show0missing) {
      left <- cbind(c(left,
        paste0(paste(rep("&nbsp;",indent1),collapse=""),c("Missing"))))
      tab2 <- c()
      for (arg in arguments) {
        if (vp) {
          tab2 <- cbind(tab2,sum(is.na(arg)))
        } else {
          tab2 <- cbind(tab2,
            npct(is.na(factor(arg,levels=levels)),pcs=pcs,vp=vp)["TRUE"])
        }
      }
      tab <- cbind(left,rbind(tab1,tab2))
    } else {
      tab <- cbind(left,tab1)
    }
    rownames(tab) <- NULL

  } else {
    tab <- cbind(
      paste0(paste(rep("&nbsp;",indent1),collapse=""),augmented_levels))

    if (anyMissing|show0missing) {
      if (vp) {
        for (arg in arguments) {
          tab <- cbind(tab,
            c(npct(factor(arg,levels=levels),nmiss=FALSE,pcs=pcs,vp=vp),sum(is.na(arg))))
        }
      } else {
        for (arg in arguments) {
          tab <- cbind(tab,
            c(npct(factor(arg,levels=levels),nmiss=FALSE,pcs=pcs,vp=vp),
              npct(is.na(factor(arg,levels=levels)),pcs=pcs)["TRUE"]))
        }
      }
    } else {
     for (arg in arguments) {
        tab <- cbind(tab,
          c(npct(factor(arg,levels=levels),nmiss=FALSE,pcs=pcs,vp=vp)))
     }
    }

    tab <- rbind(
      c(
        paste0(paste(rep("&nbsp;",indent0),collapse=""),heading,", n(%)"),
        rep("",length(arguments))),
      tab)
  }

  mdt <- markdownTable(tab,showrownames=FALSE,finalLineBreak=FALSE)

  if (header) {
    if (headercount) {
      colheadings <- paste0(colnames,"\\\nN=",sampleSizes)
    } else {
      colheadings <- colnames
    }
    hdr1 <- paste0("|&nbsp;|",paste(colheadings,collapse="|"),"|\n")
    hdr2 <- paste0(paste(rep("|:-",length(colnames)+1),collapse=""),"|\n")

    paste0(hdr1,hdr2,mdt)
  } else {
    mdt
  }
}


#' @title [o]dds [r]atios and [c]onfidence [i]ntervals
#' @author Nick Barrowman
#' @description
#' \code{orci} Calculates Odds Ratio & Confidence Intervals from a fitted model object
#' @param z a fitted model object
#'
#' @return a table with odds ratios & confidence intervals from a fitted model object
#'
#' @export
#'

orci <- function(z) {


  if (class(z)[1]=="glm") {
    x <- summary(z)$coef
    or <- exp(x[,"Estimate"])
    orlo <- exp(x[,"Estimate"]-1.96*x[,"Std. Error"])
    orhi <- exp(x[,"Estimate"]+1.96*x[,"Std. Error"])
  } else
    if (class(z)[1]=="lrm") {
      lor <- fit$coefficients
      se <- sqrt(diag(fit$var))
      or <- exp(lor)
      orlo <- exp(lor-1.96*se)
      orhi <- exp(lor+1.96*se)
    } else
      stop("Only works for objects of class glm or lrm")

  cbind(orlo,or,orhi)
}


#' @title [pipetablepipetable][header]
#' @author Nick Barrowman
#' @description
#' \code{pipetableheader}  Make a pipetable header.
#'
#' @param x            a matrix, data frame, or vector
#' @param ndashes      optional parameter: a numeric vector the same length
#'                     as \code{x} specifying the number of dashes
#'                     corresponding each column in the header row. If not
#'                     provided, the number of dashes will be automatically
#'                     calculated based on the number of characters in each
#'                     element of x.
#' @param bold         Make each of the column headings bold.
#'
#' @return             a character string containing the pipetable header
#' @examples
#' pipetableheader(FakeData)
#' @export
#'
pipetableheader <- function(x,ndashes,bold=FALSE) {

  if (bold) x <- paste0("**",x,"**")

  if (missing(ndashes)) {
    ndashes <- nchar(x)
    ndashes <- rep(5,length(x))   # over-ride
  } else {
    if (is.null(ndashes)) {
      ndashes <- nchar(x)
      ndashes <- rep(5,length(x))   # over-ride
    }
  }



  header <- paste0("|",paste(x,collapse="|"),"|")

  row <- ""
  for (i in 1:length(x)) {
    row <- paste0(row,paste(rep("-",ndashes[i]),collapse=""),"|")
  }

  row <- paste0(header,"\n",row)

  row
}


#' @title Generate a string of (nonbreaking) spaces.
#' @author Nick Barrowman
#' @description Generate spaces (typically used for indentation in tables).
#'
#' @param n            Number of spaces.
#' @export
#'
spaces <- function(n) {
  paste(rep("&nbsp;",n),collapse="")
}


#'
#' @title [pipetable]
#' @author Nick Barrowman
#' @description
#' \code{pipetable}  Make a pipetable
#'
#' @param x            Matrix, data frame, or vector.
#' @param labels       Vector of column labels.
#' @param columns      More convenient way to specify column labels (compared to \code{labels}).
#'                     A vector whose names represent the new column labels and whose
#' @param rows         Like \code{columns} but for specifying row labels.
#'                     A vector whose names represent the new rows labels and whose
#'                     values represent the old row labels.
#' @param ndashes      A vector of integers specifying how many spaces to allocate for each column.
#' @param sizecol      Size the columns automatically?
#' @param boldrownames Show the row names in bold?
#' @param bolccolnames Show column names in bold?
#' @param showrownames Show the rownames?
#' @param topleft      Text to put in the top left cell of the table if rownames are being shown.
#' @param llspace      Should leading spaces be replaced by non-breaking spaces?
#'                     (Otherwise they are simply removed.)
#' @param blank0       Leave blank any cells containing zero?
#' @param frows        Number of rows to fold in the table
#' @param digits       Number of digits to display for numeric variables.
#' @param style        Custom style (for docx).
#' @param dashline     Include a line of dashes at the top of the table?
#'                     Setting this FALSE may be useful if several tables are glued together.
#'
#' @return             A character string containing the pipetable.
#' @examples
#' pipetable(FakeData)
#' @export
#'
pipetable <- function (x, labels, columns, rows, ndashes, sizecol = TRUE, boldrownames = TRUE,
    boldcolnames = TRUE, showrownames = FALSE, topleft = "", llspace = TRUE,
    blank0 = FALSE, frows=0,digits,style="",dashline=TRUE)
{
    if (is.data.frame(x)) {
        if (nrow(x) == 0) {
            stop("Data frame with no rows.")
        }
    }
    if (is.matrix(x)) {
        if (nrow(x) == 0) {
            stop("Matrix with no rows.")
        }
    }
    if (length(x) == 0) {
        stop("Object of length zero.")
    }
    rn <- rownames(x)
    if (!is.matrix(x) & !is.data.frame(x)) {
      if (frows>0) {
        x <- cbind(x)
        colnames(x) <- NULL
        cnames <- NULL
      } else {
        if (length(x) == 0)
          return()
        if (!missing(labels) && length(labels) == 2) {
          cnames <- labels
          x <- cbind(names(x), x)
        } else {
          cnames <- names(x)
          x <- rbind(x)
        }
        rownames(x) <- NULL
      }
    } else {
        cnames <- colnames(x)
    }

    if (frows>0) {
      if (!is.null(rn)) {
        if (showrownames) {
          x <- cbind("&nbsp;"=rn,x)
          cnames <- c("&nbsp;",cnames)
        }
      }
      if (is.null(cnames)) {
        x <- fold(x,frows,sep="&nbsp;")
      } else {
        x <- fold(x,frows,cnames=cnames,sep="&nbsp;")
      }
      if (is.null(attributes(x)$cnames)) {
        cnames <- colnames(x)
      } else {
        cnames <- attributes(x)$cnames
      }
    }

    if (!missing(labels)) {
        if (length(labels) != ncol(x)) {
            stop("Length of labels argument is not equal to number of columns of x.")
        }
        cnames <- labels
    }
    if (!missing(columns)) {
        for (i in 1:length(columns)) {
            cn <- columns[i]
            if (cn %in% colnames(x)) {
                m <- match(cn, colnames(x))
                cnames[m] <- names(columns)[i]
            }
        }
    }
    if (is.null(cnames)) {
        cnames <- rep("&nbsp;", ncol(x))
    }
    if (!missing(rows)) {
        for (i in 1:length(rows)) {
            rn <- rows[i]
            if (rn %in% rownames(x)) {
                m <- match(rn, rownames(x))
                rownames(x)[m] <- names(rows)[i]
            }
        }
    }
    if (is.null(cnames)) {
        cnames <- rep("&nbsp;", ncol(x))
    }
    else {
        if (boldcolnames) {
            nonWhiteSpace <- grep("^ *$", cnames, invert = TRUE)
            bolded <- paste0("**", cnames, "**")
            cnames[nonWhiteSpace] <- bolded[nonWhiteSpace]
        }
    }
    if (showrownames) {
        if (!is.null(rownames(x))) {
            cnames <- c("&nbsp;", cnames)
            if (topleft != "")
                cnames[1] <- topleft
        }
    }
    if (missing(ndashes)) {
        if (sizecol) {
            ndashes <- nchar(cnames)
        }
        else {
            ndashes <- rep(1, length(cnames))
        }
    }
    if (style!="") {
      cnames <- applydocxStyle(cnames,style)
    }
    header <- paste0("|", paste(cnames, collapse = "|"), "|")
    row <- "|"
    for (i in 1:length(cnames)) {
        row <- paste0(row, paste(rep("-", ndashes[i]), collapse = ""),
            "|")
    }
    if (dashline) {
      row <- paste0(header, "\n", row, "\n")
    } else {
      row <- paste0(header,"\n")
    }
    paste0(row, markdownTable(x, boldrownames = boldrownames,
        showrownames = showrownames, llspace = llspace, blank0 = blank0,
        digits = digits,style=style))
}


#' @title Convert numeric values into a rounded character format with precisely the number of digits specified
#' @author Nick Barrowman
#' @description
#' Convert numeric values into a rounded character format with precisely the number of digits specified.
#' Unlike the ordinary \code{round} function, which will omit trailing zeros, \code{around} will keep them.
#'
#' @param x       a vector
#' @param digits  number of digits to include
#' @param tooLong number of characters before displaying value using scientific notation
#'
#' @return        a rounded numeric vector in character format
#'
#' @examples
#'
#' around(FakeData$Age)
#'
#' [1] "3.00" "4.00" "5.00" "3.00" " NA"  "5.00" "3.00" "4.00" "5.00" "3.00" "4.00" " NA"  "3.00" "4.00" "5.00" "3.00" "4.00"
#' [18] "5.00" " NA"  "4.00" "5.00" "5.00" "5.00"
#'
#' @export
#'
around <- function(x,digits=2,tooLong=10) {

  if (is.data.frame(x)) {
    # Handle data frames
    for (i in 1:ncol(x)) {
      x[[i]] <- around(x[[i]],digits=digits)
    }
    x
  } else
    if (!is.numeric(x)) {
      # Ignore variables that are not numeric
      x
    } else {
      if (digits==0) {
        result <- formatC(x,digits=digits,drop0trailing=TRUE,format="f",flag="#")
        result[nchar(result)>tooLong] <-
          formatC(x[nchar(result)>tooLong],digits=digits,drop0trailing=TRUE,format="g",flag="#")
      } else {
        result <- formatC(x,digits=digits,drop0trailing=FALSE,format="f",flag="#")
        result[is.na(x)] <- "NA"  # This is a fix because for some reason a leading space shows up, like " NA"
        result[nchar(result)>tooLong] <-
          formatC(x[nchar(result)>tooLong],digits=digits,drop0trailing=FALSE,format="g",flag="#")
      }
      result[result=="-0"] <- "0"
      result[result=="-0.0"] <- "0.0"
      result[result=="-0.00"] <- "0.00"
      result[result=="-0.000"] <- "0.000"
      result
    }
}


#' @title [format][p]
#' @author Nick Barrowman
#' @description
#' \code{formatp}  Format p-values nicely
#' @param p        a p-value
#' @param equals   the equals argument is helpful for p-values in text versus in tables
#' @param digits   number of digits to include
#' @param smallest the smallest p-value to show
#' @param missing  Character string to display for a missing p-value
#' @return         a formatted p-value
#' @examples
#' formatp(0.00552) # Good for tables
#' [1] "0.01"
#'
#' formatp(0.00003) # Good for tables
#' [1] "<0.001"
#'
#' formatp(0.00552,equals=TRUE) # Good for text
#' [1] "=0.01"
#'
#' formatp(0.00003,equals=TRUE) # Good for text
#' [1] "<0.001"
#'
#' from a fitted model:
#' formatp(model.name$p.value)
#'
#' @export

formatp <- function(p,equals=FALSE,digits=2,smallest=0.001,missing="-") {
  # NJB, 22-Nov-2016
  #
  # Format p-values nicely.
  #
  # The equals argument is helpful for p-values in text versus in tables.
  # e.g
  # > formatp(0.00552) # Good for tables
  # [1] "0.01"
  # > formatp(0.00003) # Good for tables
  # [1] "<0.001"
  # > formatp(0.00552,equals=TRUE) # Good for text
  # [1] "=0.01"
  # > formatp(0.00003,equals=TRUE) # Good for text
  # [1] "<0.001"
  #

  p[is.nan(p)] <- NA

  output <- rep("",length(p))

  pval <- p[!is.na(p)]
  result <- output[!is.na(p)]

  equalsSign <- "="
  if (!equals) equalsSign <- ""
  result[pval<smallest] <- paste("<",smallest,sep="")
  result[pval>=smallest] <- paste(
    equalsSign,
    formatC(pval[pval>=smallest],
            digits=digits,drop0trailing=FALSE,format="f",flag="#"),
    sep="")
  condition <- (pval>smallest) & (round(pval,digits)==0)
  if (any(condition,na.rm=TRUE)) {
    result[condition] <- paste(
      equalsSign,
      formatC(pval[condition],
              digits=digits+1,drop0trailing=FALSE,format="f",flag="#"),
      sep="")
  }
  result[is.na(pval)] <- paste(equalsSign,"NA",sep="")
  names(result) <- names(pval)

  output[!is.na(p)] <- result
  output[is.na(p)]  <- missing

  output

}



#' @title  [n] and [p]er[c]en[t]
#'
#' @author Nick Barrowman
#'
#' @description
#'  \code{npct} Displays frequency and percentage
#'
#' @param x            A vector.
#' @param vp           Show [v]alid [p]ercentages?
#'                     Valid percentages are computed by first excluding missing values and then calculating percentages.
#' @param digits       Number of decimal places
#' @param pcs          Percentage symbol. Specify "\%" to include a percent symbol.
#' @param empty        Character string to show when x has length 0
#' @param shown        Show numerator?
#' @param showN        Show denominator?
#' @param showp        Show percentage?
#' @param nmiss        Show number of missing values as a superscript?
#' @param nmiss0       If nmiss=TRUE and if there are no missing values, show mv=0?
#' @param includemiss  include count of missing values in the vector of results
#'                     (independent of the nmiss argument)
#' @param showzero     Show zeros?
#' @param percentfirst Show the percentage first?
#' @param comma        Use a comma instead of parentheses?
#' @param style        Optional specification of a style number.
#'
#' @return N(\%)
#' @examples
#' npct(FakeData$Age)
#'
#' 3          4          5
#' "6 (30.0)" "6 (30.0)" "8 (40.0)"
#'
#' npct(FakeData$Age==5)
#'
#' FALSE        TRUE
#' "12 (60.0)"  "8 (40.0)"
#'
#' To return a single value with valid percent:
#'
#' npct(FakeData$Age==5)["TRUE"]
#'
#' "8 (40.0)"
#'
#'
#'
#' @export
#'

npct <- function(x,vp=TRUE,digits=1,pcs="",empty="-",showN=FALSE,sep=" ",
                 shown=TRUE,showp=TRUE,nmiss=FALSE,nmiss0=FALSE,includemiss=FALSE,
                 showzero=TRUE,percentfirst=FALSE,comma=FALSE,style=NA) {

  if (!is.na(style) && (style==1)) {
    showN <- TRUE
    pcs <- "%"
  }

  if (comma) {
    pStart <- paste0(",",sep); pStop <- ""
  } else {
    pStart <- paste0(sep,"(");  pStop <- ")"
  }


  nmissString <- ""
  missingNum <- sum(is.na(x))

  if (nmiss) {
    nmissString <- paste0("mv=",missingNum)
    if (!vp) nmissString <- paste0("[",nmissString,"]")
    nmissString <- paste0("^",nmissString,"^")
    if (!nmiss0 & missingNum==0) nmissString <- ""
  }

  if (vp) { x <- x[!is.na(x)] }

  #
  # The following is important because if x is entirely TRUE or
  # entirely FALSE then the table function will be incomplete
  # (it won't list the zero FALSEs or zero TRUEs).
  #
  if (is.logical(x)) {
    x <- factor(x,c("FALSE","TRUE"))
  }

  #if (length(x)==0 & (!is.factor(x))) return(empty)

  if ((length(x)==0) && (is.factor(x))) {
    result <- rep(empty,length(levels(x)))
    names(result) <- levels(x)
    return(result)
  }

  tab <- table(x,exclude=NULL)
  if (any(is.na(names(tab)))) names(tab)[is.na(names(tab))] <- "NA"
  result <- countStr <- ""
  countStr <- paste0(tab,sep="")
  fracStr <- paste0(tab,"/",length(x))
  percentStr <- paste(around(100*as.numeric(tab)/sum(tab),digits=digits),pcs,sep="")

  if (shown) {
    if (showN) {
      result <- fracStr
    } else {
      result <- countStr
    }
  }
  if (showp) {
    if (shown) {
      result <- paste0(result,pStart,sep="")
    }
    result <- paste0(result,percentStr,sep="")
    if (shown) result <- paste(result,pStop,sep="")
  }

  if (percentfirst & shown & showp) {
    result <- paste(around(100*as.numeric(tab)/sum(tab),digits=digits),pcs,sep="")
    result <- paste0(result,pStart,tab)
    if (showN) result <- paste0(result,"/",length(x))
    result <- paste0(result,pStop)
  }

  if (!is.na(style) && (style==1)) {
    result <- paste0("(",percentStr,", ",fracStr,")")
  }

   if (!is.na(style) && (style==2)) {
    result <- paste0("(",fracStr,", ",percentStr,")")
  }

  if (!showzero) result[!is.na(tab) & tab==0] <- ""
  result <- paste0(result,nmissString,sep="")
  #browser()
  names(result) <- names(tab)
  # Remove the element named "NA" because it may not be wanted
  # and it may have a percentage with it, which we don't want.
  result <- result[names(result)!="NA"]
  # If desired put in an "NA" element with just the count.
  if (includemiss) {
    result["NA"] <- missingNum
    if (missingNum==0 & !showzero) {
      result["NA"] <- ""
    }
  }
  result
}


#' @title [c]ontinuous [desc]riptives
#' @author Nick Barrowman
#' @description Produces custom descriptives for a continuous variable
#'
#' @param x a vector
#' @param format a character string representing the custom descriptives (see Details)
#' @param digits number of digits to include
#' @param na.rm  remove missing values?
#' @param nmiss  show number of missing values as a superscript?
#'
#' @return a character string of custom descriptive statistics
#'
#' @examples
#' cdesc(FakeData$Age,"mean (SD) [min-max]")
#'
#' @details
#' The following keywords are recognized in \code{format}:
#' \code{mean} mean
#'
#' \code{SD} standard deviation
#'
#' \code{min} minimum
#'
#' \code{max} maximum
#'
#' \code{q}X the Xth percentile
#'
#' \code{mv} number of missing values, with Markdown formatting as a superscript
#'
#' \code{MV} number of missing values
#'
#' @export
#'
cdesc <- function(x,format,digits=1,na.rm=TRUE,nmiss=FALSE,nmiss0=FALSE) {
  nmissString <- ""
  missingNum <- sum(is.na(x))

  if (nmiss) {
    nmissString <- paste0("mv=",missingNum)
    nmissString <- paste0(" ^",nmissString,"^")
    if (!nmiss0 & missingNum == 0)
      nmissString <- ""
  }

  if (na.rm) x <- x[!is.na(x)]

  result <- format
  result <- gsub("mean",around(mean(x),digits=digits),result)
  result <- gsub("median",around(median(x),digits=digits),result)
  result <- gsub("SD",around(sd(x),digits=digits),result)
  result <- gsub("pm","&plusmn;",result)
  result <- gsub("min",around(min(x),digits=digits),result)
  result <- gsub("max",around(max(x),digits=digits),result)
  result <- gsub("mv",paste0(" ^mv=",missingNum,"^"),result)
  result <- gsub("MV",missingNum,result)

  repeat {
    if (length(grep("(q)([0-9]+)",result))==0) break
    quant <- sub("(.*)(q)([0-9]+)(.*)","\\3",result)
    if (quant!="") {
      qq <- around(quantile(x,as.numeric(quant)/100),digits=digits)
      result <- sub(paste0("q",quant),qq,result)
    }
  }

  result <- paste(result,nmissString,sep="")

  result
}

#' @title [median] [I]nter[Q]uartile[R]ange
#' @author Nick Barrowman
#' @description Calculates the median and IQR (interquartile range)
#'
#' @param x a vector
#' @param na.rm  remove missing values?
#' @param digits number of digits to include
#' @param IQRlabel optional label for IQR; defaults to blank
#' @param empty a symbol to demarcate an absence of values
#' @param nmiss show missing observations in a superscript in the same cell
#' @param hardspace put in a hardspace between the 25th and 75th percentile so that they generally stay together
#' @param nmiss0  if nmiss=TRUE and if there are no missing values, show mv=0?
#' @return median(Q3 − Q1)
#' @examples
#' medianIQR(FakeData$Age)
#'
#' [1] "4.0 (3.0, 5.0)"
#' @export
#'

medianIQR <- function(x,na.rm=TRUE,digits=1,IQRlabel="",empty="-",nmiss=FALSE,nmiss0=FALSE,hardspace=TRUE) {
  between <- ", "
  if (hardspace) {
    # Put in a hardspace between the 25th and 75th
    # percentile that they generally stay together
    between <- ",&nbsp;"
  }
  nmissString <- ""
  if (nmiss) {
    missingNum <- sum(is.na(x))
    nmissString <- paste(" ^mv=",missingNum,"^",sep="")
    if (!nmiss0 & missingNum==0) nmissString <- ""
  }

  if (na.rm) x <- x[!is.na(x)]
  if (length(x)==0) {
    empty
  } else {
    paste(
      around(median(x),digits=digits),
      " (",IQRlabel,
      around(quantile(x,0.25),digits=digits),
      between,
      around(quantile(x,0.75),digits=digits),
      ")",
      nmissString,
      sep="")
  }
}

#' @title [mean] [S]tandard [D]eviation
#' @author Nick Barrowman
#' @description
#'  \code{meanSD} Calculate the mean and standard deviation
#' @param x a vector
#' @param na.rm       remove missing values?
#' @param digits      number of digits to include
#' @param showSD      show the standard deviation?
#' @param SDlabel     optional label for SD
#' @param emtpy       a symbol to demarcate an absence of values
#' @param nmiss       show missing observations in a superscript in the same cell
#' @param nmiss0      show non-missing "missing observation" in a superscript in the same cell
#' @param plusminus   use the "plus or minus" symbol instead of putting SD in parentheses
#' @param range       also show the range of the data
#' @param rangeFormat if 1, square brackets are used; if 2, parentheses are used
#'
#' @return mean(SD)
#' @examples
#'  meanSD(FakeData$Age)
#'
#'  [1] "4.1 (0.9)"
#' @export
#'

meanSD <- function(x,na.rm=TRUE,digits=1,showSD=TRUE,SDlabel="",empty="-",nmiss=FALSE,nmiss0=FALSE,plusminus=FALSE,range=FALSE,rangeFormat=1,...) {
  nmissString <- ""
  if (nmiss) {
    missingNum <- sum(is.na(x))
    nmissString <- paste0(" ^mv=",missingNum,"^")
    if (!nmiss0 & missingNum==0) nmissString <- ""
  }

  rangeString <- ""
  if (range) {
    if (rangeFormat==1)
      rangeString <- paste0(" [",around(min(x,na.rm=TRUE),digits=digits),", ",around(max(x,na.rm=TRUE),digits=digits),"]")
    if (rangeFormat==2)
          rangeString <- paste0(" (",around(min(x,na.rm=TRUE),digits=digits),", ",around(max(x,na.rm=TRUE),digits=digits),")")
  }

  if (na.rm) x <- x[!is.na(x)]
  if (length(x)==0) {
    empty
  } else {
    if (plusminus) {
      paste(
        around(mean(x),digits=digits),
        " &plusmn; ",
        around(sd(x),digits=digits),
        nmissString,
        rangeString,
        sep="")
    } else {
      if (showSD) {
        paste(
          around(mean(x),digits=digits),
          " (",SDlabel,
          around(sd(x),digits=digits),
          ")",
          nmissString,
          rangeString,
          sep="")
      } else {
        paste(
          around(mean(x),digits=digits),
          nmissString,
          rangeString,
          sep="")
      }
    }
  }
}

#' @title [m]ean [S]tandard [D]eviation with a [p]lus minus "±" sign
#' @author Nick Barrowman, Mary-Ann Harrison
#' @description
#'  \code{meanSDp} Display the mean and standard deviation using the +//- symbol
#' @param ... parameters passed to the \code{meanSD} function.
#' @examples
#' meanSDp(FakeData$Age)
#' [1] "4.1 &plusmn; 0.9"
#' @return mean ± SD
#'
#' @export
#'

meanSDp <- function(...) {
  meanSD(...,plusminus=TRUE)
}


#' @title [range] [fun]ction
#' @author Nick Barrowman, Mary-Ann Harrison
#' @description
#'  \code{rangefun} Display minimum and maxium
#' @param x a numeric vector
#' @param na.rm  remove missing values?
#' @param digits number of digits to include
#' @param label optional label
#' @param emtpy a symbol to demarcate an absence of values
#' @param nmiss show missing observations in a superscript in the same cell
#' @param hardspace Put in a hardspace between values so they generally stay together
#'
#' @return min - max
#' @examples
#' rangefun(FakeData$Age)
#'
#' [1] "3.0- 5.0"
#' @export
#'
rangefun <- function(x,na.rm=TRUE,digits=1,label="",emtpy="-",nmiss=FALSE,hardspace=TRUE) {


  nmissString <- ""
  if (nmiss) nmissString <- paste(" ^mv=",sum(is.na(x)),"^",sep="")
  if (na.rm) x <- x[!is.na(x)]
  if (length(x)==0) {
    emtpy
  } else {
    paste(
      around(min(x),digits=digits),
      " &ndash; ",
      around(max(x),digits=digits),
      nmissString,
      sep="")
  }
}

#' @title [p]ipetable [bind] rows
#' @author Nick Barrowman
#' @description
#' \code{pbind} Join arguments together as rows of a pipe table
#'
#' @param ... arguments to be used in the function
#'
#' @details Arguments are expected to be character strings.
#' (But are converted to character strings in any case.)
#' Empty strings will be converted to non-breakable spaces.
#'
#' @return Arguments joined together as rows of a pipe table
#'
#' @export
#'

pbind <- function(...) {


  arguments <- list(...)

  pieces <- c()
  ncol <- 0
  for (argument in arguments) {

    argument <- as.character(argument)
    if (!is.na(argument) & argument=="") {
      argument <- paste0(rep("&nbsp;",ncol),collapse=" | ")
    }
    pieces <- c(pieces,argument)

    cliparg <- substring(argument,2) # clip first character in case it's a |
    ncol <- length(strsplit(cliparg,"|")[[1]])
  }

  row <- paste(pieces,collapse="\n")
  row
}

#' @title [tablerow]
#' @author Nick Barrowman
#' @description
#' \code{tablerow} Join arguments together as rows of a pipe table
#' @param ... arguments to be used in the function
#'
#' @details Arguments are expected to be character strings
#' (But are converted to character strings in any case)
#' Empty strings will be converted to non-breakable spaces
#'
#' @return arguments joined together as rows of a pipe table
#'
#' @examples
#'
#' For use in a R Markdown pipetable:
#'
#' Set up your pipetable with Headers, and dashes to demarcate desired column width:
#'
#' Table 1. Clinical Characteristics
#'
#' Treatment Group | N(%)
#' ----------------|----------
#' `r tablerow("Group A, N(%)", npct(FakeData$Group=="A")["TRUE"])`
#'
#' @export
#'

tablerow <- function(...) {

  arguments <- list(...)

  pieces <- c()
  for (argument in arguments) {
    argument <- as.character(argument)
    argument[!is.na(argument) & argument==""] <- "&nbsp;"
    pieces <- c(pieces,argument)
  }

  row <- paste(pieces,collapse=" | ")
  row
}



#' @title [pipetable] for [row] N & percentages
#' @author Nick Barrowman
#' @description
#' \code{pipetablerow} Make a pipetable for the cross-classification of two variables including row percentages
#' @param  x           The row variable.
#'                     (Unless the column variable is not specified, in which case \code{x} is treated as the column variable.)
#' @param  y           The column variable. (If not specified, a one-way classification of \code{x} is produced.)
#' @param  vp          Show [v]alid [p]ercentages?
#'                     Valid percentages are computed by first excluding missing values and then calculating percentages.
#' @param pcs          Percentage symbol (default is "\%", but could be blank).
#' @param digits       Number of decimal places.
#' @param omity        Values of \code{y} to omit.
#'                     Use this for dichotomous variables
#'                     (e.g. Yes/No where you don't want to see No).
#' @param showmiss     show missing value row and column
#'                     (overrides \code{showmissrow} and \code{showmisscol})
#' @param showmissrow  show missing value row
#' @param showmisscol  show missing value row
#' @param showN        show marginal counts
#'                     (overrides \code{showNrow} and \code{showNcol})
#' @param showNrow     show marginal counts row
#' @param showNcol     show marginal counts column
#' @param showp        Show percentages currently only row percentages are supported.
#' @param blank0       Leave blank any cells containing zero?
#' @param rowvarname   A name for labeling the row variable.
#' @param colvarname   A name for labeling the column variable.
#' @param varname      A name for labeling a single variable.
#'                     (\code{rowvarname} and \code{colvarname} also work, but seem poorly named in such a case.)
#' @param ndashes      The number of dashes to use in each column of the pipe table header.
#' @param show0x       Show values of x that are entirely zero?
#' @param show0y       Show values of y that are entirely zero?
#' @param rowheadstyle Custom style (for docx) for row headers.
#' @param colheadstyle Custom style (for docx) for column headers.
#' @param cellstyle    Custom style (for docx) for table cells.
#' @param style        Custom style (for docx) for row headers,
#'                     column headers, and table cells.
#' @param sep          Parameter to pass on to the npct function.
#'
#' @return a pipetable that illustrates the cross-classification of two variables including row percentages
#'
#' @examples
#'
#' # Using the show0y argument to suppress column of zeros.
#' # First subset FakeData to remove missing values of Severity.
#' # (It turns out that Severity is missing only
#' # in cases where Category="triple"
#'
#' FD <- FakeData[!is.na(FakeData$Severity),]
#' pipetablerow(FD$Severity,FD$Category,show0y=FALSE)
#'
#' @export
#'
pipetablerow <- function(x,y,vp=TRUE,pcs="",digits=1,omity=NULL,
  showmiss=TRUE,showmissrow=TRUE,showmisscol=TRUE,
  showN=TRUE,showNrow=TRUE,showNcol=TRUE,
  showp=TRUE,blank0=FALSE,rowvarname,colvarname,varname,ndashes=NULL,
  rowheadstyle="",colheadstyle="",cellstyle="",style="",
  show0x=TRUE,show0y=TRUE,sep=" ") {

  if (!showmiss) {
    showmissrow <- showmisscol <- FALSE
  }

  if (!showN) {
    showNrow <- showNcol <- FALSE
  }

  if (!missing(style)) {
    rowheadstyle <- colheadstyle <- cellstyle <- style
  }

  if (missing(rowvarname)) {
    xname <- sapply(as.list(substitute({x})[-1]), deparse)
  } else {
    xname <- rowvarname
  }

  if (missing(y)) {
    singleRow <- TRUE
    y <- x
    x <- rep(1,length(x))
    # yname <- xname
    if (!missing(colvarname)) {
      xname <- colvarname
    }
    if (!missing(rowvarname)) {
      xname <- rowvarname
    }
    if (!missing(varname)) {
      xname <- varname
    }
    yname <- ""
  } else {
    singleRow <- FALSE
    if (missing(colvarname)) {
      yname <- sapply(as.list(substitute({y})[-1]), deparse)
    } else {
      yname <- colvarname
    }
  }

  xname <- escapeSymbols(xname)
  yname <- escapeSymbols(yname)

  if (!is.factor(x)) x <- factor(x)
  if (!is.factor(y)) y <- factor(y)

  if (!show0x) {
    if (any(table(x)==0)) {
     keep <- names(table(x))[table(x)!=0]
     x <- factor(x,levels=keep)
    }
  }

  if (!show0y) {
    if (any(table(y)==0)) {
     keep <- names(table(y))[table(y)!=0]
     y <- factor(y,levels=keep)
    }
  }

  ly <- levels(y)
  if (!missing(omity)) ly <- ly[!(ly %in% omity)]

  if (!singleRow) {
    if (yname!="") {
      ly[1] <- paste(yname,"\\\n",ly[1],sep="")
    }
  }

  if (singleRow) {
    headings <- c(xname,"&nbsp;",ly)
  } else {
    headings <- c("&nbsp;","&nbsp;",ly)
  }
  if (showmisscol) headings <- c(headings,"Missing")
  if (showNcol) headings <- c(headings,"N")

  h <- headings

  if (colheadstyle!="") {
    headings <- applydocxStyle(headings,colheadstyle)
  }

  headings <- paste0("**",headings,"**")

  result <- pipetableheader(headings,ndashes)

  xlevels <- levels(x)

  for (i in seq_len(length(xlevels))) {
    row <- !is.na(x) & x==xlevels[i]
    if (singleRow) {
      levelhead <- ""
    } else {
      levelhead <- paste0("**",xlevels[i],"**")
      if (rowheadstyle!="") {
        levelhead <- applydocxStyle(levelhead,rowheadstyle)
       }
    }
    if (i==1) {
      #col1 <- paste0("**",xname,"**")
      if (singleRow) {
        col1 <- ""
      } else {
        if (xname=="") {
          col1 <- ""
        } else {
          col1 <- applydocxStyle(paste0("**",xname,"**"),rowheadstyle)
        }
      }
    } else {
      col1 <- ""
    }
    rowSum <- as.character(sum(row))
    if (blank0) {
      if (rowSum=="0") rowSum <- ""
    }
    npct_stuff <- npct(y[row],vp=vp,digits=digits,pcs=pcs,includemiss=showmisscol,showp=showp,showzero=!blank0,sep=sep)
    if (!missing(omity)) npct_stuff <- npct_stuff[!(names(npct_stuff) %in% omity)]
    rowSum_stuff <- as.character(rowSum)
    if (cellstyle!="") {
      npct_stuff <- applydocxStyle(npct_stuff,cellstyle)
      rowSum_stuff <- applydocxStyle(rowSum_stuff,cellstyle)
    }
    if (showNcol) {
      result <- pbind(
        result,
        tablerow(
          col1,
          levelhead,
          npct_stuff,
          rowSum_stuff))
    } else {
      result <- pbind(
        result,
        tablerow(
          col1,
          levelhead,
          npct_stuff))
    }
  }
  if (showmissrow &!singleRow) {
    countMissing <- as.character(table(y[is.na(x)],useNA="always"))
    countTotalMissing <- as.character(sum(is.na(x)))
    if (blank0) {
      countMissing[countMissing=="0"] <- ""
      if (countTotalMissing=="0") countTotalMissing <- ""
    }
    if (cellstyle!="") {
      countMissing <- applydocxStyle(countMissing,cellstyle)
      countTotalMissing <- applydocxStyle(countTotalMissing,cellstyle)
    }
    missingTerm <- "Missing"
    if (rowheadstyle!="") {
      missingTerm <- applydocxStyle(missingTerm,rowheadstyle)
    }
    missingTerm <- paste0("**",missingTerm,"**")
    if (showNcol) {
       result <- pbind(result,
                    tablerow("",missingTerm,countMissing,countTotalMissing))
    } else {
       result <- pbind(result,
                    tablerow("",missingTerm,countMissing))
    }
  }
  if (showNrow &! singleRow) {
    if (showmiss) {
      countTotal <- as.character(table(y,useNA="always"))
    } else {
      countTotal <- as.character(table(y))
    }
    countGrandTotal <- as.character(length(y))
    if (blank0) {
      countTotal[countTotal==0] <- ""
      if (countGrandTotal=="0") countGrandTotal <- ""
    }
    NTerm <- "N"
    if (rowheadstyle!="") {
      NTerm <- applydocxStyle(NTerm,rowheadstyle)
    }
    NTerm <- paste0("**",NTerm,"**")
    if (cellstyle!="") {
      countTotal <- applydocxStyle(countTotal,cellstyle)
      countGrandTotal <- applydocxStyle(countGrandTotal,cellstyle)
    }
    if (showNcol) {
      result <- pbind(result,
                      tablerow("",NTerm,tablerow(countTotal,countGrandTotal)))
    } else {
      result <- pbind(result,
                      tablerow("",NTerm,tablerow(countTotal)))
    }
  }
  result
}


#' @title [pipetable][l]inear [m]odel [coeff]icients
#' @author Nick Barrowman
#' @description
#' \code{pipetablelmCoef} Make a pipetable to display coefficients from a linear model fit
#' @param fit                 linear model
#' @param varnames            variable names
#' @param digitsEstimate      number of digits to include in the estimate
#' @param ci                  if TRUE confidence intervals are shown; otherwise, standard errors are shown
#' @return A pipetable that displays coefficients from a linear model fit
#'
#'
#' @export
#'

pipetablelmCoef <- function(fit,varnames,digitsEstimate=2,ci=TRUE) {


  if (ci) {
    conf <- confint(fit)

    mat <- cbind(
      "Variable"=rownames(summary(fit)$coef),
      "Estimate"=around(summary(fit)$coef[,"Estimate"],digits=digitsEstimate),
      "95%Lo"=around(conf[,"2.5 %"],digits=digitsEstimate),
      "95%Hi"=around(conf[,"97.5 %"],digits=digitsEstimate),
      "p-value"=formatp(summary(fit)$coef[,"Pr(>|t|)"]))
  } else {
    mat <- cbind(
      "Variable"=rownames(summary(fit)$coef),
      "Estimate"=around(summary(fit)$coef[,"Estimate"],digits=digitsEstimate),
      "SE"=around(summary(fit)$coef[,"Std. Error"],digits=digitsEstimate),
      "p-value"=formatp(summary(fit)$coef[,"Pr(>|t|)"]))
  }

  if (!missing(varnames)) mat[,"Variable"] <- varnames

  pipetable(mat,showrownames=FALSE)
}


#' @title [pipetable] [logistic]
#' @author Nick Barrowman
#' @description
#' \code{pipetablelogistic} Make a pipetable to display coefficients from a logistic regression model fit
#' @param  fit logistic regression model
#' @param  varnames Variable names to include in the model
#' @param  digitsEstimate # of digits to include in the estimate
#' @param  SE show standard error
#' @param  ShowEst show estimate
#' @param  showInt show intercept
#'
#' @return a pipetable that displays the coefficients from a logistic regression model fit
#'
#' @export
#'

pipetablelogistic <- function(fit,varnames,digitsEstimate=2,SE=FALSE,ShowEst=FALSE,showInt=FALSE) {
  #
  # Make a {pipetable} to display {coeff}icients from a {logistic} regression {m}odel fit
  #

  ci <- confint(fit)

  mat <- NULL

  mat <- cbind(mat,"Variable"=rownames(summary(fit)$coef))
  if (ShowEst) mat <- cbind(mat,"Estimate"=around(summary(fit)$coef[,"Estimate"],digits=digitsEstimate))

  if (SE) mat <- cbind(mat,"SE"=around(summary(fit)$coef[,"Std. Error"],digits=digitsEstimate))

  mat <- cbind(mat,"Exp(Estimate)"=around(exp(summary(fit)$coef[,"Estimate"]),digits=digitsEstimate))
  mat <- cbind(mat,"95%lo"=around(exp(ci[,"2.5 %"]),digits=digitsEstimate))
  mat <- cbind(mat,"95%hi"=around(exp(ci[,"97.5 %"]),digits=digitsEstimate))
  mat <- cbind(mat,"p-value"=formatp(summary(fit)$coef[,"Pr(>|z|)"]))

  #browser()

  if (!showInt) {
    mat <- mat[mat[,"Variable"]!="(Intercept)",,drop=FALSE]
    colnames(mat)[colnames(mat)=="Exp(Estimate)"] <- "OR"
  }

  if (!missing(varnames)) mat[,"Variable"] <- varnames

  pipetable(mat,showrownames=FALSE)
}

#' @title  [markdown] pipe[Table]
#' @author Nick Barrowman
#' @description
#' \code{markdownTable}  Convert a matrix or dataframe into a Markdown pipe table
#' @details Empty strings will be converted to non-breakable spaces.
#' @param x            A matrix or dataframe
#' @param NAreplace    What to replace NA's with
#' @param boldrownames Should row names have bold font?
#' @param showrownames Should row names be shown?
#' @param llspace      Should leading spaces be replaced by non-breaking spaces?
#'                     (Otherwise they are simply removed.)
#' @param blank0       Leave blank any cells containing zero?
#' @param digits       Number of digits to display for numeric variables
#' @param style        Custom style (for docx).
#' @param finalLineBreak Should there be a line break at the end?
#'
#' @return a Markdown pipe table generated from a matrix or dataframe
#'
#'
#' @export
#'

markdownTable <- function(x,NAreplace="",boldrownames=TRUE,showrownames=TRUE,
  llspace=TRUE,blank0=FALSE,digits,style="",finalLineBreak=TRUE) {

  rn <- rownames(x)
  AnyRowNames <- !is.null(rn)
  if (!showrownames) AnyRowNames <- FALSE
  if (AnyRowNames) {
    if (boldrownames) rn <- paste0("**",rn,"**")
  }

  xx <- as.character(as.matrix(x))
  xx[is.na(xx)] <- NAreplace

  if (blank0) {
    xx[grepl("^\\s*0$",xx)] <- ""
  }

  w <- matrix(xx,nrow=nrow(x),ncol=ncol(x))

  if (!missing(digits)) {
    for (i in 1:ncol(w)) {
      if (is.numeric(x[,i])) w[,i] <- around(x[,i],digits=digits)
    }
  }

  for (i in 1:nrow(w)) {
    row <- w[i,]

    #
    # Now replace leading spaces with "&nbsp;"
    #

    left  <- gsub("^( *)(.*)$","\\1",row)
    right <- gsub("^( *)(.*)$","\\2",row)
    newleft <- gsub(" ","&nbsp;",left)

    if (llspace) {
      row <- paste(newleft,right,sep="")
    } else {
      row <- paste(right,sep="")
    }

    if (style!="") {
      row <- applydocxStyle(row,style)
    }

    row[!is.na(row) & row==""] <- "&nbsp;"

    textrow <- paste(row,collapse="|")

    if (AnyRowNames) {
      textrow <- paste(c(rn[i],textrow),collapse="|")
    }

    textrow <- paste0(textrow,"|")

    if (i==1) {
      result <- textrow
    } else {
      result <- paste(result,textrow,sep="\n")
    }
  }

  if (finalLineBreak) {
    paste(result,"\n")
  } else {
    result
  }
}



#' @title [p]er[c]en[t] [f]unction
#' @author Nick Barrowman
#' @description
#' A helper function for the uORtable and mORtable functions
#' @param xname    name of x variable
#' @param lab      label
#' @param index    index
#' @param yname    name of y variable
#' @param data     dataframe
#' @param xorder   named list of display order of levels for corresponding predictor variables
#' @param binary   re-label logical or binary vectors into 'no' and 'yes' for clarity
#' @param digits   number of decimal digits to show
#' @param ...      other arguments to include
#' @return N(%)
#'
#'
#' @export
#'

pctf <- function(xname,lab,index,yname,data,xorder=list(),binary=c("no","yes"),digits=1,...) {

  # message(paste("pctf: xname =",xname,"  yname =",yname))

  x <- data[[xname]]
  y <- data[[yname]]

  if (!is.factor(x)) {
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  }

  if (is.factor(x)) {

    values <- levels(x)
    if (xname %in% names(xorder)) {
      values <- values[xorder[[xname]]]
    }

    if (index==0) return("")
    #v <- rev(levels(factor(x)))[index]   # REVERSE SORT
    v <- values[index]

    num <- sum(y[!is.na(x) & (x==v)],na.rm=TRUE)
    den <- sum(x==v,na.rm=TRUE)

    #message(paste("pctf: v =",v,"  num =",num,"   den =",den))

    if (num==0 && den==0) {
      "-"
    } else {
      paste(
        num,"/",den,
        " (",
        around(100*num/den,digits=digits),
        "%)",sep="")
    }
  } else {
    ""
  }
}



#' @title [Var]iable [Rows]
#' @author Nick Barrowman
#' @description
#' Generate a table of character strings corresponding to the levels of a variable that may predict an outcome
#' @param xname    name of a predictor variable
#' @param yname    name of outcome variable
#' @param heading  a descriptive label for the variable
#' @param data     dataframe
#' @param indent   number of spaces to indent each level of the variable (Default 5)
#' @param f        a list of functions for the columns of the table
#' @param binary   re-label logical or binary vectors into 'no' and 'yes' for clarity
#' @param xorder   named list of display order of predictor levels for corresponding variables
#'
#' @return a table of character strings corresponding to the levels of a variable that may predict an outcome
#'
#' @export
#'

VarRows <- function(xname,yname,heading,data,xorder=list(),indent=5,f,binary=c("no","yes"),...) {


  K <- length(f)

  # If heading is not specified, use the actual name of the x argument.
  if (missing(heading)) heading <- xname

  head <- paste("**",heading,"**",sep="")

  x <- data[[xname]]
  y <- data[[yname]]

  if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)

  spaces <- paste(rep(" ",indent),collapse="")
  #values <- rev(sort(unique(x))) # REVERSE SORT

  if (is.factor(x)) {
    values <- levels(x)

    if (xname %in% names(xorder)) {
      values <- values[xorder[[xname]]]
    }

    lab <- paste(xname,values,sep="") # labels

    n <- length(values)

    groupOfRows <- c()
    for (i in 0:n) {
      if (i==0) {
        row <- head
      } else {
        row <- paste(spaces,values[i],sep="")
      }
      for (Function in f) {
        #browser()
        row <- c(row,Function(
          xname=xname,lab=lab[i],index=i,yname=yname,data=data,xorder=xorder,binary=binary,...))
      }
      groupOfRows <- rbind(groupOfRows,row)
    }
  } else {
    row <- head
    for (Function in f) {
      row <- c(row,Function(
        xname=xname,lab=xname,index=1,yname=yname,data=data,binary=binary,xorder=xorder,...))   # using xname for lab (check if this matters later)
    }
    groupOfRows <- rbind(row)
  }

  rownames(groupOfRows) <- NULL

  groupOfRows
}


#'
#' @title [uni]variate [log]istic regression
#' @author Nick Barrowman
#' @description
#' Run a [uni]variate [log]istic regression analysis
#' @param xname   name of predictor variable
#' @param yname   name of y variable
#' @param df      dataframe
#' @param binary  re-label logical or binary vectors into 'no' and 'yes' for clarity
#'
#' @return univariate regression model
#'
#'
#' @export
#'
#'
#'
unilog <- function(xname,yname,df,binary=c("no","yes")) {

  x <- df[[xname]]

  if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)

  df[[xname]] <- x

  formula <- as.formula(paste(yname,"~",xname))

  fit <- glm(formula,family=binomial,data=df,subset=!is.na(df[[xname]]))

  ci <- suppressMessages(confint(fit))

  eci <- exp(ci)
  tab <- cbind(exp(coef(fit)),eci)
  colnames(tab) <- c("OR","95%lo","95%hi")

  formula0 <- as.formula(paste(".~.-",xname,sep=""))
  fit0 <- update(fit,formula0)

  a <- anova(fit,fit0,test="LRT")

  list(fit=fit,ORtable=tab,fit0=fit0,p=a$"Pr(>Chi)"[2])
}

#' @title [u]nivariate [O]dds [R]atio [table]
#' @author Nick Barrowman
#' @description
#' Generates a Markdown pipetable containing results from a univariate regression analysis
#' @details the function can accomodate (k) predictors and one binary outcome variable
#' calculates, formats and populates a Markdown pipetable with N(\%), OR(lower CI, upper CI), & p-values
#'
#' @param xnames       names of predictor variables
#' @param yname        name of outcome variable
#' @param data         dataframe
#' @param xorder       named list of display order of levels for corresponding predictor variables
#' @param xlabels      named list of labels for corresponding predictor variables
#' @param missingNone  Use only complete cases?
#'                     (i.e. no missing values in any of the predictor variables)
#'                     This can be useful for comparing with multiple logistic regression results
#' @param nmiss        Display number of missing values next to each variable name?
#'
#' @return a Markdown pipetable containing results from a univariate regression analysis
#' including formatted N(\%), OR(lower CI, upper CI), and p-values
#'
#' @examples
#' # All of the following code should be called inline.
#'
#' # A basic call to mORtable:
#' uORtable(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",data=wide)
#'
#' # Also specify the cutoff:
#' uORtable(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",0.1,data=wide)
#'
#' # Also specify that values of the AHICat variable should listed in order 1, 3, 2:
#' uORtable(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)))
#'
#' # Also specify nicer labels for the AHICat, LowO2Cat, and HighCO2Cat variables:
#' uORtable(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)),
#'   xlabels=list(AHICat="AHI",LowO2Cat="Lowest O~2~ saturation",HighCO2Cat="Highest CO~2~"))
#'
#' @export


uORtable <- function(xnames,yname,data,xorder=list(),xlabels=list(),missingNone=FALSE,nmiss=TRUE) {

  # Identify complete cases across all predictor variables
  notmissing <- rep(TRUE, nrow(data))
  if (missingNone) {
    for (xname in xnames) {
      notmissing <- notmissing & !is.na(data[[xname]])
    }
    # Select complete cases
    DATA <- data[notmissing, ]
  } else {
    DATA <- data
  }

  include <- rep(TRUE,length(xnames))
  names(include) <- xnames
  univariate <- vector("list",length(xnames))
  names(univariate) <- xnames

  out <-""
  i <- 0
  for (xname in xnames) {
    i <- i + 1
    univariate[[i]] <- unilog(xname,yname,DATA)

    heading <- xname
    if (xname %in% names(xlabels)) {
      heading <- xlabels[[xname]]
    }

    if (nmiss) {
      countmissing <- sum(is.na(data[[xname]]))
      if (countmissing>0) {
        heading <- paste0(heading," ^mv=",countmissing,"^")
      }
    }

    out <- paste(out,markdownTable(
      VarRows(xname,yname,heading=heading,data=DATA,xorder=xorder,
              f=list(pctf,uorf,upvf),
              ufit=univariate[[i]])))
  }
  out
}




#' @title [u]nivariate [o]dds [r]atio [f]unction
#' @author Nick Barrowman
#' @description
#' A helper function for the uORtable and mORtable functions
#' @param xname   name of predictor variable
#' @param lab     label
#' @param index   index
#' @param yname   name of y variable
#' @param data    dataframe
#' @param xorder  named list of display order of levels for corresponding predictor variables
#' @param ufit    univariate model fit
#' @param ...     other arguments to pass into the model
#'
#' @return univariate odds ratio
#'
#'
#' @export

uorf <- function(xname,lab,index,yname,data,xorder,ufit,binary=c("no","yes"),...) {

  show_it <- TRUE

  x <- data[[xname]]
  y <- data[[yname]]

  if (!is.factor(x)) {
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  }

  if (is.factor(x)) {

    values <- levels(x)
    if (xname %in% names(xorder)) {
      values <- values[xorder[[xname]]]
    }

    if (index==0) return("")
    #v <- rev(levels(factor(x)))[index]   # REVERSE SORT
    v <- values[index]

    num <- sum(y[!is.na(x) & (x==v)],na.rm=TRUE)
    den <- sum(x==v,na.rm=TRUE)

    if (num==0 && den==0) show_it <- FALSE
  }


  if (index==0) return("") # HEADER ROW

  ORtable <- ufit$ORtable

  if (show_it) {
    if (is.na(match(lab,rownames(ORtable)))) {
      "1.0"
    } else
    if (ORtable[lab,"OR"]<0.01) {
      "0.0 ( - )"
    } else
    if (ORtable[lab,"OR"]>1e4) {
      "Inf ( - )"
    } else {
      paste(
        around(ORtable[lab,"OR"]),
        " (",
        around(ORtable[lab,"95%lo"]),
        ", ",
        around(ORtable[lab,"95%hi"]),
        ")",
        sep=""
      )
    }
  } else {
    "-"
  }
}

#' @title  [u]nivariate [p]-[v]alue [f]unction
#' @author Nick Barrowman
#' @description
#' A helper function for the uORtable and mORtable functions
#' @param xname   name of predictor variable
#' @param lab     label
#' @param index   index
#' @param yname   name of y variable
#' @param data    dataframe
#' @param xorder  named list of display order of levels for corresponding predictor variables
#' @param ufit    univariate model fit
#' @param binary  re-label logical or binary vectors into 'no' and 'yes' for clarity
#' @param ...     other arguments to be passed into the function
#'
#' @return  the p-value for a specified variable from a fitted univariate model
#'
#'
#' @export
#'

upvf <- function(xname,lab,index,yname,data,xorder,ufit,binary=c("no","yes"),...) {


  x <- data[[xname]]
  if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)

  if (index==0 | !is.factor(x)) return(formatp(ufit$p))
  if (index==1) return("")
  if (index>1) return("")
}


#' @title [m]ultivariate [O]dds [R]atio [table]
#' @author Nick Barrowman
#' @description
#' \code{mORtable} Generates a table with N(\%), OR(lower CI, upper CI), and p-values from a multivariate regression model
#' @details xnames preceded by a star will be forced into the multivariate model
#' @param xnames  vector of names of potential predictors
#' @param yname   name of outcome variable
#' @param pcutoff p-value threshold for inclusion of predictor in the multivariate model
#' @param data    data frame
#' @param binary  vector of two names for logical variables (instead of TRUE, FALSE)
#' @param xorder  named list of display order of levels for corresponding predictor variables
#' @param xlabels named list of labels for corresponding predictor variables
#'
#' @return  a Markdown pipetable table with N(\%), OR(lower CI, upper CI), and p-values
#'
#' @examples
#' # All of the following code should be called inline.
#'
#' # A basic call to mORtable:
#' mORtable(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",data=wide)
#'
#' # Also specify the cutoff:
#' mORtable(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",0.1,data=wide)
#'
#' # Also specify that values of the AHICat variable should listed in order 1, 3, 2:
#' mORtable(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)))
#'
#' # Also specify nicer labels for the AHICat, LowO2Cat, and HighCO2Cat variables:
#' mORtable(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)),
#'   xlabels=list(AHICat="AHI",LowO2Cat="Lowest O~2~ saturation",HighCO2Cat="Highest CO~2~"))
#'
#' @export

mORtable <- function(xnames,yname,pcutoff,data,binary=c("no","yes"),xorder=list(),xlabels=list()) {

  nrowOriginal <- nrow(data)

  forced <- grep("^\\*",xnames) # variables preceded by a * are forced into the multivariate model

  xnames <- gsub("^\\*(.+)","\\1",xnames)  # strip of any leading stars

  message("mORtable ---- Start ---------")
  message(paste("mORtable: xnames =",paste(xnames,collapse=","),"  yname=",yname))

  # Identify complete cases across all predictor variables
  notmissing <- rep(TRUE,nrow(data))
  for (xname in xnames) {
    notmissing <- notmissing & !is.na(data[[xname]])
  }

  # Identify complete cases for the outcome variable
  notmissing <- notmissing & !is.na(data[[yname]])

  # Select complete cases
  data <- data[notmissing,]

  message(paste("mORtable: original data object had",nrowOriginal,"rows."))
  message(paste("mORtable: complete data object has",nrow(data),"rows."))

  message("mORtable: make factors")

  # Convert the appropriate predictor variables into factors
  for (xname in xnames) {
    x <- data[[xname]]
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    data[[xname]] <- x
  }

  message("mORtable: figure out which variables to use in multivariate model")

  include <- rep(TRUE,length(xnames))
  names(include) <- xnames
  univariate <- vector("list",length(xnames))
  names(univariate) <- xnames
  i <- 0
  for (xname in xnames) {
    i <- i + 1
    univariate[[i]] <- unilog(xname,yname,data)
    include[i] <- univariate[[i]]$p<pcutoff
  }
  include[forced] <- TRUE

  xnamesMulti <- xnames[include]

  formula <- as.formula(paste(yname,"~",paste(xnamesMulti,collapse="+")))

  message("mORtable: Run multivariate model")

  fit <- glm(formula,family=binomial,data=data)

  out <-""
  for (xname in xnames) {
    heading <- xname
    if (xname %in% names(xlabels)) {
      heading <- xlabels[[xname]]
    }

    out <- paste(out,markdownTable(
      VarRows(xname,yname,heading=heading,data=data,xorder=xorder,
              f=list(pctf,uorf,upvf,morf,mpvf),
              ufit=univariate[[xname]],mfit=fit,minclude=include[xname])))
  }
  out
}


#' @title [m]ultivariate [o]dds [r]atio [f]unction
#' @author Nick Barrowman
#' @description
#' A helper function for the mORtable function
#'
#' @param xname    vector of names of potential predictors
#' @param lab      label
#' @param index    index
#' @param yname    name of y variable
#' @param data     dataframe
#' @param mfit     multivariate model fit
#' @param minclude what to include?
#' @param ...      other arguments to be passed into the function
#'
#' @return adjusted odds ratios from a multivariate regression model
#'
#'
#' @export
#'
morf <- function(xname,lab,index,yname,data,xorder,mfit,minclude,...) {

  #browser()
  if (!minclude) return("")

  if (index==0) return("")

  co <- summary(mfit)$coef

  ci <- suppressMessages(confint(mfit))

  eci <- exp(ci)
  tab <- cbind(exp(coef(mfit)),eci)
  colnames(tab) <- c("OR","95%lo","95%hi")

  if (is.na(match(lab,rownames(tab)))) {
    "1.0"
  } else
  if (tab[lab,"OR"]<0.01) {
    "0.0 ( - )"
  } else
  if (tab[lab,"OR"]>1e4) {
    "Inf ( - )"
  } else {
    paste(
      around(tab[lab,"OR"]),
      " (",
      around(tab[lab,"95%lo"]),
      ", ",
      around(tab[lab,"95%hi"]),
      ")",
      sep=""
    )
  }
}

#' @title [m]ultivariate [p]-[v]alue [f]unction
#' @author Nick Barrowman
#' @description
#' \code{mpvf} A helper function for the mORtable function
#'
#' @param xname    vector of names of potential predictors
#' @param lab      label
#' @param index    index
#' @param yname    name of y variable
#' @param data     dataframe
#' @param mfit     multivariate model fit
#' @param minclude what to include?
#' @param ...      other arguments to be passed into the function
#'
#'
#' @return p-values from a multivariate regression model
#'
#' @export
#'

mpvf <- function(xname,lab,index,yname,data,xorder,mfit,minclude,...) {

  x <- data[[xname]]

  if (!minclude) return("")

  if (index==0 | !is.factor(x)) {
    formula0 <- as.formula(paste(".~.-",xname,sep=""))
   # browser()
    mfit0 <- update(mfit,formula0)

    a <- anova(mfit,mfit0,test="LRT")
    formatp(a$"Pr(>Chi)"[2])
  } else {
    ""
  }
}


#' @title [m]ultivariate [p]-[v]alue [f]unction [f]irth corrected
#' @author Nick Barrowman
#' @description
#' \code{mpvf} A helper function for the mORtable function
#'
#' @param xname    vector of names of potential predictors
#' @param lab      label
#' @param index    index
#' @param yname    name of y variable
#' @param data     dataframe
#' @param mfit     multivariate model fit
#' @param minclude what to include?
#' @param ...      other arguments to be passed into the function
#'
#'
#' @return p-values from a multivariate regression model
#'
#' @export
#'

mpvff <- function(xname,lab,index,yname,data,xorder,mfit,minclude,...) {

  x <- data[[xname]]

  d <- drop1(mfit)
  #browser()

  if (index==0 | !is.factor(x)) {
    if (xname %in% rownames(d)) {
      formatp(d[xname,"P-value"])
    } else {
      ""
    }
  } else {
    ""
  }
}


#' @title applydocxStyle
#' @author Nick Barrowman
#' @description
#'  \code{applydocxStyle} adds pandoc Markdown syntax for a custom docx style
#' @param x        character vector
#' @param style    the name of a style in the docx template
#' @details
#' pandoc Markdown uses the syntax \code{[some text]{custom-style="MyStyle"}}
#' to specify a custom style.
#'
#' @return the \code{x} vector with each element modified with Markdown syntax
#'         specifying the custom style
#'
#' @export
#'
applydocxStyle <- function(x,style) {
  if (style!="") {
    x <- paste0("[",x,"]{custom-style=\"",style,"\"}")
  }
  x
}


#' @title [Pipetable] [Col]umns
#' @author Nick Barrowman
#' @description
#'  \code{pipetablecol}  make a pipetable for the cross-classification of two variables including column percentages
#'
#' @param x            row variable
#' @param y            column variable
#' @param vp           show [v]alid [p]ercentages, i.e. omit NA's before calculating
#' @param pcs          percentage symbol (default is "\%", but could be blank)
#' @param digits       number of decimal places
#' @param omity        Values of \code{y} to omit.
#'                     Use this for dichotomous variables
#'                     (e.g. Yes/No where you don't want to see No).
#' @param showmiss     show missing value row and column
#'                     (overrides \code{showmissrow} and \code{showmisscol})
#' @param showmissrow  show missing value row
#' @param showmisscol  show missing value row
#' @param showN        show marginal counts
#'                     (overrides \code{showNrow} and \code{showNcol})
#' @param showNrow     show marginal counts row
#' @param showNcol     show marginal counts column
#' @param showp        show percentages; currently only row percentages are supported
#' @param rowvarname   A name for labeling the row variable
#' @param colvarname   A name for labeling the column variable
#' @param varname      A name for labeling a single variable.
#'                     (\code{rowvarname} and \code{colvarname} also work, but seem poorly named in such a case.)
#' @param ndashes      Optional parameter: The number of dashes to use in each column of the pipe table header.
#' @param rowheadstyle Custom style (for docx) for row headers.
#' @param colheadstyle Custom style (for docx) for column headers.
#' @param cellstyle    Custom style (for docx) for table cells.
#' @param style        Custom style (for docx) for row headers,
#'                     column headers, and table cells.
#' @param blank        Character string to substitute for an empty variable level.
#' @param topleft      Text to put in the top left cell of the table.
#'
#' @return a Markdown pipetable that illustrates the cross-classification of two variables
#' including column percentages.
#'
#' @export
#'

pipetablecol <- function(x,y,vp=TRUE,pcs="",digits=1,omity=NULL,
  showmiss=TRUE,showmissrow=TRUE,showmisscol=TRUE,
  showN=TRUE,showNrow=TRUE,showNcol=TRUE,
  showp=TRUE,rowvarname,colvarname,varname,ndashes=NULL,
  rowheadstyle="",colheadstyle="",cellstyle="",style="",blank="-blank-",
  topleft="") {

  if (!showmiss) {
    showmissrow <- showmisscol <- FALSE
  }

  if (!showN) {
    showNrow <- showNcol <- FALSE
  }

  if (!missing(style)) {
    rowheadstyle <- colheadstyle <- cellstyle <- style
  }

  if (missing(rowvarname)) {
    xname <- sapply(as.list(substitute({x})[-1]), deparse)
  } else {
    xname <- rowvarname
  }

  if (missing(y)) {
    singleRow <- TRUE
  #  y <- x
  #  x <- rep(1,length(x))
    y <- rep("N (%)",length(x))
    # yname <- xname
    if (!missing(colvarname)) {
      xname <- colvarname
    }
    if (!missing(rowvarname)) {
      xname <- rowvarname
    }
    if (!missing(varname)) {
      xname <- varname
    }
    yname <- ""
  } else {
    singleRow <- FALSE
    if (missing(colvarname)) {
      yname <- sapply(as.list(substitute({y})[-1]), deparse)
    } else {
      yname <- colvarname
    }
  }

  xname <- escapeSymbols(xname)
  yname <- escapeSymbols(yname)

  if (!is.factor(x)) x <- factor(x)
  if (!is.factor(y)) y <- factor(y)

  ly <- levels(y)
  if (!missing(omity)) ly <- ly[!(ly %in% omity)]
  ly <- escapeSymbols(ly)

  if (!singleRow) {
    ly[1] <- paste(yname,"\\\n",ly[1],sep="")
  }

  headings <- c("&nbsp;","&nbsp;",ly)

  if (topleft!="") headings[1] <- topleft

  if (showmisscol) headings <- c(headings,"Missing")
  if (showNcol) headings <- c(headings,"N")

  if (colheadstyle!="") {
    headings <- applydocxStyle(headings,colheadstyle)
  }

  headings <- paste0("**",headings,"**")

  result <- pipetableheader(headings,ndashes)

  levels(x)[levels(x)==""] <- blank
  levels(y)[levels(y)==""] <- blank

  xlevels <- levels(x)
  ylevels <- levels(y)

  if (!missing(omity)) ylevels <- ylevels[!(ylevels %in% omity)]

  for (i in seq_len(length(xlevels))) {
    row <- !is.na(x) & x==xlevels[i]
    if (i==1) {
      col1 <- paste0("**",xname,"**")
      if (rowheadstyle!="") {
        col1 <- applydocxStyle(col1,rowheadstyle)
       }
    } else {
      col1 <- "&nbsp;"
    }
    thisrow <- applydocxStyle(paste0("**",escapeSymbols(xlevels[i]),"**"),rowheadstyle)
    for (j in seq_len(length(ylevels))) {
      thisrow <- tablerow(
        thisrow,
        applydocxStyle(
          npct(x[y==ylevels[j]],vp=vp,digits=digits,pcs=pcs,includemiss=showmisscol,showp=showp)[xlevels[i]],
          cellstyle))
    }
    thisrow <- tablerow(col1,thisrow)
    if (showmisscol) {
      thisrow <- tablerow(thisrow,applydocxStyle(sum(is.na(y[row])),cellstyle))
    }
    thisrow <- tablerow(thisrow,applydocxStyle(sum(row),cellstyle))
    result <- pbind(result,thisrow)
  }
  if (showmissrow) {
    result <- pbind(
      result,
      tablerow("",
        applydocxStyle("**Missing**",cellstyle),
        applydocxStyle(table(y[is.na(x)],useNA="always"),cellstyle),
        applydocxStyle(sum(is.na(x)),cellstyle)))
  }
  if (showNrow) {
    if (showmisscol) {
      result <- pbind(
        result,
        tablerow("",
          applydocxStyle("**N**",cellstyle),
          tablerow(
            applydocxStyle(table(y,useNA="always"),cellstyle),
            applydocxStyle(length(y),cellstyle))))
    } else {
      result <- pbind(
        result,
        tablerow("",
          applydocxStyle("**N**",cellstyle),
          tablerow(
            applydocxStyle(table(y,useNA="no"),cellstyle),
            applydocxStyle(length(y),cellstyle))))
    }
  }
  result
}



#' @title [Row] Of [Col]umn [P]er[c]en[t]
#' @author Nick Barrowman
#' @description
#'  \code{RowOfColPct} Return one row of a pipetable of column percentages
#' @details          each row has a heading cell, a cell for each level, and a p-value cell
#'                   Note: percentages within the row will NOT add up to 100%
#' @param heading    a descriptive label for the variable
#' @param InRow      a logical variable representing membership in the row, e.g. sex=="Male"
#' @param ColVar     column variable, e.g. Group
#' @param levels     levels of the column variable, e.g. Group: c("A","B","C")
#' @param test       type of test statistic: "chisquare" (default), "fisher", or ""
#' @param workspace  size of workspace for Fisher's exact test
#' @param simulate.p.value  logical. Simulate the p-value for Fisher's exact test?
#' @param ...         extra arguments to pass to npct
#'
#' @return One row of a pipetable of column percentages
#' @export


RowOfColPct <- function(heading,InRow,ColVar,levels,test="chisquare",workspace = 2e+05,simulate.p.value=FALSE,...) {
  #
  # Return one row of a pipetable of column percentages.
  # Each row has a heading cell, a cell for each level, and a p-value cell.
  #
  # Note: percentages within the row will NOT add up to 100%.
  #
  # ARGUMENTS
  #
  #   heading :          Heading for first column of table
  #
  #   InRow :            a logical variable representing membership in the row,
  #                      e.g. sex=="Male"
  #
  #   ColVar :           column variable, e.g. Group
  #
  #   levels :           levels of the column variable, e.g. Group: c("A","B","C")
  #
  #   test :             type of test statistic: "chisquare" (default), "fisher", or ""
  #
  #   workspace :        size of workspace for Fisher's exact test
  #
  #   simulate.p.value : logical. Simulate the p-value for Fisher's exact test?
  #
  #   ... :              extra arguments to pass to npct
  #
  # EXAMPLE
  #
  #   Percent males in each group:
  #
  #     ROWOFCOLPCT("Male Gender n(%)",sex=="Male",Group,levels=c("A","B","C"))`


  if (test=="chisquare") {
    testStatistic <- chisq.test(table(ColVar,InRow))
  } else
    if (test=="fisher") {
      testStatistic <- fisher.test(
        table(ColVar,InRow),
        workspace=workspace,simulate.p.value=simulate.p.value)
    }


  result <- tablerow(heading)
  for (level in levels) {
    level <- as.character(level)
    result <- tablerow(result,npct(InRow[ColVar==level],...)["TRUE"])
  }

  if (test=="chisquare" | test=="fisher") {
    tablerow(result,formatp(testStatistic$p.value))
  } else {
    tablerow(result,"&nbsp;")
  }
}



#' @title [Row] Of [Row] [P]er[c]en[t]
#' @author Nick Barrowman
#' @description
#'  \code{RowOfRowPct} Return a row of a pipetable giving row percentages
#' @details          each row has a heading cell, a cell for each level, and an empty cell
#'                   the empty cell is for p-values that are displayed on other rows of the table
#'                   Note: percentages within the row will add up to 100% assuming all levels are specified
#' @param heading    heading for first column of table
#' @param ColVarWithinSubset     for example to find the distribution of groups: for male patients, Group[sex=="Male"]
#' @param levels     levels of the column variable, e.g. Group: c("A","B","C")
#' @param ...        extra arguments to pass to npct
#'
#' @return One row of a pipetable of column percentages
#' @export

RowOfRowPct <- function(heading,ColVarWithinSubset,levels,...) {
  #
  # Return a row of a pipetable giving row percentages.
  # Each row has a heading cell, a cell for each level, and an empty cell.
  # The empty cell is for p-values that are displayed on other rows of the table.
  #
  # Note: percentages within the row will add up to 100%,
  # assuming all levels are specified.
  #
  # ARGUMENTS
  #
  #   heading:            Heading for first column of table
  #
  #   ColVarWithinSubset: for example to find the distribution of groups
  #                       for male patients, Group[sex=="Male"]
  #
  #   levels:             levels of the column variable,
  #                       e.g. Group: c("A","B","C")
  #
  #   ...:                extra arguments to pass to npct
  #
  # EXAMPLE
  #
  #   Percent in each Group, for males:
  #
  #     RowOfRowPct("Male Gender n( row%)",Group[sex=="Male"],levels=c("A","B","C"))`
  #

  result <- tablerow(heading)
  for (level in levels) {
    level <- as.character(level)
    result <- tablerow(result,npct(ColVarWithinSubset,...)[level])
  }
  tablerow(result,"&nbsp;")
}




#' @title [Row] Of [Mean] [S]tandard [D]eviation
#' @author Nick Barrowman
#' @description
#'  \code{RowOfMeanSD} Return a row of a pipetable giving means, and if desired, a p-value from a one-way ANOVA to compare means
#' @details          each row has a heading cell, a cell for each level, and a p-value cell
#' @param heading    heading for first column of the table
#' @param var        the continuous variable of interest
#' @param group      column variable
#' @param levels     levels of the column variable, e.g. c("A","B","C")
#' @param test       logical value; should the p-value from a one-way ANOVA be shown?
#' @param ...        extra arguments to pass to meanSD
#'
#' @return A row of a pipetable giving means, and if desired, a p-value from a one-way ANOVA to compare means
#' @export

RowOfMeanSD <- function(heading,var,group,levels,test=TRUE,...) {
  #
  # Return a row of a pipetable giving means, and if desired,
  # a p-value from a one-way ANOVA to compare means.
  # Each row has a heading cell, a cell for each level, and a p-value cell.
  #
  # ARGUMENTS
  #
  #   heading : Heading for first column of table
  #
  #   var :     The continuous variable of interest
  #
  #   group :   column variable
  #
  #   levels :  levels of the column variable,
  #             e.g. c("A","B","C")
  #
  #   test :    logical value. Should the p-value from a one-way ANOVA be shown?
  #
  #   ... :     extra arguments to pass to meanSD
  #
  # EXAMPLE
  #
  #   Percent in each Group, for males:
  #
  #     RowOfMeanSD("Male Gender n( row%)",Group[sex=="Male"],levels=c("A","B","C"))`
  #
  var <- as.numeric(var)

  if (test) {
    fit <- lm(var~group)
    pv <- summary(fit)$coef["group","Pr(>|t|)"]
  }

  result <- tablerow(heading)
  for (level in levels) {
    level <- as.character(level)
    result <- tablerow(result,meanSD(var[group==level],...))
  }

  if (test) {
    tablerow(result,formatp(pv))
  } else {
    tablerow(result,"&nbsp;")
  }
}

#' @title [Column] [Spaces]
#' @author Nick Barrowman
#' @description \code{ColumnSpaces} Make non-breaking spaces to control column
#' width of tables
#' @param ...        arguments to define how many non-breaking spaces to include
#'   for each column
#'
#' @return A table with user specified non-breaking spaces that control column
#'   width of tables
#' @export
#'
ColumnSpaces <- function(...) {
  #
  # Make non-breaking spaces to control column width of tables.
  #
  # NJB, 31-Jan-2017
  #
  n <- list(...)
  G <- length(n)
  spaces <- ""
  for (i in 1:G) {
    spaces <- paste(spaces,paste(rep("&nbsp;",n[[i]]),collapse=""),sep="")
    if (i<G) spaces <- paste(spaces,"| ",collapse="")
  }
  spaces
}




#' @title [m]ultiple [l]inear [m]odel [table]
#' @author Nick Barrowman
#' @param xnames   vector of character strings naming predictor variables
#' @param yname    name of the outcome variable
#' @param pcutoff  p-value cutoff for predictor variables to enter the multivariable model
#' @param data     data frame
#' @param binary   vector of length two. First element is the name for a 0, second element is the name for a 1.
#' @param xorder   list specifying the order of values for named variables
#' @param xlabels  list specifying the names for specified variables
#'
#' @examples
#' # All of the following examples should be called inline.
#'
#' **Variable** | **Mean (SD)** | **Unadjusted coefficient (95% CI)** | **p-value** |  **Unadjusted coefficient (95% CI)** | **p-value** |
#' ------------|-------------------|-------------------|-------------------|-------------------|-------------------|
#' `r mlmtable(c("Sex","Severity","Group"),"Age",data=FakeData,pcutoff=1)`
#'
#' @export

mlmtable <- function(xnames,yname,pcutoff,data,binary=c("no","yes"),xorder=list(),xlabels=list(),f=list(meanSDf,ulmcf,upvf,mlmcf,mlmpvf),...) {

  nrowOriginal <- nrow(data)

  forced <- grep("^\\*",xnames) # variables preceded by a * are forced into the multivariate model

  xnames <- gsub("^\\*(.+)","\\1",xnames)  # strip of any leading stars

  message("mlmtable ---- Start ---------")
  message(paste("mlmtable: xnames =",paste(xnames,collapse=","),"  yname=",yname))

  # Identify complete cases across all predictor variables
  notmissing <- rep(TRUE,nrow(data))
  for (xname in xnames) {
    notmissing <- notmissing & !is.na(data[[xname]])
  }

  # Identify complete cases for the outcome variable
  notmissing <- notmissing & !is.na(data[[yname]])

  # Select complete cases
  data <- data[notmissing,]

  message(paste("mlmtable: original data object had",nrowOriginal,"rows."))
  message(paste("mlmtable: complete data object has",nrow(data),"rows."))

  message("mlmtable: make factors")

  # Convert the appropriate predictor variables into factors
  for (xname in xnames) {
    x <- data[[xname]]
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    data[[xname]] <- x
  }

  message("mORtable: figure out which variables to use in multivariate model")

  include <- rep(TRUE,length(xnames))
  names(include) <- xnames
  univariate <- vector("list",length(xnames))
  names(univariate) <- xnames
  i <- 0
  for (xname in xnames) {
    i <- i + 1
    univariate[[i]] <- unilm(xname,yname,data)
    include[i] <- univariate[[i]]$p<pcutoff
  }
  include[forced] <- TRUE

  xnamesMulti <- xnames[include]

  formula <- as.formula(paste(yname,"~",paste(xnamesMulti,collapse="+")))

  message("mlmtable: Run multivariate model")

  fit <- lm(formula,data=data)

  out <-""
  for (xname in xnames) {
    heading <- xname
    if (xname %in% names(xlabels)) {
      heading <- xlabels[[xname]]
    }

    out <- paste(out,markdownTable(
      VarRows(xname,yname,heading=heading,data=data,xorder=xorder,
              f=f,
              ufit=univariate[[xname]],mfit=fit,minclude=include[xname],...)))
  }
  out
}


#' @title [mean] and [S]tandard [D]eviation [f]unction
#'
#' @description Helper function: show n
#' @export
#'

meanSDf <- function(xname,lab,index,yname,data,xorder=list(),binary=c("no","yes"),...) {

  #browser()

  # message(paste("pctf: xname =",xname,"  yname =",yname))

  x <- data[[xname]]
  y <- data[[yname]]

  if (!is.factor(x)) {
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  }

  if (is.factor(x)) {

    values <- levels(x)
    if (xname %in% names(xorder)) {
      values <- values[xorder[[xname]]]
    }

    if (index==0) return("")
    #v <- rev(levels(factor(x)))[index]   # REVERSE SORT
    v <- values[index]

    meanSD(y[!is.na(x) & (x==v)],...)
  } else {
    ""
  }
}


#' @title [median] and [I]nter[Q]uartile [R]ange [f]unction
#' @description Helper function: show median (IQR)
#' @export
#'

medianIQRf <- function(xname,lab,index,yname,data,xorder=list(),binary=c("no","yes"),...) {

  # message(paste("pctf: xname =",xname,"  yname =",yname))

  x <- data[[xname]]
  y <- data[[yname]]

  if (!is.factor(x)) {
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  }

  if (is.factor(x)) {

    values <- levels(x)
    if (xname %in% names(xorder)) {
      values <- values[xorder[[xname]]]
    }

    if (index==0) return("")
    #v <- rev(levels(factor(x)))[index]   # REVERSE SORT
    v <- values[index]

    medianIQR(y[!is.na(x) & (x==v)])
  } else {
    ""
  }
}

#' @title [n] [f]unction
#'
#' @description Helper function: show n
#'
#' @export
#'

nf <- function(xname,lab,index,yname,data,xorder=list(),binary=c("no","yes"),...) {

  # message(paste("pctf: xname =",xname,"  yname =",yname))

  x <- data[[xname]]
  y <- data[[yname]]

  if (!is.factor(x)) {
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  }

  if (is.factor(x)) {

    values <- levels(x)
    if (xname %in% names(xorder)) {
      values <- values[xorder[[xname]]]
    }

    if (index==0) return("")
    #v <- rev(levels(factor(x)))[index]   # REVERSE SORT
    v <- values[index]

    length(y[!is.na(x) & (x==v)])
  } else {
    length(y[!is.na(x)])
  }
}


#'
#' @title [uni]variate [l]inear [m]odel
#' @author Nick Barrowman
#' @description
#' \code{unilog}  run a [uni]variate [l]inear [m]odel
#' @param xname   name of predictor variable
#' @param yname   name of y variable
#' @param df      dataframe
#' @param binary  re-label logical or binary vectors into 'no' and 'yes' for clarity
#'
#' @return univariate regression model
#'
#' @export
#'

unilm <- function(xname,yname,df,binary=c("no","yes")) {

  x <- df[[xname]]

  if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)

  df[[xname]] <- x

  formula <- as.formula(paste(yname,"~",xname))

  fit <- lm(formula,data=df,subset=!is.na(df[[xname]]))

  ci <- suppressMessages(confint(fit))

  tab <- cbind(coef(fit),ci)
  colnames(tab) <- c("est","95%lo","95%hi")

  formula0 <- as.formula(paste(".~.-",xname,sep=""))
  fit0 <- update(fit,formula0)

  a <- anova(fit,fit0)

  list(fit=fit,citable=tab,fit0=fit0,p=a$"Pr(>F)"[2])
}


#' @title [u]nivariate [l]inear [m]odel [c]oefficient [f]unction
#' @author Nick Barrowman
#' @description
#' A helper function for the ulmtable and mlmtable functions
#' @param xname   name of predictor variable
#' @param lab     label
#' @param index   index
#' @param yname   name of y variable
#' @param data    dataframe
#' @param xorder  named list of display order of levels for corresponding predictor variables
#' @param ufit    univariate model fit
#' @param ...     other arguments to pass into the model
#'
#' @return univariate odds ratio
#'
#'
#' @export

ulmcf <- function(xname,lab,index,yname,data,xorder,ufit,digits=2,...) {

  #browser()

  if (index==0) return("") # HEADER ROW

  citable <- ufit$citable

  if (is.na(match(lab,rownames(citable)))) {
    "0 (reference)"
  } else {
    paste(
      around(citable[lab,"est"],digits=digits),
      " (",
      around(citable[lab,"95%lo"],digits=digits),
      ", ",
      around(citable[lab,"95%hi"],digits=digits),
      ")",
      sep=""
    )
  }
}


#' @title [m]ultivariate [l]inear [m]odel [c]oefficient [f]unction
#' @author Nick Barrowman
#' @description
#' A helper function for the mlmtable function
#'
#' @param xname    vector of names of potential predictors
#' @param lab      label
#' @param index    index
#' @param yname    name of y variable
#' @param data     dataframe
#' @param mfit     multivariate model fit
#' @param minclude what to include?
#' @param ...      other arguments to be passed into the function
#'
#' @return adjusted odds ratios from a multivariate regression model
#'
#'
#' @export
#'
mlmcf <- function(xname,lab,index,yname,data,xorder,mfit,minclude,digits=2,...) {

  if (!minclude) return("")

  if (index==0) return("")

  co <- summary(mfit)$coef

  ci <- suppressMessages(confint(mfit))

  tab <- cbind(coef(mfit),ci)
  colnames(tab) <- c("est","95%lo","95%hi")

  if (is.na(match(lab,rownames(tab)))) {
    "0 (reference)"
  } else {
    paste(
      around(tab[lab,"est"],digits=digits),
      " (",
      around(tab[lab,"95%lo"],digits=digits),
      ", ",
      around(tab[lab,"95%hi"],digits=digits),
      ")",
      sep=""
    )
  }
}


#' @title [m]ultivariate [l]inear [m]odel [p]-[v]alue [f]unction
#' @author Nick Barrowman
#' @description
#' A helper function for the mORtable function
#'
#' @param xname    vector of names of potential predictors
#' @param lab      label
#' @param index    index
#' @param yname    name of y variable
#' @param data     dataframe
#' @param mfit     multivariate model fit
#' @param minclude what to include?
#' @param ...      other arguments to be passed into the function
#'
#'
#' @return p-values from a multivariate regression model
#'
#' @export
#'

mlmpvf <- function(xname,lab,index,yname,data,xorder,mfit,minclude,...) {

  x <- data[[xname]]

  if (!minclude) return("")

  if (index==0 | !is.factor(x)) {
    formula0 <- as.formula(paste(".~.-",xname,sep=""))
    mfit0 <- update(mfit,formula0)

    a <- anova(mfit,mfit0)
    formatp(a$"Pr(>F)"[2])
  } else {
    ""
  }
}


#' @title Update the CRUmarkdown package
#' @author Nick Barrowman
#' @description
#' Install the latest version of CRUmarkdown from the source tarball in R:/CRU Epibiostat/CRUpackages
#' Assuming that a version of CRUmarkdown has been previously installed, it can be updated to the latest version by typing: \code{CRUmarkdown::up()}
#'
#' @export
#'

up <- function() {
  cat("Current version:",paste(packageVersion("CRUmarkdown")),"\n")

  install.packages(
    list.files(
      path="R:/CRU Epibiostat/CRUpackages",
      pattern="CRUmarkdown.*.tar.gz",full.names=TRUE),
    repos=NULL,type="source")

  cat("Updated version:",paste(packageVersion("CRUmarkdown")),"\n")
}


#' @title Interactively display a Markdown string in the RStudio viewer.
#' @author Nick Barrowman
#' @description Interactively display a Markdown string in the RStudio viewer.
#' @param x The Markdown string to render.
#' @details Note that to use this function, the \code{rstudioapi} package must have been installed.
#'
#' @seealso \code{vv} to display (possibly multi-line) pasted R Markdown text (rather than a single string of Markdown text passed as an argument).
#'
#' @examples
#' ## Simple example:
#' vmd("**bold** *italics* x^superscript^ y~subscript~")
#'
#' ## Render Markdown resulting from a call to the npct function:
#' vmd(npct(FakeData$Age,nmiss=TRUE)["5"])
#'
#' @export
#'

vmd <- function(x) {
  if (missing(x)) stop("Missing Markdown string. Perhaps you wanted to run vv() ?")

  x <- paste0(
    "---\npagetitle: markdown rendered by CRUmarkdown::vmd\n---\n\n",
    x)

  dir <- tempfile()
  dir.create(dir)
  mdFile <- file.path(dir,"source.md")
  cat(x,file=mdFile)
  rmarkdown::render(mdFile,"html_document",output_file="index.html",output_dir=dir)
  htmlFile <- file.path(dir,"index.html")
  rstudioapi::viewer(htmlFile)
}

#' @title Display R Markdown in the RStudio viewer
#' @author Nick Barrowman
#' @description Convert R Markdown text into Markdown text (by executing any inline R code), and then render and display it in the RStudio viewer pane.
#' @param quiet     Suppress the message from pandoc?
#' @param linebreak Character string used to handle line break issues during processing. (Users can ignore this.)
#' @details Note that to use this function, the \code{rstudioapi} package must have been installed.
#'
#' To use \code{vv}, do the following:
#' \itemize{
#'   \item Run the command without arguments: \code{vv()}
#'   \item At the prompt \strong{1: }, paste in multi-line R Markdown code.
#'   \item Press Enter on a blank line to indicate the end of the R Markdown code.
#' }
#' Upon executing \code{vv()}, the following steps take place:
#' \itemize{
#'   \item Any inline R code is evaluated in R (in the current environment).
#'   \item The results are reinserted into the Markdown text.
#'   \item The Markdown text is displayed in the console.
#'   \item The Markdown text is stored in a temporary file.
#'   \item \strong{pandoc} is used to convert the Markdown file to a temporary HTML file.
#'   \item The RStudio viewer is used to display the HTML file.
#' }
#' Notes
#' \itemize{
#'   \item R Markdown code chunks are not (currently) supported.
#'   \item \strong{In order for pasting of code to work properly},
#'         the RStudio setting "Auto-indent code after paste" must be turned \emph{off}.
#'         (See Tools > Global Options... > Code.)
#'   \item Rendering in HTML may not look identical to rendering in Microsoft Word, for example.
#' }
#'
#' @seealso \code{vmd} to display a single Markdown (rather than R Markdown) string passed as an argument (rather than pasted).
#'
#' @examples
#' ## Simple example
#' ## Suppose you want to see how the following line of R Markdown will look:
#'
#' `r npct(FakeData$Age,nmiss=TRUE)["5"]`
#'
#' vv()
#' 1: `r npct(FakeData$Age,nmiss=TRUE)["5"]`
#' 2:
#' Read 1 item
#' 12 (30.8%) ^mv=7^
#' # Formatted result appears in RStudio Viewer pane
#'
#' ## More complicated example.
#' ## Suppose you want to see the pipe table created by the following R Markdown lines:
#'
#' **Variable** | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value**
#' ------------|-------------------|-------------|---------
#' `r uORtable(c("Age","Severity"),"Male",data=FakeData)`
#'
#' vv()
#' 1: **Variable** | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value**
#' 2: ------------|-------------------|-------------|---------
#' 3: `r uORtable(c("Age","Severity"),"Male",data=FakeData)`
#' 4:
#' Read 3 items
#' **Variable** | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value**
#' ------------|-------------------|-------------|---------
#'  **Age**|\ |1.21 (0.51, 2.92)|0.66
#'  **Severity**|\ |\ |0.76
#' \ \ \ \ \ Mild|7/16 (43.8%)|1.0|\
#' \ \ \ \ \ Moderate|5/15 (33.3%)|0.64 (0.14, 2.75)|\
#' \ \ \ \ \ Severe|2/4 (50.0%)|1.29 (0.13, 13.07)|\
#' # Formatted result appears in RStudio Viewer pane
#'
#' @export
#'

vv <- function(quiet=TRUE,linebreak="LINEBREAKCODE") {
  pastedText <- scan(what = "", sep = "\n")

  pt <- paste(pastedText,collapse=linebreak)

  out <- ""

  w <- pt
  done <- FALSE
  while (!done) {
    pos <- regexpr("`r [^`]+`",w)
    #cat("..........pos=",pos,"\n")
    if (pos==-1) {
      out <- paste(out,w)
      done <- TRUE
    } else {
      left  <- substr(w,1,pos-1)
      out <- paste0(out,left)
      n <- attr(pos,"match.length")
      x <- substr(w,pos,pos+n-1)
      r <- gsub("`r ([^`]+)`","\\1",x)
      r <- gsub(linebreak,"",r)
      rOut <- eval(parse(text = r),envir=parent.frame(n=2))
      out <- paste0(out,rOut)
      if ((pos+n)==length(w)) {
        #
        # R Markdown inline code goes to the end
        #
        done <- TRUE
      } else {
        right <- substr(w,pos+n,nchar(w))
        w <- right
      }
    }
  }

  result <- gsub(linebreak,"\n",out)
  cat(result)

  result <- paste0(
    "---\npagetitle: markdown rendered by CRUmarkdown::vv\n---\n\n",
    result)

  dir <- tempfile()
  dir.create(dir)
  mdFile <- file.path(dir, "source.md")
  cat(result, file = mdFile)
  rmarkdown::render(mdFile, "html_document", output_file = "index.html",
      output_dir = dir,quiet=quiet)
  htmlFile <- file.path(dir, "index.html")
  rstudioapi::viewer(htmlFile)
  invisible(NULL)
}


#' @title [m]ultivariate [O]dds [R]atio [table] version [2]
#' @author Nick Barrowman
#' @description
#' \code{mORtable2} Generates a table with N(\%), number of missing values,
#' OR(lower CI, upper CI), and p-values from univariable logistic regression,
#' and OR(lower CI, upper CI), and p-values from a multivariate logistic regression
#' (which includes all variables with p-value < \code{pcutoff}).
#' Each univariable logistic regression uses all available data.
#' The multivariable logistic regression model uses complete cases.
#' A sample size summary is provided below the table.
#' @details xnames preceded by a star will be forced into the multivariable model
#' @param xnames  vector of names of potential predictors
#' @param yname   name of outcome variable
#' @param pcutoff p-value threshold for inclusion of predictor in the multivariable model
#' @param data    data frame
#' @param binary  vector of two names for logical variables (instead of TRUE, FALSE)
#' @param xorder  named list of display order of levels for corresponding predictor variables
#' @param xlabels named list of labels for corresponding predictor variables
#' @param outcome name of the outcome variable to display in the column header
#' @param showmiss show the column of missing values?
#'
#' @return  a Markdown pipetable table with N(\%), OR(lower CI, upper CI), and p-values
#'
#' @examples
#' # All of the following code should be called inline.
#'
#' # A basic call to mORtable2:
#' mORtable2(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",data=wide)
#'
#' # Also specify the cutoff:
#' mORtable2(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",0.1,data=wide)
#'
#' # Also specify that values of the AHICat variable should listed in order 1, 3, 2:
#' mORtable2(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)))
#'
#' # Also specify nicer labels for the AHICat, LowO2Cat, and HighCO2Cat variables:
#' mORtable2(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)),
#'   xlabels=list(AHICat="AHI",LowO2Cat="Lowest O~2~ saturation",HighCO2Cat="Highest CO~2~"))
#'
#' @export

mORtable2 <- function(xnames,yname,pcutoff,data,binary=c("no","yes"),xorder=list(),xlabels=list(),outcome="Outcome",showmiss=TRUE) {

  nrowOriginal <- nrow(data)
  SampleSizeNotMissingOutcome <- sum(!is.na(data[[yname]]))

  forced <- grep("^\\*",xnames) # variables preceded by a * are forced into the multivariate model

  xnames <- gsub("^\\*(.+)","\\1",xnames)  # strip of any leading stars

  message("mORtable2 ---- Start ---------")
  message(paste("mORtable2: xnames =",paste(xnames,collapse=","),"  yname=",yname))

  message("mORtable2: make factors")

  # Convert the appropriate predictor variables into factors
  for (xname in xnames) {
    x <- data[[xname]]
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    data[[xname]] <- x
  }

  # Identify complete cases across all predictor variables
  notmissing <- rep(TRUE,nrow(data))
  for (xname in xnames) {
    notmissing <- notmissing & !is.na(data[[xname]])
  }

  # Identify complete cases for the outcome variable
  notmissing <- notmissing & !is.na(data[[yname]])

  # Select complete cases
  dataC <- data[notmissing,]

  message(paste("mORtable2: original data object had",nrowOriginal,"rows."))
  message(paste("mORtable2: complete data object has",nrow(dataC),"rows."))

  message("mORtable2: figure out which variables to use in multivariate model")

  include <- rep(TRUE,length(xnames))
  names(include) <- xnames
  univariate <- vector("list",length(xnames))
  names(univariate) <- xnames
  i <- 0
  for (xname in xnames) {
    i <- i + 1
    univariate[[i]] <- unilog(xname,yname,data)
    include[i] <- univariate[[i]]$p<pcutoff
  }
  include[forced] <- TRUE

  xnamesMulti <- xnames[include]

  if (length(xnamesMulti)==0) {
    formula <- as.formula(paste(yname,"~ 1"))
  } else {
    formula <- as.formula(paste(yname,"~",paste(xnamesMulti,collapse="+")))
  }

  message("mORtable2: Run multivariate model")
  message(paste0("nrow(dataC)=",nrow(dataC)))

  #fit <- glm(formula,family=binomial,data=dataC)

  fit <- do.call("glm",list(formula=formula,family=binomial,data=dataC))

  if (showmiss) {
    f <- list(nmissf,pctf,uorf,upvf,morf,mpvf)
    header <- c("Variable","Missing",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value","Adjusted OR (95% CI)","p-value")
  } else {
    f <- list(pctf,uorf,upvf,morf,mpvf)
    header <- c("Variable","Unadjusted OR (95% CI)","p-value","Adjusted OR (95% CI)","p-value")
  }

  out <- pipetableheader(header,bold=TRUE)
  out <- paste0(out,"\n")


  for (xname in xnames) {
    heading <- xname
    if (xname %in% names(xlabels)) {
      heading <- xlabels[[xname]]
    }

    out <- paste(out,markdownTable(
      VarRows(xname,yname,heading=heading,data=data,xorder=xorder,
              f=f,
              ufit=univariate[[xname]],mfit=fit,minclude=include[xname])))
  }
  paste0(out,
    paste0(
      "**Sample size** ",
      "Total: ",nrowOriginal,",&nbsp;&nbsp;",
      "Excluding missing values in the outcome: ",SampleSizeNotMissingOutcome,",&nbsp;&nbsp;",
      "Multivariable analysis: ",sum(notmissing),",&nbsp;&nbsp;",
      "**Events**: ",sum(data[[yname]],na.rm=TRUE),",&nbsp;&nbsp;",
      "**p-value cutoff**: ",pcutoff))
}



#' @title [m]ultivariate [O]dds [R]atio [table] version [3]
#' @author Nick Barrowman
#' @description
#' \code{mORtable3} Generates a table with N(\%), number of missing values,
#' OR(lower CI, upper CI), and p-values from univariable logistic regression,
#' and OR(lower CI, upper CI), and p-values from a multivariate logistic regression
#' (which includes all variables with p-value < \code{pcutoff}).
#' Each univariable logistic regression uses all available data.
#' The multivariable logistic regression model uses complete cases.
#' A sample size summary is provided below the table.
#' Note that the column of N(\%) excludes cases where the outcome variable is missing.
#' @details xnames preceded by a star will be forced into the multivariate model
#' @param xnames    vector of names of potential predictors
#' @param yname     name of outcome variable
#' @param pcutoff   p-value threshold for inclusion of predictor in the multivariate model
#' @param data      data frame
#' @param binary    vector of two names for logical variables (instead of TRUE, FALSE)
#' @param xorder    named list of display order of levels for corresponding predictor variables
#' @param xlabels   named list of labels for corresponding predictor variables
#' @param outcome   name of the outcome variable to display in the column header
#' @param showmiss  show the column of missing values?
#' @param showuni   show univariate results?
#' @param showmulti show multivariate results?
#'
#' @return  a Markdown pipetable table with N(\%), OR(lower CI, upper CI), and p-values
#'
#' @examples
#' # All of the following code should be called inline.
#'
#' # A basic call to mORtable3:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",data=wide)
#'
#' # Also specify the cutoff:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",0.1,data=wide)
#'
#' # Also specify that values of the AHICat variable should listed in order 1, 3, 2:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)))
#'
#' # Also specify nicer labels for the AHICat, LowO2Cat, and HighCO2Cat variables:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)),
#'   xlabels=list(AHICat="AHI",LowO2Cat="Lowest O~2~ saturation",HighCO2Cat="Highest CO~2~"))
#'
#' @export

mORtable3 <- function(xnames,yname,pcutoff,data,binary=c("no","yes"),xorder=list(),xlabels=list(),outcome="Outcome",showmiss=TRUE,
showuni=TRUE,showmulti=TRUE) {

  nrowOriginal <- nrow(data)
  SampleSizeNotMissingOutcome <- sum(!is.na(data[[yname]]))

  dataNMO <- data[!is.na(data[[yname]]),]  # data Not Missing Outcome

  forced <- grep("^\\*",xnames) # variables preceded by a * are forced into the multivariate model

  xnames <- gsub("^\\*(.+)","\\1",xnames)  # strip of any leading stars

  message("mORtable3 ---- Start ---------")
  message(paste("mORtable3: xnames =",paste(xnames,collapse=","),"  yname=",yname))

  message("mORtable3: make factors")

  # Convert the appropriate predictor variables into factors
  for (xname in xnames) {
    x <- dataNMO[[xname]]
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    dataNMO[[xname]] <- x
  }

  # Identify complete cases across all predictor variables
  notmissing <- rep(TRUE,nrow(dataNMO))
  for (xname in xnames) {
    notmissing <- notmissing & !is.na(dataNMO[[xname]])
  }

  # Identify complete cases for the outcome variable
  notmissing <- notmissing & !is.na(dataNMO[[yname]])

  # Select complete cases
  dataC <- dataNMO[notmissing,]

  message(paste("mORtable3: original data object had",nrowOriginal,"rows."))
  message(paste("mORtable3: complete data object has",nrow(dataC),"rows."))

  message("mORtable3: figure out which variables to use in multivariate model")

  include <- rep(TRUE,length(xnames))
  names(include) <- xnames
  univariate <- vector("list",length(xnames))
  names(univariate) <- xnames
  i <- 0
  for (xname in xnames) {
    i <- i + 1
    univariate[[i]] <- unilog(xname,yname,dataNMO)
    include[i] <- univariate[[i]]$p<pcutoff
  }
  include[forced] <- TRUE

  xnamesMulti <- xnames[include]

  if (length(xnamesMulti)==0) {
    formula <- as.formula(paste(yname,"~ 1"))
  } else {
    formula <- as.formula(paste(yname,"~",paste(xnamesMulti,collapse="+")))
  }

  message("mORtable3: Run multivariate model")
  message(paste0("nrow(dataC)=",nrow(dataC)))

  #fit <- glm(formula,family=binomial,data=dataC)

  fit <- do.call("glm",list(formula=formula,family=binomial,data=dataC))

  if (showmiss) {
    f <- list(nmissf,pctf,uorf,upvf,morf,mpvf)
    if (showuni & showmulti) {
      header <- c("Variable","Missing",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value","Adjusted OR (95% CI)","p-value")
    } else
    if (showuni & !showmulti) {
      header <- c("Variable","Missing",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value")
    } else
    if (!showuni & showmulti) {
      header <- c("Variable","Missing",paste(outcome,"n/N"),"Adjusted OR (95% CI)","p-value")
    }
  } else {
    f <- list(pctf,uorf,upvf,morf,mpvf)
    if (showuni & showmulti) {
      header <- c("Variable",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value","Adjusted OR (95% CI)","p-value")
    } else
    if (showuni & !showmulti) {
      header <- c("Variable",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value")
    } else
    if (!showuni & showmulti) {
      header <- c("Variable",paste(outcome,"n/N"),"Adjusted OR (95% CI)","p-value")
    }
  }

  out <- pipetableheader(header,bold=TRUE)
  out <- paste0(out,"\n")


  for (xname in xnames) {
    heading <- xname
    if (xname %in% names(xlabels)) {
      heading <- xlabels[[xname]]
    }

    #browser()
    vr <- VarRows(xname,yname,heading=heading,data=dataNMO,xorder=xorder,f=f,
      ufit=univariate[[xname]],mfit=fit,minclude=include[xname])

    if (showuni & showmulti) {
      out <- paste(out,markdownTable(vr))
    } else
    if (showuni & !showmulti) {
      out <- paste(out,markdownTable(vr[,-c(ncol(vr)-1,ncol(vr)),drop=FALSE]))  # This needs to be more robust instead of using column numbers
    } else
    if (!showuni & showmulti) {
      out <- paste(out,markdownTable(vr[,-c(ncol(vr)-3,ncol(vr)-2),drop=FALSE]))  # This needs to be more robust instead of using column numbers
    }
  }

  paste0(out,
    paste0(
      "**Sample size** ",
      "Total: ",nrowOriginal,",&nbsp;&nbsp;",
      "Excluding missing values in the outcome: ",SampleSizeNotMissingOutcome,",&nbsp;&nbsp;",
      "Multivariable analysis: ",sum(notmissing),",&nbsp;&nbsp;",
      "**Events**: ",sum(dataNMO[[yname]],na.rm=TRUE),",&nbsp;&nbsp;",
      "**p-value cutoff**: ",pcutoff))

}




#' @title [m]ultivariate [O]dds [R]atio [table] version [4]
#' @author Nick Barrowman
#' @description
#' \code{mORtable3} Generates a table with N(\%), number of missing values,
#' OR(lower CI, upper CI), and p-values from univariable logistic regression,
#' and OR(lower CI, upper CI), and p-values from a multivariate logistic regression
#' (which includes all variables with p-value < \code{pcutoff}).
#' Each univariable logistic regression uses all available data.
#' The multivariable logistic regression model uses complete cases.
#' A sample size summary is provided below the table.
#' Note that the column of N(\%) excludes cases where the outcome variable is missing.
#' @details xnames preceded by a star will be forced into the multivariate model
#' @param xnames    vector of names of potential predictors
#' @param yname     name of outcome variable
#' @param pcutoff   p-value threshold for inclusion of predictor in the multivariate model
#' @param data      data frame
#' @param binary    vector of two names for logical variables (instead of TRUE, FALSE)
#' @param xorder    named list of display order of levels for corresponding predictor variables
#' @param xlabels   named list of labels for corresponding predictor variables
#' @param outcome   name of the outcome variable to display in the column header
#' @param showmiss  show the column of missing values?
#' @param showuni   show univariate results?
#' @param showmulti show multivariate results?
#'
#' @return  a Markdown pipetable table with N(\%), OR(lower CI, upper CI), and p-values
#'
#' @examples
#' # All of the following code should be called inline.
#'
#' # A basic call to mORtable3:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",data=wide)
#'
#' # Also specify the cutoff:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",0.1,data=wide)
#'
#' # Also specify that values of the AHICat variable should listed in order 1, 3, 2:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)))
#'
#' # Also specify nicer labels for the AHICat, LowO2Cat, and HighCO2Cat variables:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)),
#'   xlabels=list(AHICat="AHI",LowO2Cat="Lowest O~2~ saturation",HighCO2Cat="Highest CO~2~"))
#'
#' @export

mORtable4 <- function(xnames,yname,pcutoff,data,binary=c("no","yes"),xorder=list(),xlabels=list(),outcome="Outcome",showmiss=TRUE,
showuni=TRUE,showmulti=TRUE) {

  nrowOriginal <- nrow(data)
  SampleSizeNotMissingOutcome <- sum(!is.na(data[[yname]]))

  dataNMO <- data[!is.na(data[[yname]]),c(yname,xnames)]  # data Not Missing Outcome

  forced <- grep("^\\*",xnames) # variables preceded by a * are forced into the multivariate model

  xnames <- gsub("^\\*(.+)","\\1",xnames)  # strip of any leading stars

  message("mORtable4 ---- Start ---------")
  message(paste("mORtable4: xnames =",paste(xnames,collapse=","),"  yname=",yname))

  message("mORtable4: make factors")

  # Convert the appropriate predictor variables into factors
  for (xname in xnames) {
    x <- dataNMO[[xname]]
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    dataNMO[[xname]] <- x
  }

  # Identify complete cases across all predictor variables
  notmissing <- rep(TRUE,nrow(dataNMO))
  for (xname in xnames) {
    notmissing <- notmissing & !is.na(dataNMO[[xname]])
  }

  # Identify complete cases for the outcome variable
  notmissing <- notmissing & !is.na(dataNMO[[yname]])

  # Select complete cases
  dataC_multi <- dataNMO[notmissing,]

  if (showmulti) {
    dataC <- dataC_multi
  } else {
    dataC <- dataNMO
  }

  message(paste("mORtable4: original data object had",nrowOriginal,"rows."))
  message(paste("mORtable4: complete data object has",nrow(dataC),"rows."))

  message("mORtable4: figure out which variables to use in multivariate model")

  include <- rep(TRUE,length(xnames))
  names(include) <- xnames
  univariate <- vector("list",length(xnames))
  names(univariate) <- xnames
  i <- 0
  for (xname in xnames) {
    i <- i + 1
    univariate[[i]] <- unilog(xname,yname,dataNMO)
    include[i] <- univariate[[i]]$p<pcutoff
  }
  include[forced] <- TRUE

  xnamesMulti <- xnames[include]

  if (length(xnamesMulti)==0) {
    formula <- as.formula(paste(yname,"~ 1"))
  } else {
    formula <- as.formula(paste(yname,"~",paste(xnamesMulti,collapse="+")))
  }

  if (showmulti) {
    message("mORtable4: Run multivariate model")
    message(paste0("nrow(dataC)=",nrow(dataC)))

    #fit <- glm(formula,family=binomial,data=dataC)

    fit <- do.call("glm",list(formula=formula,family=binomial,data=dataC))
  } else {
    fit <- do.call("glm",list(formula=formula,family=binomial,data=dataC_multi))
  }

  if (showmiss) {
    if (showmulti) {
      f <- list(nmissf,pctf,uorf,upvf,morf,mpvf)
    } else {
      f <- list(nmissf,pctf,uorf,upvf)
    }
    if (showuni & showmulti) {
      header <- c("Variable","Missing",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value","Adjusted OR (95% CI)","p-value")
    } else
    if (showuni & !showmulti) {
      header <- c("Variable","Missing",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value")
    } else
    if (!showuni & showmulti) {
      header <- c("Variable","Missing",paste(outcome,"n/N"),"Adjusted OR (95% CI)","p-value")
    }
  } else {
    if (showmulti) {
      f <- list(pctf,uorf,upvf,morf,mpvf)
    } else {
      f <- list(pctf,uorf,upvf)
    }
    if (showuni & showmulti) {
      header <- c("Variable",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value","Adjusted OR (95% CI)","p-value")
    } else
    if (showuni & !showmulti) {
      header <- c("Variable",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value")
    } else
    if (!showuni & showmulti) {
      header <- c("Variable",paste(outcome,"n/N"),"Adjusted OR (95% CI)","p-value")
    }
  }

  out <- pipetableheader(header,bold=TRUE)
  out <- paste0(out,"\n")


  for (xname in xnames) {
    heading <- xname
    if (xname %in% names(xlabels)) {
      heading <- xlabels[[xname]]
    }

    #browser()
    vr <- VarRows(xname,yname,heading=heading,data=dataNMO,xorder=xorder,f=f,
      ufit=univariate[[xname]],mfit=fit,minclude=include[xname])

    out <- paste(out,markdownTable(vr))

    # if (showuni & showmulti) {
    #   out <- paste(out,markdownTable(vr))
    # } else
    # if (showuni & !showmulti) {
    #   out <- paste(out,markdownTable(vr[,-c(ncol(vr)-1,ncol(vr)),drop=FALSE]))  # This needs to be more robust instead of using column numbers
    # } else
    # if (!showuni & showmulti) {
    #   out <- paste(out,markdownTable(vr[,-c(ncol(vr)-3,ncol(vr)-2),drop=FALSE]))  # This needs to be more robust instead of using column numbers
    # }
  }

  if (showmulti) {
    output <- paste0(out,
      paste0(
        "**Sample size** ",
        "Total: ",nrowOriginal,",&nbsp;&nbsp;",
        "Excluding missing values in the outcome: ",SampleSizeNotMissingOutcome,",&nbsp;&nbsp;",
        "Multivariable analysis: ",sum(notmissing),",&nbsp;&nbsp;",
        "**Events**: ",sum(dataNMO[[yname]],na.rm=TRUE),",&nbsp;&nbsp;",
        "**p-value cutoff**: ",pcutoff))
  } else {
   # browser()
    output <- paste0(out,
      paste0(
        "**Coefficients:** ",
        length(fit$coefficients),
        ",&nbsp;&nbsp;",
        "**Sample size**: ",
        nrowOriginal,
        ",&nbsp;&nbsp;",
        "**excl. missing outcomes:** ",
        SampleSizeNotMissingOutcome,
        ",&nbsp;&nbsp;",
        "**& excl. missing predictors** ",
        sum(notmissing)))
  }

  list(output=output,fit=fit,vr=vr,data_multi=dataC_multi)

}





#
# helper function
#
lrtabvar <- function(dep,indep,data,binary) {
  #
  # Perform univariable tetss
  #
  formNull <- as.formula(paste(dep, "~1"))

  fitNull <- do.call("glm", list(formula = formNull,family=binomial,data = data))
  if (is.null(offset)) {
    formIndiv <- as.formula(paste(dep, "~",indep))
  } else {
    formIndiv <- as.formula(paste(dep, "~",indep))
  }
  fitIndiv <- do.call("glm", list(formula = formIndiv,family=binomial,data = data))
  x <- data[[indep]]
  if (is.factor(x)) {

    values <- levels(x)
    indepref <- paste0(indep,values[1])
    lab <- paste0(indep,values)
    #values <- values[lab %in% names(coef(fitIndiv))]

    #label <- c(indep,"Ref",values)
    label <- c(indep,values)
    LRTpIndiv <- c(anova(fitIndiv,fitNull,test="LRT")[2,"Pr(>Chi)"],rep(NA,length(coef(fitIndiv))))
    coIndiv <- c(NA,0,coef(fitIndiv)[-1])
    names(coIndiv)[1] <- indep
    names(coIndiv)[2] <- indepref
    ciIndiv <- rbind(c(NA,NA),c(NA,NA),suppressMessages(confint(fitIndiv)[-1,,drop=FALSE]))
    rownames(ciIndiv)[1] <- indep
    rownames(ciIndiv)[2] <- indepref
    faclevel <- c(FALSE,rep(TRUE,length(coef(fitIndiv))))
    facstart <- c(FALSE,TRUE,rep(FALSE,length(coef(fitIndiv))-1))
  } else {
    label <- indep
    LRTpIndiv <- anova(fitIndiv,fitNull,test="LRT")[2,"Pr(>Chi)"]
    coIndiv <- coef(fitIndiv)[-1]
    ciIndiv <- suppressMessages(confint(fitIndiv)[-1,,drop=FALSE])
    faclevel <- FALSE
    facstart <- FALSE
  }
  list(label=label,faclevel=faclevel,facstart=facstart,p=LRTpIndiv,co=coIndiv,ci=ciIndiv)
}


#' @title [l]ogistic [r]egression [tab]le
#' @author Nick Barrowman
#' @description
#'
#' @param dep          name of dependent (outcome) variable
#' @param indep        names of independent (explanatory) variables
#' @param data      data frame
#' @param binary    vector of two names for logical variables (instead of TRUE, FALSE)
#'
#' @return  a list with elements \code{ltab}, \code{tab}, and \code{fit}
#'
#' @export
lrtab <- function(dep,indep,data,binary = c("no","yes")) {

  nrowOriginal <- nrow(data)

  dataNMO <- data[!is.na(data[[dep]]), ]

  for (xname in indep) {
    x <- dataNMO[[xname]]
    if (is.logical(x))
      x <- factor(as.numeric(x), levels = c(0, 1), labels = binary)
    if (all(x[!is.na(x)] == 0 | x[!is.na(x)] == 1))
      x <- factor(as.numeric(x), levels = c(0, 1), labels = binary)
    dataNMO[[xname]] <- x
  }
  notmissing <- rep(TRUE, nrow(dataNMO))
  for (xname in indep) {
      notmissing <- notmissing & !is.na(dataNMO[[xname]])
  }
  notmissing <- notmissing & !is.na(dataNMO[[dep]])
  dataC <- dataNMO[notmissing, ]
  message(paste("lrtab: original data object had",
      nrowOriginal, "rows."))
  message(paste("lrtab: complete data object has",
      nrow(dataC), "rows."))

  nvar <- length(indep)

  #
  # Perform univariable tetss
  #
  LRTpIndiv <- coIndiv <- ciIndiv <- label <- faclevel <- facstart <- vars <- outcome <- NULL
  for (i in seq_len(nvar)) {
    out <- lrtabvar(dep,indep[i],data=dataC)
    LRTpIndiv <- c(LRTpIndiv,out$p)
    coIndiv <- c(coIndiv,out$co)
    ciIndiv <- rbind(ciIndiv,out$ci)
    label <- c(label,out$label)
    faclevel <- c(faclevel,out$faclevel)
    facstart <- c(facstart,out$facstart)
    vars <- c(vars,rep(indep[i],length(out$label)))
    if (is.factor(dataC[[indep[i]]])) {
      for (j in 0:length(levels(dataC[[indep[i]]]))) {
        if (j==0) {
          outcome <- c(outcome,"&nbsp;")
        } else {
          outcome <- c(outcome,pctf(
            xname=indep[i],
            index=j,
            yname=dep,
            data=dataC,
            binary=binary))
        }
      }
    } else {
      outcome <- c(outcome,"&nbsp;")
    }
  }

  #
  # Perform multiple regression
  #
  form <- as.formula(paste(dep, "~",paste(indep,collapse="+")))

  fit <- do.call("glm", list(formula = form,family=binomial,data = dataC))
  ci <- suppressMessages(confint(fit)[-1,,drop=FALSE])
  co <- coef(fit)[-1]
  #
  # Perform likelihood ratio tests for the variables in the multiple regression
  # model instead of relying on Wald tests.
  #
  LRTp <- co <- ci <- NULL
  for (i in seq_len(nvar)) {
    x <- dataC[[indep[i]]]

    newfit <- update(fit,paste0(".~.-",indep[i]))

    if (is.factor(x)) {
      indepref <- paste0(indep[i],"Ref")
      values <- levels(x)
      lab <- paste0(indep[i],values)
      lab <- lab[lab %in% names(coef(fit))]
      LRTp <- c(LRTp,anova(fit,newfit,test="LRT")[2,"Pr(>Chi)"],rep(NA,length(values)))
      newco <- c(NA,0,coef(fit)[lab])
      names(newco)[1] <- indep[i]
      names(newco)[2] <- indepref
      co <- c(co,newco)
      newci <- rbind(c(NA,NA),c(NA,NA),suppressMessages(confint(fit)[lab,,drop=FALSE]))
      rownames(newci)[1] <- indep[i]
      rownames(newci)[2] <- indepref
      ci <- rbind(ci,newci)
    } else {
      LRTp <- c(LRTp,anova(fit,newfit,test="LRT")[2,"Pr(>Chi)"])
      co   <- c(co,coef(fit)[indep[i]])
      ci   <- rbind(ci,suppressMessages(confint(fit)[indep[i],,drop=FALSE]))
    }
  }

  df <- data.frame(
    vars=vars,
    variable=I(as.character(label)),
    faclevel=faclevel,
    facstart=facstart,
    outcome=I(outcome),
    uni_OR=exp(coIndiv),
    uni_lo=exp(ciIndiv[,"2.5 %"]),
    uni_hi=exp(ciIndiv[,"97.5 %"]),
    uni_p=LRTpIndiv,
    OR=exp(co),
    lo=exp(ci[,"2.5 %"]),
    hi=exp(ci[,"97.5 %"]),
    p=LRTp)

  smaller <- df
  smaller$vars <- NULL


  rownames(df) <- NULL

  list(ltab=df,tab=smaller,fit=fit,
       nrowOriginal=nrowOriginal,nrowComplete=nrow(dataC),
       events=sum(dataNMO[[dep]],na.rm=TRUE))
}



formatlrtab <- function(TAB) {
  fp <- function(p) {
    out <- rep("",length(p))
    out[!is.na(p)] <- formatp(p[!is.na(p)])
    out
  }

  subNA <- function(x) {
    x[!is.na(x) & x=="NA"] <- ""
    x
  }

  outcome <- TAB$outcome

  # Indent factor levels
  var <- as.character(TAB$variable)
  var[TAB$faclevel] <- paste0("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",var[TAB$faclevel])

  OR_Uni <- paste0(
    subNA(around(TAB$uni_OR,2))," (95% CI ",
    subNA(around(TAB$uni_lo,2)),", ",
    subNA(around(TAB$uni_hi,2)),")")
  OR_Uni[is.na(TAB$uni_OR)] <- ""
  OR_Uni[TAB$facstart] <- paste0(around(1.0,2)," (ref)")

  OR_Multi <- paste0(
    subNA(around(TAB$OR,2))," (95% CI ",
    subNA(around(TAB$lo,2)),", ",
    subNA(around(TAB$hi,2)),")")
  OR_Multi[is.na(TAB$OR)] <- ""
  OR_Multi[TAB$facstart] <- paste0(around(1.0,2)," (ref)")

  out <- cbind(
    "var"=ifelse(TAB$faclevel,var,paste0("**",var,"**")))

  out <- cbind(out,
    "Outcome n/N"=outcome,
    "OR_Uni"=OR_Uni,
    "pUni"=fp(TAB$uni_p),
    "OR"=OR_Multi,
    "p"=fp(TAB$p))

  out
}



#' @title Make a Markdown table from logistic regression model fit
#' @author Nick Barrowman
#' @description
#'
#' @param TAB           output from \code{lrtab}
#' @param showmulti     show multivariable model fit
#'
#' @return Markdown code for a table of logistic regression estimates
#'
#' @export
pipetablelrtab <- function(TAB, showmulti=TRUE) {
  tab <- formatlrtab(TAB)
  cols <- c(
        "&nbsp;"="var",
        "Univariable\\\nodds ratio"="OR_Uni",
        "p-value"="pUni",
        "Multivariable\\\nodds ratio"="OR",
        "95% low"="lo",
        "95% high"="hi",
        "p-value"="p")
  if (!showmulti) {
    tab <- tab[,!(colnames(tab) %in% c("OR","lo","hi","p"))]
  }
  paste0(
    pipetable(tab,
      columns=cols),
    "\n")
}








#
# helper function
#
nbtabvar <- function(dep,indep,offset=NULL,data) {
  offset_values <- eval(parse(text=offset),envir=data)

  #
  # Perform univariable tests
  #
  if (is.null(offset)) {
    formNull <- as.formula(paste(dep, "~1"))
  } else {
    formNull <- as.formula(paste(dep, "~1","+",offset))
  }
  fitNull <- do.call("glm.nb", list(formula = formNull,data = data))
  if (is.null(offset)) {
    formIndiv <- as.formula(paste(dep, "~",indep))
  } else {
    formIndiv <- as.formula(paste(dep, "~",indep,"+",offset))
  }
  fitIndiv <- do.call("glm.nb", list(formula = formIndiv,data = data))
  x <- data[[indep]]
  if (is.factor(x)) {

    values <- levels(x)

    n <- events <- exposure <- rep(NA,length(values)+1)
    i <- 1
    for (value in values) {
      i <- i+1
      select <- x %in% value
      n[i] <- sum(select,na.rm=TRUE)
      events[i] <- sum(data[[dep]][select],na.rm=TRUE)
      exposure[i] <- sum(exp(offset_values[select]),na.rm=TRUE)
    }

    indepref <- paste0(indep,values[1])
    lab <- paste0(indep,values)
    #values <- values[lab %in% names(coef(fitIndiv))]

    #label <- c(indep,"Ref",values)
    label <- c(indep,values)
    LRTpIndiv <- c(anova(fitIndiv,fitNull)[2,"Pr(Chi)"],rep(NA,length(coef(fitIndiv))))
    coIndiv <- c(NA,0,coef(fitIndiv)[-1])
    names(coIndiv)[1] <- indep
    names(coIndiv)[2] <- indepref
    ciIndiv <- rbind(c(NA,NA),c(NA,NA),suppressMessages(confint(fitIndiv)[-1,,drop=FALSE]))
    rownames(ciIndiv)[1] <- indep
    rownames(ciIndiv)[2] <- indepref
    faclevel <- c(FALSE,rep(TRUE,length(coef(fitIndiv))))
    facstart <- c(FALSE,TRUE,rep(FALSE,length(coef(fitIndiv))-1))
  } else {
    n <- sum(!is.na(x))
    events <- sum(data[[dep]],na.rm=TRUE)
    exposure <- sum(exp(offset_values),na.rm=TRUE)
    label <- indep
    LRTpIndiv <- anova(fitIndiv,fitNull)[2,"Pr(Chi)"]
    coIndiv <- coef(fitIndiv)[-1]
    ciIndiv <- suppressMessages(confint(fitIndiv)[-1,,drop=FALSE])
    faclevel <- FALSE
    facstart <- FALSE
  }
  list(label=label,faclevel=faclevel,facstart=facstart,n=n,events=events,
    exposure=exposure,p=LRTpIndiv,co=coIndiv,ci=ciIndiv)
}


#' @title [n]egative [b]inomial [tab]le version [2]
#' @author Nick Barrowman
#' @description
#'
#' @param dep           name of dependent (outcome) variable
#' @param indep         names of independent (explanatory) variables
#' @param offsetstring  character string representing offset
#' @param data          data frame
#' @param binary        vector of two names for logical variables (instead of TRUE, FALSE)
#'
#' @return  a list with elements \code{ltab}, \code{tab}, and \code{fit}
#'
#' @export
nbtab2 <- function(dep,indep,offsetString=NULL,data,binary = c("no","yes")) {

  nrowOriginal <- nrow(data)

  dataNMO <- data[!is.na(data[[dep]]), ]

  for (xname in indep) {
    x <- dataNMO[[xname]]
    if (is.logical(x))
      x <- factor(as.numeric(x), levels = c(0, 1), labels = binary)
    if (all(x[!is.na(x)] == 0 | x[!is.na(x)] == 1))
      x <- factor(as.numeric(x), levels = c(0, 1), labels = binary)
    dataNMO[[xname]] <- x
  }
  notmissing <- rep(TRUE, nrow(dataNMO))
  for (xname in indep) {
      notmissing <- notmissing & !is.na(dataNMO[[xname]])
  }
  notmissing <- notmissing & !is.na(dataNMO[[dep]])
  dataC <- dataNMO[notmissing, ]
  message(paste("nbtab2: original data object had",
      nrowOriginal, "rows."))
  message(paste("nbtab2: complete data object has",
      nrow(dataC), "rows."))

  nvar <- length(indep)
  offset <- paste0("offset(",offsetString,")")

  #
  # Perform univariable tetss
  #
  LRTpIndiv <- coIndiv <- ciIndiv <- label <- faclevel <-
    facstart <- vars <- n <- events <- exposure <- NULL
  for (i in seq_len(nvar)) {
    out <- nbtabvar(dep,indep[i],offset=offset,data=dataC)
    LRTpIndiv <- c(LRTpIndiv,out$p)
    coIndiv <- c(coIndiv,out$co)
    ciIndiv <- rbind(ciIndiv,out$ci)
    label <- c(label,out$label)
    faclevel <- c(faclevel,out$faclevel)
    facstart <- c(facstart,out$facstart)
    n <- c(n,out$n)
    events <- c(events,out$events)
    exposure <- c(exposure,out$exposure)
    vars <- c(vars,rep(indep[i],length(out$label)))
  }

  #
  # Perform multiple regression
  #
  if (is.null(offsetString)) {
    form <- as.formula(paste(dep, "~",paste(indep,collapse="+")))
  } else {
    form <- as.formula(paste(dep, "~",paste(indep,collapse="+"),"+",offset))
  }
  fit <- do.call("glm.nb", list(formula = form,data = dataC))
  ci <- suppressMessages(confint(fit)[-1,,drop=FALSE])
  co <- coef(fit)[-1]
  #
  # Perform likelihood ratio tests for the variables in the multiple regression
  # model instead of relying on Wald tests.
  #
  LRTp <- co <- ci <- NULL
  for (i in seq_len(nvar)) {
    x <- dataC[[indep[i]]]

    newfit <- update(fit,paste0(".~.-",indep[i]))

    if (is.factor(x)) {
      indepref <- paste0(indep[i],"Ref")
      values <- levels(x)
      lab <- paste0(indep[i],values)
      lab <- lab[lab %in% names(coef(fit))]
      LRTp <- c(LRTp,anova(fit,newfit)[2,"Pr(Chi)"],rep(NA,length(values)))
      newco <- c(NA,0,coef(fit)[lab])
      names(newco)[1] <- indep[i]
      names(newco)[2] <- indepref
      co <- c(co,newco)
      newci <- rbind(c(NA,NA),c(NA,NA),suppressMessages(confint(fit)[lab,,drop=FALSE]))
      rownames(newci)[1] <- indep[i]
      rownames(newci)[2] <- indepref
      ci <- rbind(ci,newci)
    } else {
      LRTp <- c(LRTp,anova(fit,newfit)[2,"Pr(Chi)"])
      co   <- c(co,coef(fit)[indep[i]])
      ci   <- rbind(ci,suppressMessages(confint(fit)[indep[i],,drop=FALSE]))
    }
  }

  df <- data.frame(
    vars=vars,
    variable=I(as.character(label)),
    faclevel=faclevel,
    facstart=facstart,
    n=n,
    events=events,
    exposure=exposure,
    uni_rate=exp(coIndiv),
    uni_lo=exp(ciIndiv[,"2.5 %"]),
    uni_hi=exp(ciIndiv[,"97.5 %"]),
    uni_p=LRTpIndiv,
    rate=exp(co),
    lo=exp(ci[,"2.5 %"]),
    hi=exp(ci[,"97.5 %"]),
    p=LRTp)

  smaller <- df
  smaller$vars <- NULL


  rownames(df) <- NULL

  list(ltab=df,tab=smaller,fit=fit)
}





formatnbtab <- function(TAB,showmulti=TRUE) {
  fp <- function(p) {
    out <- rep("",length(p))
    out[!is.na(p)] <- formatp(p[!is.na(p)])
    out
  }

  subNA <- function(x) {
    x[!is.na(x) & x=="NA"] <- ""
    x
  }

  # Indent factor levels
  var <- as.character(TAB$variable)
  var[TAB$faclevel] <- paste0("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",var[TAB$faclevel])

  rateUni <- paste0(
    subNA(around(TAB$uni_rate,2))," (95% CI ",
    subNA(around(TAB$uni_lo,2)),", ",
    subNA(around(TAB$uni_hi,2)),")")
  rateUni[is.na(TAB$uni_rate)] <- ""
  rateUni[TAB$facstart] <- paste0(around(1.0,2)," (ref)")

  rateMulti <- paste0(
    subNA(around(TAB$rate,2))," (95% CI ",
    subNA(around(TAB$lo,2)),", ",
    subNA(around(TAB$hi,2)),")")
  rateMulti[is.na(TAB$rate)] <- ""
  rateMulti[TAB$facstart] <- paste0(around(1.0,2)," (ref)")

  round_exposure <- around(TAB$exposure,0)
  round_exposure[round_exposure=="NA"] <- "&nbsp;"

  out <- cbind(
    "var"=var,
    "n"=TAB$n,
    "events"=TAB$events,
    "exposure"=round_exposure,
    "rateUni"=rateUni,
    "pUni"=fp(TAB$uni_p),
    "rate"=rateMulti,
    "p"=fp(TAB$p))

  out
}



#' @title Make a Markdown table from negative binomial model fit
#' @author Nick Barrowman
#' @description
#'
#' @param TAB           output from \code{nbtab2}
#' @param exposureName  name of exposure
#' @param shown         show n (sample size)
#' @param showevents    show events
#' @param showexposure  show exposure
#' @param showmulti     show multivariable model fit
#'
#' @return Markdown code for a table of negative binomial estimates
#'
#' @export
pipetablenbtab <- function(TAB,exposureName="exposure",shown=TRUE,showevents=TRUE,
  showexposure=TRUE, showmulti=TRUE) {

  tab <- formatnbtab(TAB)
  if (!shown) tab <- tab[,!(colnames(tab) %in% "n")]
  if (!showevents) tab <- tab[,!(colnames(tab) %in% "events")]
  if (!showexposure) tab <- tab[,!(colnames(tab) %in% "exposure")]
  cols <- c(
    "&nbsp;"="var",
    "n"="n",
    "events"="events",
    "exposure"="exposure",
    "Univariable\\\nrate ratio"="rateUni",
    "p-value"="pUni",
    "Multivariable\\\nrate ratio"="rate",
    "95% low"="lo",
    "95% high"="hi",
    "p-value"="p")
  names(cols)[names(cols)=="exposure"] <- exposureName
  if (!showmulti) {
    tab <- tab[,!(colnames(tab) %in% c("rate","lo","hi","p"))]
  }
  paste0(
    pipetable(tab,columns=cols),
    "\nRate ratios represent estimated ratio of events/year between groups.\n")

}





#'
#' @title [uni]variate [log]istic regression with [f]irth correction
#' @author Nick Barrowman
#' @description
#' Run a [uni]variate [log]istic regression analysis
#' @param xname   name of predictor variable
#' @param yname   name of y variable
#' @param df      dataframe
#' @param binary  re-label logical or binary vectors into 'no' and 'yes' for clarity
#'
#' @return univariate regression model
#'
#'
#' @export
#'
#'
#'
unilogf <- function(xname,yname,df,binary=c("no","yes")) {

  x <- df[[xname]]

  if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
  if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)

  df[[xname]] <- x

  formula <- as.formula(paste(yname,"~",xname))

  fit <- logistf(formula,family=binomial,data=df,subset=!is.na(df[[xname]]))

  ci <- suppressMessages(confint(fit))

  eci <- exp(ci)
  tab <- cbind(exp(coef(fit)),eci)
  colnames(tab) <- c("OR","95%lo","95%hi")

  list(fit=fit,ORtable=tab,p=fit$prob[2])
}

#' @title [m]ultivariate [O]dds [R]atio [table] with [f]irth correction
#' @author Nick Barrowman
#' @description
#' \code{mORtable3} Generates a table with N(\%), number of missing values,
#' OR(lower CI, upper CI), and p-values from univariable logistic regression,
#' and OR(lower CI, upper CI), and p-values from a multivariate logistic regression
#' (which includes all variables with p-value < \code{pcutoff}).
#' Each univariable logistic regression uses all available data.
#' The multivariable logistic regression model uses complete cases.
#' A sample size summary is provided below the table.
#' Note that the column of N(\%) excludes cases where the outcome variable is missing.
#' @details xnames preceded by a star will be forced into the multivariate model
#' @param xnames  vector of names of potential predictors
#' @param yname   name of outcome variable
#' @param pcutoff p-value threshold for inclusion of predictor in the multivariate model
#' @param data    data frame
#' @param binary  vector of two names for logical variables (instead of TRUE, FALSE)
#' @param xorder  named list of display order of levels for corresponding predictor variables
#' @param xlabels named list of labels for corresponding predictor variables
#' @param outcome name of the outcome variable to display in the column header
#' @param showmiss show the column of missing values?
#'
#' @return  a Markdown pipetable table with N(\%), OR(lower CI, upper CI), and p-values
#'
#' @examples
#' # All of the following code should be called inline.
#'
#' # A basic call to mORtable3:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",data=wide)
#'
#' # Also specify the cutoff:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",0.1,data=wide)
#'
#' # Also specify that values of the AHICat variable should listed in order 1, 3, 2:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)))
#'
#' # Also specify nicer labels for the AHICat, LowO2Cat, and HighCO2Cat variables:
#' mORtable3(c("AHICat","LowO2Cat","HighCO2Cat"),"anycompAnywhere",
#'   0.1,wide,xorder=list(AHICat=c(1,3,2)),
#'   xlabels=list(AHICat="AHI",LowO2Cat="Lowest O~2~ saturation",HighCO2Cat="Highest CO~2~"))
#'
#' @export

mORtablef <- function(xnames,yname,pcutoff,data,binary=c("no","yes"),xorder=list(),xlabels=list(),outcome="Outcome",showmiss=TRUE) {

  nrowOriginal <- nrow(data)
  SampleSizeNotMissingOutcome <- sum(!is.na(data[[yname]]))

  dataNMO <- data[!is.na(data[[yname]]),]  # data Not Missing Outcome

  forced <- grep("^\\*",xnames) # variables preceded by a * are forced into the multivariate model

  xnames <- gsub("^\\*(.+)","\\1",xnames)  # strip of any leading stars

 # message("mORtable3 ---- Start ---------")
 # message(paste("mORtable3: xnames =",paste(xnames,collapse=","),"  yname=",yname))

 # message("mORtable3: make factors")

  # Convert the appropriate predictor variables into factors
  for (xname in xnames) {
    x <- dataNMO[[xname]]
    if (is.logical(x)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    if (all(x[!is.na(x)]==0 | x[!is.na(x)]==1)) x <- factor(as.numeric(x),levels=c(0,1),labels=binary)
    dataNMO[[xname]] <- x
  }

  # Identify complete cases across all predictor variables
  notmissing <- rep(TRUE,nrow(dataNMO))
  for (xname in xnames) {
    notmissing <- notmissing & !is.na(dataNMO[[xname]])
  }

  # Identify complete cases for the outcome variable
  notmissing <- notmissing & !is.na(dataNMO[[yname]])

  # Select complete cases
  dataC <- dataNMO[notmissing,]

  message(paste("mORtable3: original data object had",nrowOriginal,"rows."))
  message(paste("mORtable3: complete data object has",nrow(dataC),"rows."))

  message("mORtable3: figure out which variables to use in multivariate model")

  include <- rep(TRUE,length(xnames))
  names(include) <- xnames
  univariate <- vector("list",length(xnames))
  names(univariate) <- xnames
  i <- 0
  for (xname in xnames) {
    i <- i + 1
    univariate[[i]] <- unilogf(xname,yname,dataNMO)
    include[i] <- univariate[[i]]$p<pcutoff
  }
  include[forced] <- TRUE

  xnamesMulti <- xnames[include]

  if (length(xnamesMulti)==0) {
    formula <- as.formula(paste(yname,"~ 1"))
  } else {
    formula <- as.formula(paste(yname,"~",paste(xnamesMulti,collapse="+")))
  }

  message("mORtable3: Run multivariate model")
  message(paste0("nrow(dataC)=",nrow(dataC)))

  fit <- logistf(formula=formula,data=dataC)

  if (showmiss) {
    f <- list(nmissf,pctf,uorf,upvf,morf,mpvff)
    header <- c("Variable","Missing",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value","Adjusted OR (95% CI)","p-value")
  } else {
    f <- list(pctf,uorf,upvf,morf,mpvf)
    header <- c("Variable",paste(outcome,"n/N"),"Unadjusted OR (95% CI)","p-value","Adjusted OR (95% CI)","p-value")
  }

  out <- pipetableheader(header,bold=TRUE)
  out <- paste0(out,"\n")

  for (xname in xnames) {
    heading <- xname
    if (xname %in% names(xlabels)) {
      heading <- xlabels[[xname]]
    }

    out <- paste(out,markdownTable(
      VarRows(xname,yname,heading=heading,data=dataNMO,xorder=xorder,
              f=f,
              ufit=univariate[[xname]],mfit=fit,minclude=include[xname])))
  }

  paste0(out,
    paste0(
      "**Sample size** ",
      "Total: ",nrowOriginal,",&nbsp;&nbsp;",
      "Excluding missing values in the outcome: ",SampleSizeNotMissingOutcome,",&nbsp;&nbsp;",
      "Multivariable analysis: ",sum(notmissing),",&nbsp;&nbsp;",
      "**Events**: ",sum(dataNMO[[yname]],na.rm=TRUE),",&nbsp;&nbsp;",
      "**p-value cutoff**: ",pcutoff))
}





#' @title [n] [miss]ing [f]unction
#'
#' @description Helper function: show number of missing values for a predictor variable
#'
#' @export
#'

nmissf <- function(xname,lab,index,yname,data,xorder=list(),binary=c("no","yes"),...) {

  # message(paste("pctf: xname =",xname,"  yname =",yname))

  x <- data[[xname]]
  y <- data[[yname]]

  if (index==0 | !is.factor(x)) {
    sum(is.na(x))
  } else {
    ""
  }
}


#' @title Escape symbols and other special characters to use in pandoc Markdown.
#' @param newlineSubstitute Character string to substitute for newlines.
#'
#' @export
#'
escapeSymbols <- function(x,newlineSubstitute=" ") {
  gsub("\\$","\\\\$",x)
  gsub("\\*","&ast;",x)
  gsub("\n",newlineSubstitute,x)

}




#
# helper function
#
lmtabvar <- function(dep,indep,data,digits=2) {

  #
  # Perform univariable tests
  #
  formNull <- as.formula(paste(dep, "~1"))

  fitNull <- do.call("lm", list(formula = formNull,data = data))

  formIndiv <- as.formula(paste(dep, "~",indep))

  fitIndiv <- do.call("lm", list(formula = formIndiv,data = data))
  x <- data[[indep]]
  if (is.factor(x)) {

    values <- levels(x)

    n <- rep(NA,length(values)+1)
    meansd <- rep("",length(values)+1)
    i <- 1
    for (value in values) {
      i <- i+1
      select <- x %in% value
      n[i] <- sum(select,na.rm=TRUE)
      meansd[i] <- meanSD(data[[dep]][select],digits = digits)
    }

    indepref <- paste0(indep,values[1])
    lab <- paste0(indep,values)
    #values <- values[lab %in% names(coef(fitIndiv))]

    #label <- c(indep,"Ref",values)
    label <- c(indep,values)
    LRTpIndiv <- c(anova(fitIndiv,fitNull)[2,"Pr(>F)"],rep(NA,length(coef(fitIndiv))))
    coIndiv <- c(NA,0,coef(fitIndiv)[-1])
    names(coIndiv)[1] <- indep
    names(coIndiv)[2] <- indepref
    ciIndiv <- rbind(c(NA,NA),c(NA,NA),suppressMessages(confint(fitIndiv)[-1,,drop=FALSE]))
    rownames(ciIndiv)[1] <- indep
    rownames(ciIndiv)[2] <- indepref
    faclevel <- c(FALSE,rep(TRUE,length(coef(fitIndiv))))
    facstart <- c(FALSE,TRUE,rep(FALSE,length(coef(fitIndiv))-1))
  } else {
    n <- sum(!is.na(x))
    label <- indep
    LRTpIndiv <- anova(fitIndiv,fitNull)[2,"Pr(>F)"]
    coIndiv <- coef(fitIndiv)[-1]
    ciIndiv <- suppressMessages(confint(fitIndiv)[-1,,drop=FALSE])
    faclevel <- FALSE
    facstart <- FALSE
    meansd <- ""
  }

  list(label=label,faclevel=faclevel,facstart=facstart,n=n,meansd=meansd,
    p=LRTpIndiv,co=coIndiv,ci=ciIndiv)
}


#' @title [l]inear [m]odel [tab]le
#' @author Nick Barrowman
#' @description
#'
#' @param dep           name of dependent (outcome) variable
#' @param indep         names of independent (explanatory) variables
#' @param data          data frame
#' @param binary        vector of two names for logical variables (instead of TRUE, FALSE)
#' @param digits        number of digits to show
#' @param log           Should the dependent variable be log transformed?
#'
#' @return  a list with elements \code{ltab}, \code{tab}, and \code{fit}
#'
#' @export
lmtab <- function(dep,indep,data,binary = c("no","yes"),digits=2,log=FALSE) {

  if (log) {
    depnew <- paste0("log",dep)
    data[[depnew]] <- log(data[[dep]])
    dep <- depnew
  }

  nrowOriginal <- nrow(data)

  dataNMO <- data[!is.na(data[[dep]]), ]

  for (xname in indep) {
    x <- dataNMO[[xname]]
    if (is.logical(x))
      x <- factor(as.numeric(x), levels = c(0, 1), labels = binary)
    if (all(x[!is.na(x)] == 0 | x[!is.na(x)] == 1))
      x <- factor(as.numeric(x), levels = c(0, 1), labels = binary)
    dataNMO[[xname]] <- x
  }
  notmissing <- rep(TRUE, nrow(dataNMO))
  for (xname in indep) {
      notmissing <- notmissing & !is.na(dataNMO[[xname]])
  }
  notmissing <- notmissing & !is.na(dataNMO[[dep]])
  dataC <- dataNMO[notmissing, ]
  message(paste("lmtab: original data object had",
      nrowOriginal, "rows."))
  message(paste("lmtab: complete data object has",
      nrow(dataC), "rows."))


  nvar <- length(indep)

  #
  # Perform univariable tetss
  #
  LRTpIndiv <- coIndiv <- ciIndiv <- label <- faclevel <- meansd <-
    facstart <- vars <- n <- NULL


  for (i in seq_len(nvar)) {

    out <- lmtabvar(dep,indep[i],data=dataC)
    LRTpIndiv <- c(LRTpIndiv,out$p)

    meansd <- c(meansd,out$meansd)
    coIndiv <- c(coIndiv,out$co)
    ciIndiv <- rbind(ciIndiv,out$ci)
    label <- c(label,out$label)
    faclevel <- c(faclevel,out$faclevel)
    facstart <- c(facstart,out$facstart)
    n <- c(n,out$n)
    vars <- c(vars,rep(indep[i],length(out$label)))
  }

  #
  # Perform multiple regression
  #
  form <- as.formula(paste(dep, "~",paste(indep,collapse="+")))

  fit <- do.call("lm", list(formula = form,data = dataC))
  ci <- suppressMessages(confint(fit)[-1,,drop=FALSE])
  co <- coef(fit)[-1]
  #
  # Perform likelihood ratio tests for the variables in the multiple regression
  # model instead of relying on Wald tests.
  #
  LRTp <- co <- ci <- NULL
  for (i in seq_len(nvar)) {
    x <- dataC[[indep[i]]]

    newfit <- update(fit,paste0(".~.-",indep[i]))

    if (is.factor(x)) {
      indepref <- paste0(indep[i],"Ref")
      values <- levels(x)
      lab <- paste0(indep[i],values)
      lab <- lab[lab %in% names(coef(fit))]
      LRTp <- c(LRTp,anova(fit,newfit)[2,"Pr(>F)"],rep(NA,length(values)))
      newco <- c(NA,0,coef(fit)[lab])
      names(newco)[1] <- indep[i]
      names(newco)[2] <- indepref
      co <- c(co,newco)
      newci <- rbind(c(NA,NA),c(NA,NA),suppressMessages(confint(fit)[lab,,drop=FALSE]))
      rownames(newci)[1] <- indep[i]
      rownames(newci)[2] <- indepref
      ci <- rbind(ci,newci)
    } else {
      LRTp <- c(LRTp,anova(fit,newfit)[2,"Pr(>F)"])
      co   <- c(co,coef(fit)[indep[i]])
      ci   <- rbind(ci,suppressMessages(confint(fit)[indep[i],,drop=FALSE]))
    }
  }

  # browser()
  df <- data.frame(
    vars=vars,
    variable=I(as.character(label)),
    faclevel=faclevel,
    facstart=facstart,
    n=n,
    meansd=meansd,
    uni_est=coIndiv,
    uni_lo=ciIndiv[,"2.5 %"],
    uni_hi=ciIndiv[,"97.5 %"],
    uni_p=LRTpIndiv,
    est=co,
    lo=ci[,"2.5 %"],
    hi=ci[,"97.5 %"],
    p=LRTp)

  smaller <- df
  smaller$vars <- NULL


  rownames(df) <- NULL

  list(ltab=df,tab=smaller,fit=fit,log=log)
}





formatlmtab <- function(modelout,showmulti=TRUE) {
  fp <- function(p) {
    out <- rep("",length(p))
    out[!is.na(p)] <- formatp(p[!is.na(p)])
    out
  }

  subNA <- function(x) {
    x[!is.na(x) & x=="NA"] <- ""
    x
  }

  TAB <- modelout$tab

  # Indent factor levels
  var <- as.character(TAB$variable)
  var[TAB$faclevel] <- paste0("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",var[TAB$faclevel])

  est <- TAB$uni_est
  lo  <- TAB$uni_lo
  hi  <- TAB$uni_hi

  if (modelout$log) {
    est <- exp(est)
    lo  <- exp(lo)
    hi  <- exp(hi)
  }

  estUni <- paste0(
    subNA(around(est,2))," (95% CI ",
    subNA(around(lo,2)),", ",
    subNA(around(hi,2)),")")
  estUni[is.na(est)] <- ""
  estUni[TAB$facstart] <- paste0(around(1.0,2)," (ref)")

  est <- TAB$est
  lo  <- TAB$lo
  hi  <- TAB$hi

  if (modelout$log) {
    est <- exp(est)
    lo  <- exp(lo)
    hi  <- exp(hi)
  }

  estMulti <- paste0(
    subNA(around(est,2))," (95% CI ",
    subNA(around(lo,2)),", ",
    subNA(around(hi,2)),")")
  estMulti[is.na(est)] <- ""
  estMulti[TAB$facstart] <- paste0(around(1.0,2)," (ref)")

  out <- cbind(
    "var"=ifelse(TAB$faclevel,var,paste0("**",var,"**")),
    "n"=TAB$n)

  if (!modelout$log) {
    out <- cbind(out,"mean (SD)"=TAB$meansd)
  }

  out <- cbind(out,
    "estUni"=estUni,
    "pUni"=fp(TAB$uni_p),
    "est"=estMulti,
    "p"=fp(TAB$p))

  out
}



#' @title Make a Markdown table from linear regression model fit
#' @author Nick Barrowman
#' @description
#'
#' @param modelout      output from \code{lmtab}
#' @param exposureName  name of exposure
#' @param shown         show n (sample size)
#' @param showmulti     show multivariable model fit
#'
#' @return Markdown code for a table of negative binomial estimates
#'
#' @export
pipetablelmtab <- function(modelout,shown=TRUE, showmulti=TRUE) {

  tab <- formatlmtab(modelout)
  if (!shown) tab <- tab[,!(colnames(tab) %in% "n")]
  cols <- c(
    "&nbsp;"="var",
    "n"="n",
    "Univariable"="estUni",
    "p-value"="pUni",
    "Multivariable"="est",
    "95% low"="lo",
    "95% high"="hi",
    "p-value"="p")
  if (!showmulti) {
    tab <- tab[,!(colnames(tab) %in% c("est","lo","hi","p"))]
  }
  #paste0(
  #  pipetable(tab,columns=cols),
  #  "\nNotes.\n")
  pipetable(tab,columns=cols)
}

