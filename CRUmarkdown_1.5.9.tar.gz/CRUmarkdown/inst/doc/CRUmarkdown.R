## ---- echo=FALSE--------------------------------------------------------------
library(CRUmarkdown)
#source("R:/CRU Epibiostat/projects/Nick/CRUmarkdown [svn]/CRUmarkdown/source.R")

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  ```{r}
#  NiceLookingPvalue <- formatp(pval)
#  ```

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetable(FakeData)`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  ```{r,results="asis"}
#  cat(pipetable(head(FakeData)))
#  ```

## ----results="asis",echo=FALSE------------------------------------------------
cat(pipetable(head(FakeData)))

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  Variable             | Value
#  ---------------------|------
#  sex                  |
#  male                 |  32
#  female               |  52

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  Variable             | Value
#  ---------------------|------
#  sex                  |
#  `r spaces(5)`male    |  32
#  `r spaces(5)`female  |  52

## -----------------------------------------------------------------------------
round(5.102,digits=2)
around(5.102,digits=2)
round(5.10,digits=2)
around(5.10,digits=2)
round(5,digits=2)
around(5,digits=2)

## -----------------------------------------------------------------------------
formatp(0.2345)
formatp(0.0234)
formatp(0.0023)
formatp(0.0002)

## -----------------------------------------------------------------------------
meanSD(FakeData$Age)

## -----------------------------------------------------------------------------
meanSD(FakeData$Age,plusminus=TRUE)

## -----------------------------------------------------------------------------
meanSD(FakeData$Age,range=TRUE)

## -----------------------------------------------------------------------------
meanSD(FakeData$Age,plusminus=TRUE,range=TRUE,rangeFormat=2)

## -----------------------------------------------------------------------------
meanSDp(FakeData$Age)

## -----------------------------------------------------------------------------
medianIQR(FakeData$Age)

## -----------------------------------------------------------------------------
rangefun(FakeData$Age)

## ---- echo=TRUE---------------------------------------------------------------
npct(FakeData$Age)

## ---- echo=TRUE---------------------------------------------------------------
npct(FakeData$Age==5)["TRUE"]

## ---- echo=TRUE---------------------------------------------------------------
npct(FakeData$Age==100)["TRUE"]

## ---- echo=TRUE---------------------------------------------------------------
npct(FakeData$Age)["100"]

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r npct(FakeData$Age==5)["TRUE"]`

## ---- echo=TRUE---------------------------------------------------------------
npct(FakeData$Age,nmiss=TRUE)

## ---- echo=TRUE---------------------------------------------------------------
npct(FakeData$Age,nmiss=TRUE)["5"]

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r npct(FakeData$Age,nmiss=TRUE)["5"]`

## ---- echo=TRUE---------------------------------------------------------------
npct(FakeData$Age,vp=FALSE,nmiss=TRUE)

## -----------------------------------------------------------------------------
npct(FakeData$Severity,includemiss=TRUE)

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetable(npct(FakeData$Severity,includemiss=TRUE))`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetable(subset(FakeData,FakeData$Severity=="Mild"))`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetable(FakeData[sample(1:nrow(FakeData),5),],
#    columns=c("How bad is it?"="Severity"))`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetable(FakeData[sample(1:nrow(FakeData),5),],
#    columns=c("How bad\\\nis it?"="Severity"))`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetable(FakeData[sample(1:nrow(FakeData),5),],
#    columns=c("How bad\\\nis it?"="Severity","Type"="Group"))`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetablerow(FakeData$Age,FakeData$Sex)`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetablerow(FakeData$Age,FakeData$Sex,
#     rowvarname="Age of patient",colvarname="Gender")`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetablerow(FakeData$Age)`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetablerow(FakeData$Age,varname="Patient age")`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetablecol(FakeData$Age,FakeData$Sex)`

## -----------------------------------------------------------------------------
fit <- lm(Age~Severity+Sex,data=FakeData)

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetablelmCoef(fit)`

## -----------------------------------------------------------------------------
fit <- glm(Sex~Age+Severity,family=binomial,data=FakeData)

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetablelogistic(fit)`

## -----------------------------------------------------------------------------
fit <- glm(Sex~Age+Severity,family=binomial,data=FakeData)
orci(fit)

## ---- eval=FALSE--------------------------------------------------------------
#  
#  # ## Function: mORtable (inline function)
#  #
#  # A more sophisticated way to show estimates from a logistic regression is `mORtable`. It does the following:
#  #
#  # 1. runs univariable logistic regressions
#  #
#  # 2. selects predictors significant at a specified p-value cutoff `pcutoff`
#  #
#  # 3. runs a multivariable logistic regression using the selected variables
#  #
#  # **Note that (currently) mORtable does not produce the table header, so that needs to be supplied before calling `mORtable`.**
#  #
#  # Use the following command in R Markdown text:
#  #
#  # ```{r, highlight=FALSE, eval=FALSE}
#  # **Variable** | Missing | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value** | **Adjusted OR (95% CI)** | **p-value**
#  # -------------|---------|---------|-------------|---------|-------------|----------
#  # `r mORtable(c("Age","Severity"),"Male",pcutoff=1,data=FakeData)`
#  # ```
#  #
#  # **Variable** | Missing | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value** | **Adjusted OR (95% CI)** | **p-value**
#  # -------------|---------|---------|-------------|---------|-------------|----------
#  # `r mORtable(c("Age","Severity"),"Male",pcutoff=1,data=FakeData)`
#  #
#  # Age and Severity are fairly self explanatory, but we may wish to specify labels instead of the variable names. For example, in place of Age we may wish to display *Age (years)* and in place of Severity, *Severity classification*. This can be specified by supplying the `xlabels` argument, which should be a list whose elements have names specifying the variables and whose values are the new labels. (You can specify these in any order, and you can choose to only relabel some of the variables.)
#  #
#  # ```{r, highlight=FALSE, eval=FALSE}
#  # **Variable** | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value** | **Adjusted OR (95% CI)** | **p-value**
#  # ------------|-------------------|-------------|---------|-------------|----------
#  # `r mORtable(c("Age","Severity"),"Male",pcutoff=1,data=FakeData,xlabels=list(Age="Age (years)",Severity="Severity classification"))`
#  # ```
#  #
#  # **Variable** | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value** | **Adjusted OR (95% CI)** | **p-value**
#  # ------------|-------------------|-------------|---------|-------------|----------
#  # `r mORtable(c("Age","Severity"),"Male",pcutoff=1,data=FakeData,xlabels=list(Age="Age (years)",Severity="Severity classification"))`

## ---- eval=FALSE--------------------------------------------------------------
#  # ## Function: uORtable (inline function)
#  #
#  # If you only want results from univariable logistic regressions, the `uORtable` function can be used.
#  #
#  # Use the following command in R Markdown text:
#  #
#  # ```{r, highlight=FALSE, eval=FALSE}
#  # **Variable** | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value**
#  # ------------|-------------------|-------------|---------
#  # `r uORtable(c("Age","Severity"),"Male",data=FakeData)`
#  # ```
#  #
#  # **Variable** | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value**
#  # ------------|-------------------|-------------|---------
#  # `r uORtable(c("Age","Severity"),"Male",data=FakeData)`

## ---- eval=FALSE--------------------------------------------------------------
#  # ## Function: mlmtable
#  #
#  # The `mlmtable` is like `mORtable` but for linear models rather than logistic regression. In the example below, the response variable is `Age` and the predictor variables are `Sex`, `Severity`, and `Group`. Specifying `pcutoff=1.1` means that all variables will be entered into the multiple regression model, regardless of their significance. (Commonly we might want to specify `pcutoff=0.1` so that variables with marginal statistical significance in the unadjusted model will still make it into the multiple regression model.)
#  #
#  #
#  # ```{r, highlight=FALSE, eval=FALSE}
#  # **Variable** | **Mean (SD)** | **Unadjusted coefficient (95% CI)** | **p-value** |  **Adjusted coefficient (95% CI)** | **p-value** |
#  # ------------|-------------------|-------------------|-------------------|-------------------|-------------------|
#  # `r mlmtable(c("Sex","Severity","Group"),"Age",data=FakeData,pcutoff=1.1)`
#  # ```
#  #
#  # **Variable** | **Mean (SD)** | **Unadjusted coefficient (95% CI)** | **p-value** |  **Adjusted coefficient (95% CI)** | **p-value** |
#  # ------------|-------------------|-------------------|-------------------|-------------------|-------------------|
#  # `r mlmtable(c("Sex","Severity","Group"),"Age",data=FakeData,pcutoff=1.1)`
#  #
#  # ### Customizing columns
#  #
#  # Simpler tables can be created using the `f` parameter. For example if we only want to see the sample size, median (IQR), and mean (SD), we could use the following code:
#  #
#  # ```{r, highlight=FALSE, eval=FALSE}
#  # **Variable** | n | **Median (IQR)** | **Mean (SD)** |
#  # -------------|---|------------------|---------------|
#  # `r mlmtable(c("Sex","Severity","Group"),"Age",data=FakeData,pcutoff=1.1,f=list(nf,medianIQRf,meanSDf))`
#  # ```
#  #
#  # **Variable** | n | **Median (IQR)** | **Mean (SD)** |
#  # -------------|---|------------------|---------------|
#  # `r mlmtable(c("Sex","Severity","Group"),"Age",data=FakeData,pcutoff=1.1,f=list(nf,medianIQRf,meanSDf))`
#  #
#  #
#  # ### Binary predictor variables
#  #
#  # The example below uses the numeric variable `Male` (1=Male, 0=Female) instead of the factor variable `Sex`. Note that `mlmtable` recognizes `Male` as an indicator variable, and replaces 0 with *no* and 1 with *yes*. (This is specified using the parameter `binary` whose default is `binary=c("no","yes")`.)
#  #
#  # You can specify alternative labels using
#  #
#  # ```{r, highlight=FALSE, eval=FALSE}
#  # **Variable** | **Mean (SD)** | **Unadjusted coefficient (95% CI)** | **p-value** |  **Adjusted coefficient (95% CI)** | **p-value** |
#  # ------------|-------------------|-------------------|-------------------|-------------------|-------------------|
#  # `r mlmtable(c("Male","Severity","Group"),"Age",data=FakeData,pcutoff=1.1)`
#  # ```
#  #
#  # **Variable** | **Mean (SD)** | **Unadjusted coefficient (95% CI)** | **p-value** |  **Adjusted coefficient (95% CI)** | **p-value** |
#  # ------------|-------------------|-------------------|-------------------|-------------------|-------------------|
#  # `r mlmtable(c("Male","Severity","Group"),"Age",data=FakeData,pcutoff=1.1)`
#  

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("One","Two","Three"))`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("Variable","mean (SD)","range"))`
#  `r tablerow("Age (years)",meanSD(FakeData$Age),rangefun(FakeData$Age))`

## -----------------------------------------------------------------------------
tab <- pbind(
  pipetableheader(c("Variable","mean (SD)","range")),
  tablerow("Age (years)",meanSD(FakeData$Age),rangefun(FakeData$Age))
)

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r tab`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("&nbsp;","Mild","Moderate","Severe"))`
#  `r RowOfRowPct("Whole group",FakeData$Severity,
#       c("Mild","Moderate","Severe"))`
#  `r RowOfRowPct("Males",FakeData$Severity[FakeData$Sex=="M"],
#       c("Mild","Moderate","Severe"))`
#  `r RowOfRowPct("Females",FakeData$Severity[FakeData$Sex=="F"],
#       c("Mild","Moderate","Severe"))`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("&nbsp;","Mild","Moderate","Severe"))`
#  `r RowOfRowPct("Whole group",FakeData$Severity,
#       c("Mild","Moderate","Severe"),showN=TRUE)`
#  `r RowOfRowPct("Males",FakeData$Severity[FakeData$Sex=="M"],
#       c("Mild","Moderate","Severe"),showN=TRUE)`
#  `r RowOfRowPct("Females",FakeData$Severity[FakeData$Sex=="F"],
#      c("Mild","Moderate","Severe"),showN=TRUE)`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("&nbsp;","Mild","Moderate","Severe"))`
#  `r RowOfRowPct("Whole group",FakeData$Severity,
#       c("Mild","Moderate","Severe"),nmiss=TRUE)`
#  `r RowOfRowPct("Males",FakeData$Severity[FakeData$Sex=="M"],
#       c("Mild","Moderate","Severe"),nmiss=TRUE)`
#  `r RowOfRowPct("Females",FakeData$Severity[FakeData$Sex=="F"],
#       c("Mild","Moderate","Severe"),nmiss=TRUE)`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("&nbsp;","Mild","Moderate","Severe","p-value"))`
#  `r RowOfColPct("Males",FakeData$Sex=="M",FakeData$Severity,
#      levels=c("Mild","Moderate","Severe"))`
#  `r RowOfColPct("Females",FakeData$Sex=="F",FakeData$Severity,
#      levels=c("Mild","Moderate","Severe"),test="")`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("&nbsp;","Mild","Moderate","Severe","p-value"))`
#  `r RowOfColPct("Males",FakeData$Sex=="M",FakeData$Severity,
#      levels=c("Mild","Moderate","Severe"),showN=TRUE)`
#  `r RowOfColPct("Females",FakeData$Sex=="F",FakeData$Severity,
#      levels=c("Mild","Moderate","Severe"),test="",showN=TRUE)`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("&nbsp;","Mild","Moderate","Severe","p-value"))`
#  `r RowOfColPct("Males",FakeData$Sex=="M",FakeData$Severity,
#      levels=c("Mild","Moderate","Severe"),nmiss=TRUE)`
#  `r RowOfColPct("Females",FakeData$Sex=="F",FakeData$Severity,
#      levels=c("Mild","Moderate","Severe"),test="",nmiss=TRUE)`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r pipetableheader(c("&nbsp;","n (%)"))`
#  `r categ(FakeData$Severity,"Illness severity")`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r npct(FakeData$Age,nmiss=TRUE)["5"]`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  **Variable** | **Male n/N (%)** | **Unadjusted OR (95% CI)** | **p-value**
#  ------------|-------------------|-------------|---------
#  `r uORtable(c("Age","Severity"),"Male",data=FakeData)`

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  ---
#  title: |
#    Quality Report
#  subtitle: |
#    Intermittent vs. Continuous Oxygen Saturation Monitoring\
#    in Infants Hospitalized for Bronchiolitis\
#    A Randomized Controlled Trial - SK REB 1000054699\
#  author: "Nick Barrowman"
#  date: '`r strftime(Sys.time(),format="%d-%b-%Y at %H:%M")`'
#  params:
#    datafile: "R:/CRU Data/Thing/Master/.RData"
#  output:
#    word_document:
#      reference_docx: R:/CRU Epibiostat/Rmarkdown knitr/templateWithBlock.docx
#  ---

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  template.docx
#  template_landscape.docx
#  templateLandscape10ptArial.docx
#  templateLandscape10ptArialNarrowMargins.docx
#  templateLandscape8ptArial.docx
#  templateLandscape8ptArialNarrowMargins.docx
#  templateLandscapeNarrowTopBottomMarginsSmallTableFont.docx
#  templateNarrowMargins.docx
#  templateNarrowMarginsSmallTableFont.docx
#  templateNarrowMarginsSmallTableFontWithBlock.docx
#  templateNarrowTopBottomMargins.docx
#  templateNarrowTopBottomMarginsSmallTableFont.docx
#  templateOriginal.docx
#  templateSmallTableFont.docx
#  templateSmallTableFontNarrowMargin.docx
#  templateSuperNarrowTopBottomMargins.docx
#  templateWithBlock.docx
#  templateWithPageBreaks.docx

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  Variable                        | N
#  --------------------------------|-----------
#  Agegroup                        |
#  &nbsp;&nbsp;&nbsp;&nbsp;< 1     | 50
#  &nbsp;&nbsp;&nbsp;&nbsp;1 - <3  | 50
#  &nbsp;&nbsp;&nbsp;&nbsp;3+      | 50

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  Country | Population\
#  Size | Capital
#  --------------|-----------|------------------
#  Narnia        | Thousands | Cair Paravel
#  Middle Earth  | Gazillions| Minas Tirith

## ---- highlight=FALSE, eval=FALSE---------------------------------------------
#  `r boilerplate()`

