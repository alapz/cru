# Run this to read data from the FakeData.csv file and store it
# in the appropriate way to become part of the package.
FakeData <- read.csv("FakeData.csv",na.strings="")
devtools::use_data(FakeData,overwrite=TRUE)
